// COUNTER10.CPP CLIENT PROGRAM
// This program will run a throttled counter with files. 
// It will also be able to run in parallel or by itself. Each counter has its own experimental counter but there is only one control counter
// This program uses files. 
// The only thing the decrypt functions share is the control counter. There is only one control counter.
// Copyright (C) 2016 http://time-travel.institute
// ============================================================================================
 // declare includes
    #include <cstdlib>
    #include <iostream>
    #include <stdlib.h>
    #include <fstream>
    #include <sstream>
    #include <string> 
    #include <cmath>
    #include <ctime>
    #include <cstdio>
    #include <iostream>
    #include "timecheckhacking.h"
// checklockfile give name of file and gives a 0 or 1 back
// backupcounter give file names
// getdiff3 Note pass target checksum to it and name of counter file use lock files
// getfilesize Note give file name use lock file and give name of lock file
// getstrongchecksum Note give file name it computes its own filesize and uses lock files
// get weak check sum
// binaryreadwrite build in using lock files
// setspeedrandom Note: using linear or random file size give name of file
// createcounterrandom Note:randomly writes a counter file of given size give name of file to write
// addspeedtocounter Note:pass file names (Note using lock file)
// throttled decrypt function one
// compare destination, target, diff3 and backup when needed
// ============================================================================================
    // Declare namespace
    using namespace std;
// ============================================================================================     
// declare globals 
    long double targetstrongchecksum;
    long double destinationstrongchecksum;
    string file1;
    long long filesize1;
    long long howmanyweightedsums;
// ============================================================================================     
// declare subs
// This is where all the work is done to make the program run.
// ======================================================================================================================
// loadconfig Note give name of config file
int loadconfig() 
{// Can't put this in a header and use globals
    // Declare these variables as global in your main file
    // declare variables
    string dummy;
    string pause;
// Load configure file
          fstream c1myfile("config.txt", ios::in);
          // read name of file
          c1myfile >>  dummy >> dummy >> dummy >> file1;
          // strong check sum
          c1myfile >>  dummy >> dummy >> dummy >> targetstrongchecksum;
          // read file size
          c1myfile >>  dummy >> dummy >> dummy >> filesize1;
          // read how many weights
          c1myfile >>  dummy >> dummy >> dummy>> dummy >> howmanyweightedsums;

         // close configure file
          c1myfile.close();
          c1myfile.clear();
          c1myfile.flush();

         // Print configure file to confirm loaded correctly
          cout << "File name > " << file1 << "\n";
          cout.precision(36);
          cout << "Strong check-sum > " << targetstrongchecksum << "\n";
          cout.precision(36);
          cout << "File size > " << filesize1 << "\n";
          cout.precision(36);
          cout << "How many weighted check-sums > " << howmanyweightedsums<< "\n";
          cout << "\n"; 
          cout << "Is the configuration file loaded properly?" << "\n";
          cout << "Hit any key and enter." << "\n";
          cin >> pause;
          return(0);
//        
}
// ============================================================================================
// declare main
    int main (int argc, char *argv[])
    { 
         // declare variables
         char pause;
         string configfile = "";  
         string lockfile = "lock.txt";
         int dummyfile = 0;
         string file2 = "speed.bin";
         string file3 = "random.bin";
         string file4 = "counter.bin";
         string file5 = "counterbak.bin";
         int buffersize = 1;
         long long randfileposition = -1;
         long double destinationstrongchecksum;     
         long double diff3;
         int comparetest = 0;   
         int test = 0;
// ============================================================================================
// Test subs and functions here
// ============================================================================================         
         // pass arguments to program. If no arguments run menu. If Arguments run program
         // pass arguments to program. If no arguments run menu. If Arguments run program
         if (argc == 1) 
         {
              cout << "No command line arguments. I can't run. Type nameofprogram help" << "\n";
              cin >> pause;
              exit(1);   
         }

         // passing command line arguments to program
         configfile = argv[1]; // name of config file only // contains lockfile, strong checksum, howmany weighted sums, and file size.

         if (configfile == "help")
         {
              cout << "This is help here." << "\n";
              cin >> pause;
              exit(0); 
         }

// ============================================================================================
         // open configure file here and read it.
         dummyfile = loadconfig();

         // name counter file counter.bin so we don't over write the file if it still exist.
         file1 = "counter.bin";
// ============================================================================================
        // create lockfile
        dummyfile = createemptyfile(lockfile);
// ============================================================================================
        // create counter.bin to hold file
        dummyfile = createsizefile(file1, filesize1, buffersize); // experimental counter
        dummyfile = createsizefile(file5, filesize1, buffersize); // control counter
// ============================================================================================
//      // initialize counter here
        dummyfile = generaterandomnumbers(10000); 
// ============================================================================================
         // get destination for diff3
         destinationstrongchecksum = getstrongchecksum(file1, howmanyweightedsums, buffersize);
// ============================================================================================
         diff3 = abs(destinationstrongchecksum - targetstrongchecksum);
// ============================================================================================
         comparetest == 0; // we start out and roll counter till both the experimental and the control are completely different
// ============================================================================================         
        // run main loop for file construction
        do
        {
// ============================================================================================
// Decrypt
// Function1  // Running in Random
              // set speed Note size of speed can be linear or random. Specifiy

//file1 = "file being reconstructed"
// file2 = "speed.bin";
// file3 = "random.bin";
// file4 = "counter.bin";
// file5 = "counterbak.bin";

//              system("rm speed.bin");
         
              // Set speed for counter
              randfileposition = setspeedrandom1(randfileposition, file3, file2, buffersize, filesize1);
              
              if (comparetest == 1)
              {

                   dummyfile = rollcounter2(file1,file2, file5, buffersize, filesize1);
                   test = compare2(file1, file5, filesize1, buffersize); // if the files are the same test = 0
                   if (test == 0)
                   {
                        comparetest = 0;
                   }
              }

              if (comparetest == 0)
              {
                   dummyfile = rollcounter1(file1, file2, buffersize, filesize1);
                   test = compare3(file1, file5, filesize1, buffersize); // if the files are completely different test = 0
                   if (test == 0)
                   {
                        comparetest = 1;
                   }
              }                   

              // get destination
              destinationstrongchecksum = getstrongchecksum(file1, howmanyweightedsums, buffersize);

             
              // break loop if diff3 == 0
              if (abs(targetstrongchecksum - destinationstrongchecksum) == 0)
              {
                   if (targetstrongchecksum == destinationstrongchecksum)
                   {
                        break;
                   }
              }

              // if abs(destination - target) < diff3 then backup counter 
              if (abs(targetstrongchecksum - destinationstrongchecksum) < diff3)
              {
                   system("cp counter.bin counterbak.bin");

              // if abs(destination - target) < diff3 then diff3 = abs(destination - target)
                   diff3 = abs(destinationstrongchecksum - targetstrongchecksum);

              }

              // check lock file
              dummyfile = checklockfile(lockfile);

              // display output (for testing only)
              cout << "Diff3 " << diff3 << " Destination sum " << destinationstrongchecksum << " Target sum "<< targetstrongchecksum << "\n";

//              dummyfile = viewfile1(file1, buffersize, filesize1);

// ============================================================================================
        // end main loop for file construction   
        } while(targetstrongchecksum != destinationstrongchecksum);            
        // End program
       

    }
// ===========================================================================================
