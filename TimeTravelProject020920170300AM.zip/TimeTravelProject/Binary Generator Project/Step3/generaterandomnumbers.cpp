// Random number generator
// Creates a file of random numbers
// the program is ran with the parameters "name of program" "thefilesize"
// Divide filesize / 255 to determine how many times each number can occur in the file
// Divide filesize / 255 to determine the frequency of each number occuring in the file.
// Use a random number generator with my own to pic which number from 0 to 255 then use that number in the file a specific number of times occuring to that specific frequency. All numbers occure the same amount of time to the same amount of frequency as randomly as possible.
// As each number is used it will be written to a do not use again list and that listed checked time a new number is selected.
// do not limit file size instead let that float till done because the math is not always perfect for a giving file size.
// This is for a random number file to be used in cryptography. 

// This program generates a random number file for use with calculating strong check-sums
// Copyright (C) 2016 http://time-travel.institute
// NOTE TO PROGRAMMER - SET THIS UP TO RUN WITH COMMAND LINE PARAMETERS.
// ============================================================================================
 // declare includes
     #include <cstdlib>
     #include <iostream>
     #include <stdlib.h>
     #include <fstream>
     #include <sstream>
     #include <string> 
     #include <cmath>
     #include <ctime>
     #include <cstdio>
     #include <iostream>
// ============================================================================================
    // Declare namespace
    using namespace std;
// ============================================================================================     
    // declare globals
// ============================================================================================     
// declare subs
// This is where all the work is done to make the program run.
// int viewfile1
// ==========================================================================
int viewfile1(string file1, long long filesize1, int buffersize)
{
// declare variables
     int count = -1;
	 int byte1 = 0;
     long long begin1 = 0;
	 unsigned char buffer(buffersize);
	 string pause;
// open file 1
     fstream myfile1(file1.c_str(), ios:: in | ios:: binary);
     if (!myfile1)
     {
          cout << "Error in line 314 view file.\n";
          cin >> pause;
          myfile1.close();
          myfile1.clear();
          myfile1.flush();
	  exit(1); // terminate with error
     }
// read file view output   
     do
     {
          count++;

         // read file 1
          myfile1.seekg(count);
          myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellg();
          byte1 = (int)buffer;
	  cout << " count " << count << " " << " byte " << byte1 << "\n";

      } while (count < filesize1 - 1);


// close file1
// close file2
      myfile1.close();
      myfile1.clear();
      myfile1.flush();

      return(0);
}

// ============================================================================================================
// declare main
int main (int argc, char *argv[])
{ // Begin main

    // declare variables
    long long filesize1 = 0; // Note the true filesize of this file has not been determined yet. This is the filesize in theory that we want.
    long long frequency1 = 0; // constant
    long long occurance1 = 0; // constant
    long long frequency2 = 0; // variable
    long long occurance2 = 0; // variable
    long long count1 = 0; // counts up to 255 then we are done. All bytes in file at same frequency and occurance.
    long long count2 = 0; // counting occurance and frequency
    long long count3 = 0; // counting file position
    long long count4 = 0; // unused
    string file1 = "random.bin";
    long long startposition1 = 0; // starting position in the file for each new byte
    long long startposition2 = 0; // starting position in the file for each new byte
    long long begin1;
    long long end1;
    unsigned char buffer;
    int buffersize = 1;
    string pause;
    time_t seconds;
    srand((unsigned int) 5654940); // This seed number can be changed to what ever you want.        
    long long a = 3;
    long long c = 2361;
    long long m = 999999;
    long long k = 0;
    long long r = 0;
    int byte1 = 0;
    int test = 0;
    int dummyfile;

    // Get file size from command line argument.
    filesize1 = strtoull(argv[1],NULL,10);

    // double donotuse[255];
    double donotuse[255];

    // initialize do not use array with -1
    count1 = 0;
    do
    {
         donotuse[count1] = -1;
         count1++;
    } while(count1 < 256);


    // calculate frequency of use
    frequency1 = round(filesize1 / 255);
    frequency2 = frequency1;

    // calculate how often used
    occurance1 = round(filesize1 / 255);
    occurance2 = occurance1;

    // open binary file random.bin
    fstream myfile1(file1.c_str(), ios::out | ios::binary);
    if (!myfile1)
    {
         myfile1.close();
         cout << "Failed to read file one line 94.\n";
         cin >> pause;
         exit(1);
    }

    // initilize counts
    count1 = 0; // general counting variable
    count2 = 0; // counting occurance and frequency
    count3 = 0; // counting file position
    count4 = 0; // counts up to 255 then we are done. All bytes in file at same frequency and occurance.
    startposition1 = 0; // starting position in the file for each new byte
    do // Start main loop for occurance1
    {

         // jump1
jump1:
         // pick random number
         time(&seconds);
         k = (rand() % 429940833); // We can randomize timer here if we want. Thats up to the user.
         k = k + seconds;
         byte1 = (a * k + c) % 256;
 
         // initilize count1
         count1 = 0;
         // initilize test
         test = 0;
         // start do loop
         do
         {
              // test to see if number in do not use array
              if (donotuse[count1] == byte1)
              {
                   test = 1;
                   break;
              }
              // increment count1
              count1++;
         // end do loop
         } while(count1 < 255);

         // if test == 1 goto jump1
         if (test == 1)
         {
              goto jump1;
         }
         
         // if test == 0 keep going
              // no code needed here we keep going

         // initialize count1
         count1 = 0;

         // start do loop
         do
         {
              // put number in do not use array where there is a -1
              if (donotuse[count1] == -1)
              {
                   donotuse[count1] == byte1;
                   break;
              }
              // increment count1
              count1++;

         // end do loop
         } while(count1 < 255);

         // set occurance1 = occurance2
         occurance2 = occurance1;

         // Put binary number in file at frequency and occurance
         count1 = 0; // counts bytes as they are used. Must be 0 starting out.
         count2 = startposition1; // used for occurance
         count3 = startposition1; // used for file position
         startposition2 = startposition1; // setting variable startposition2
         occurance2 = occurance1; // setting variable occurance2
         do // Start second loop for frequency1
         {
              if (count2 == startposition2)
              {
                   // occurance2--
                   occurance2--;

                   // put number in file at count3;
                   buffer = (unsigned char)byte1;
                   myfile1.seekp(count3);
                   myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
                   begin1 = myfile1.tellp();


                   // startposition2 = -999 // so we do use this again
                   startposition2 = -999;            
              }

              count2++;
              if (count2 >= occurance1)
              {
                   // occurance2--
                   occurance2--;

                   // put number in file at count3
                   buffer = (unsigned char)byte1;
                   myfile1.seekp(count3);
                   myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
                   begin1 = myfile1.tellp();

                   // reset count2
                   count2 = 0; 
              }
 
              count3++; // file position

          } while(occurance2 > 0);

         // reset start position2
         count4++; // counts up to 255 then we are done. All bytes in file at same frequency and occurance.

         // starting position in the file for each new byte 
         startposition1++;          

    } while(count4 < 255); // End main loop for file size

    // close random.bin
    myfile1.close();
    myfile1.clear();
    myfile1.flush();

    
//    dummyfile = viewfile1(file1, filesize1, buffersize);
//    cout << "These were your random numbers" << "\n";

    // exit prograom
    exit(0);
} // End main
