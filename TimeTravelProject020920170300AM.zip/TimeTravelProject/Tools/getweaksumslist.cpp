// int getweaksumsfilelist(int buffersize)
// Must have a list.txt file with the names of the files to get a weak check-sum of.
// outputs a weaksums.txt file
// COPYRIGHT(C) 2017 http://time-travel.institute
// ============================================================================================
// Declare includes
#include <cstdlib>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <string> 
#include <cmath>
#include <ctime>
#include <cstdio>
#include <iostream>
#include "timecheckhacking.h"
// ============================================================================================
// Declare namespace
using namespace std;
// ============================================================================================
// declare main
int main (int argc, char *argv[])
{
    // Declare variables
    int buffersize;
    int dummyfile;

    // Command line arguments
    buffersize = atoi( argv[1]); // How many bytes we are reading at a time.

    dummyfile = getweaksumsfilelist(buffersize);
    exit(0);
}
