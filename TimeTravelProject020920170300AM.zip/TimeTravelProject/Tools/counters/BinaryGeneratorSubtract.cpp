// This program will take a high file and a low file and treat them as numbers in a numerical base.
// Then this program will generate binary files between those two numbers
// Give this program the differece by using the filesize of the difference between the two files
// IF YOU RUN THIS PROGRAM AND GET A SEGMENTAION FAULT ERROR THEN YOU RAN IT INCORRECTLY. IT TAKES COMMAND LINE PARAMETERS TO RUN THIS PROGRAM.
// Compile this program like this g++ BinaryGenerator.cpp -o BinaryGenerator
// COPYRIGHT(C) 2017 http://time-travel.institute
// THIS PROGRAM IS USED FOR COMPUTER TIME TRAVEL
// program                                       buffersize filesize howmanyfiles destinationfile       seedfile                    fileextension
// This program is run like this ./nameofprogram buffersize filesize howmanyfiles nameofdestinationfile nameofrandomnumberseedfile  fileextension    
// ============================================================================================
// declare includes
#include <cstdlib>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <string> 
#include <cmath>
#include <ctime>
#include <cstdio>
#include <iostream>
// ============================================================================================
    // Declare namespace
using namespace std;
// ============================================================================================     
// declare subs
// ======================================================================================================================
long long filesize(string file1)
{
// declare variables
    long long begin1;
    long long end1;
    long long filesize1;
    string pause;  

    // open file1
    fstream myfile1(file1.c_str(), ios::in | ios::binary);
    if (!myfile1)
    {
         myfile1.close();
         cout << "Failed to read file one line 134.\n";
         cin >> pause;
         exit(1);
    }

// get filesize1
    begin1 = myfile1.tellg();
    if (!myfile1)
    {
         myfile1.close();
         cout << "Failed to read file one line 316.\n";
         cin >> pause;
         exit(1);
    }
    myfile1.seekg (0, ios::end);
    end1 = myfile1.tellg();
    filesize1 = (end1-begin1);     

// close file 1
    myfile1.close();
    myfile1.clear();
    myfile1.flush();

// return filesize
    return(filesize1);
// end sub
}
// ======================================================================================================================
// ======================================================================================================================
int binaryreadwrite(string whatdo, string file1, long long byteposition, int byte, int buffersize)
{

    unsigned char buffer(buffersize);
    char pause;
    int byte1 = byte;
    long long count1 = byteposition;
    long long begin1;
//     int buffersize = 1;
       
    // open file
    fstream myfile1(file1.c_str(), ios::out  | ios::in | ios::binary);
    if (!myfile1)
    {
         myfile1.close();
         cout << "error in line 79" << " " << file1 << "\n";
         cin >> pause;
         exit(1);
    }
    if (whatdo == "read")
    {
// cout << byte1 << " We are reading bytes " << "\n"; // debug code
         myfile1.seekg(count1);
         myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
         begin1 = myfile1.tellg();
         byte1 = (int)buffer;
         myfile1.close();
         myfile1.clear();
         myfile1.flush();
         return(byte1);
    }
    if (whatdo == "write")
    {
// cout << byte1 << " We are writing bytes " << "\n"; // debug code
         buffer = (unsigned char)byte1;
         myfile1.seekp(count1);
         myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
         begin1 = myfile1.tellp();
         myfile1.close();
         myfile1.clear();
         myfile1.flush();
         return(0);
    } 
     

    cout << "Error in binary read and write" << "\n";
    cin >> pause;
    exit(1);
}
// ======================================================================================================================

// ============================================================================================
// declare main
int main (int argc, char *argv[])
{

    long long filesize1;
    long long filesize2;
    long long filesize3;
    string destinationfile;
    string seedfile; 
    string extension;
    int buffersize;
    string file1; // This is the suspected time travel media file
    string file2 = "temp.bin"; // This is the file we subtract from the main file.
    long long count1;
    long long count2;
    long long count3;
    int byte;
    int byte1;
    int byte2;
    int byte3; 
    int carry;
    string pause;
    int dummyfile;
    string whatdo;
    long long numberbase;
    long long howmanyfiles;
    fstream myfile1;
    fstream c1myfile1; // Seed file
    long long seed;
                                     // program      buffersize filesize howmanyfiles destinationfile       seedfile                    fileextension
    // This program is run like this ./nameofprogram buffersize filesize howmanyfiles nameofdestinationfile nameofrandomnumberseedfile  fileextension     // passing command line arguments to program
    buffersize = atoi( argv[1]); // How many bytes we are reading at a time.
    filesize1 = strtoull(argv[2],NULL,10); // Largest file size of temp.bin to subtract from destination file.
    howmanyfiles = strtoull(argv[3],NULL,10); // This is how many files we are building to day.
    destinationfile = argv[4]; //This is the file we will subtract from with temp.bin
    seedfile = argv[5]; // Name of random number seed file. We are not using this just yet.
    extension = argv[6]; // file extension for target files.

    // Setting name of destination file from command line
    filesize3 = filesize(destinationfile);

    // Setting up number base;
    numberbase = (buffersize * 255) + 1;
    // setting up file namer
    count3 = 0;

    // setting up for how man files
    count1 = 0;

      // open seed file
    c1myfile1.open(seedfile.c_str(), ios::in);
    if (!c1myfile1)
    {
         cout << "There is no file list." << "\n";
         c1myfile1.close();
         c1myfile1.clear();
         c1myfile1.flush();
         exit(0);           
    }
    c1myfile1 >> seed; 
    srand((unsigned int) seed); 
    // Start main loop <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Here for debugging
    do
    {
         count1++;

// ============================================================================ DECIDED STATIC OR RANDOM
         // Get random file size below max file size
         filesize2 = (rand() % filesize1 - 1); // minus so are files don't go over the max file size.

         // If you want a specific filesize set that here <<<<<<<<<<<<<<<<<<<<<<<<<<<<<< YOU CAN HAVE A STATIC OR RANDOM FILE SIZE!!!!!!!!!!!!!!!
//         filesize2 = 24;        
// ============================================================================ DECIDED STATIC OR RANDOM
 
         system("rm temp.bin"); // removing the previous file

         // create temp bin
         myfile1.open(file2.c_str(), ios::out  | ios::binary);
         if (!myfile1)
         {
              myfile1.close();
              cout << "error in line 38" << " " << file2 << "\n";
              cin >> pause;
              exit(1);
         }
         myfile1.close();
         myfile1.clear();
         myfile1.flush();

         // Get random binary          
//         srand(time(0)); // randomize timer
         c1myfile1 >> seed; 
         srand((unsigned int) seed);
         count2 = buffersize * -1;
         // start second loop
         do
         {
              count2 = count2 + buffersize;
              byte = (rand() % (255*buffersize));
              whatdo = "write";
              file2 = "temp.bin";
              // write random binary
              dummyfile = binaryreadwrite(whatdo, file2, count2, byte, buffersize);

              // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< NOTE CAN ADD RESEEDED RANDOM NUMBER GENERATOR WHERE WITH SEED FILE
//              c1myfile1 >> seed; 
//              srand((unsigned int) seed);

          // end second loop for random file size
         } while(count2 < filesize2);

         // get file name  from ss
         stringstream ss;
         count3++;
         file1 = "";
         ss << count3;
         ss >> file1;
         file1 = file1 + extension;

         myfile1.open(file1.c_str(), ios::out  | ios::binary);
         if (!myfile1)
         {
              myfile1.close();
              cout << "error in line 245" << " " << file1 << "\n";
              cin >> pause;
              exit(1);
         }
         myfile1.close();
         myfile1.clear();
         myfile1.flush();



         carry = 0;
         count2 = buffersize * -1;
         // start third loop
         do
         {
              // increment file variable
              count2 = count2 + buffersize;

              // set byte1 to zero
              byte1 = 0;

              // read byte1 if less than filesize
              whatdo = "read";

              if (count2 < filesize3 - 1)
              { 
                   byte1 = binaryreadwrite(whatdo, destinationfile, count2, byte, buffersize);
              }

              // // set byte2 to 0
              byte2 = 0;

              // read byte2 if less than filesize
              if (count2 < filesize2) // Dont have to use minus one here because it is upto filesize1 - 1 already.
              {
                   byte2 = binaryreadwrite(whatdo, file2, count2, byte, buffersize);
              }

              // byte3 = byte1 - byte2 - carry;
              byte3 = byte1 - byte2 - carry;

              // carry = 0;
              carry = 0;

              // if byte < 0 subtract from the base
              if (byte3  < 0)
              {
                   byte3 = byte3 + numberbase;
                   carry = 1;
              }

              // Check for error
              if (byte3 > (numberbase - 1))
              {
                   cout << "Houston we have a problem\n";
                   cout << "byte3 greater than the base - 1\n";
                   cin >> pause;
                   exit(0);
              }

              // write random binary
              whatdo = "write";
              dummyfile = binaryreadwrite(whatdo, file1, count2, byte3, buffersize);


         // end third loop
         } while(count2 < filesize2); // We can use filesize2 or filesize3 here as our stop. I chose filesize2 so it would not copy into output file.
                                      // from the destination file. if filesize 2 and 3 are the same size then also not a problem.
         // if carry has value write it
         if (carry > 0)
         {
              // write random binary
              whatdo = "write";
              dummyfile = binaryreadwrite(whatdo, file1, count2, carry, buffersize);
              // write to addition file              
              carry = 0;
         }

         // Reseed random number generator
         // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Do reseeding here 
//        c1myfile1 >> seed; 
//        srand((unsigned int) seed);

     // End main loop for how many files to create
    } while(count1 < howmanyfiles); 
    c1myfile1.close();
    c1myfile1.clear();
    c1myfile1.flush();
    system("rm temp.bin");
    exit(0);
 
}
