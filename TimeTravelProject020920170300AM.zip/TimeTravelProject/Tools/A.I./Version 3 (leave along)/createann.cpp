// Program gives choices of types of networks to create and gets information from user and creates those networks automatically.

// Choices will be 
//             1. Standard Feed forward neural net. How many input nodes. How many output nodes. 
//             2. Standard recurring neural net. How many input nodes. How many output nodes.
//             3. Customized Ann. 

// Node types
// 1. input
// 2. output
// 3. worker
// 4. input/output

// Each neural net has a master neural net file. It contains - Net type, how many inputs, how many outputs, total nodes, nodes per layer, total layers

// Each node has 4 files. Master file - Broken down into three files: 1. name. masterfile 2. name.Inputmaster 3. name.Outputmaster
//                          1. list node type, how many input nodes, how many output nodes.              
//                          2. input nodes list. example 1, 2, 3
//                          3. output nodes list. example 5, 6, 7
                       
//                        input log file. - All input data and what node they are recorded from are recorded here temporaly.
//                                            Node from | input
//                        output log file - The output and what nodes those outputs were recorded too.
//                                            Node too | output   
//                        weight file - Weight is recorded here temporaly 
//                                        Node from | weight
//                        data base - all inputs and their weights are recorded here.
//                                      Node From | input | weight 
//                        Threshold file - After training this will be calulated and held here. A 0 means no thresh-hold.
//                                           High | Low  
     
// Program will use backpropagation for training. 
// for output nodes and worker nodes - output will be devided by number of inputs to get weighted sum at each input. Weights picked input calulated.
// for input nodes - output will be devided by number of inputs to get weighted sum at each input. Weights calulated from known input.

// The data base per node will hold each input, where it is from, and its weight. After training thresh holds can be calulated and per node if wanted.


// This type of network remembers all of its training and applys all of its training to a problem. 

// Training Program.
// 1. Load Master file.
// 2. Load output.
// 3. Compute distrubitied sum.
// 4. if Input read compute weight and write it to log file.
// 5. if input read skip to number 8  
// 6. if Input empty select weight and write it to log file and compute input and write it to log file.
// 7. copy input to its output node. Read output node master file and copy output to their input nodes.
// 8. write input & weight to data base.
// 9. Go back to orginal node and repeat training for rest of inputs on that node.
// 10. Derement one node and repeat training program.
// 11. When all nodes exhausted end training program

#include <cstdlib>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <string>
#include <cmath>

using namespace std;

int main (int argc, char *argv[])

{
     
     long long layers = 0; // counts layers as they are created
     long long maxlayers = 0; // holds max number of layers for neural net
     long long nodes = 0; // counts nodes in each layer
     long long countnodes = 0; // Used with ss to name files.
     long long inputs = 0; // number of input nodes
     long long outputs = 0; // number of output nodes
     long long maxnodes; // how many nodes per layer
     long long endingnode; // ending node in output / input files.
     long long startingnode; // starting node in output / input files.
     string mext = ".masterfile"; // extension to denote master file.
     string miext = ".inputmasterfile";
     string moext = ".outputmasterfile";
     string iext = ".input"; // extension to denote input file.
     string oext = ".output"; // extension to denote output file.
     string wext = ".weight"; // extension to denote weight file
     string dext = ".database"; // extension to denote data base file.
     string text = ".threshold"; // extension to denote threshold file.
     string file0 = "";
     string file1 = "";
     string file2 = "";
     string file3 = "";
     string file4 = "";
     string file5 = "";
     string file6 = "";
     string file7 = "";
     string file8 = "";
     
     int x; // dummy variable
     std::stringstream ss;     

     cout << "Create artificial intellegent neural network." << "\n"; 
     
     cout << "\n"; 
     
     cout << "Select your choice." << "\n";  
     
     cout << "\n";

     cout << "1. Standard artificial intellegent neural network." << "\n";  
     
     cout << "\n";

//     cout << "2. Recurring artificial intellegent neural network." << "\n";  
     
//     cout << "\n";

//     cout << "3. Customized artificial intellegent neural network." << "\n";
     
//     cout << "\n";
     
     cout << "Any other - Exit." << "\n";
     
     cout << "\n";

     // get the response  
     char choice;  

     cin >> choice;  
     
     if (choice=='1') 
     {

// ask user how many layers  
          cout << "How many layers in your network?\n";
          cin >> maxlayers; 
          
// ask user how many neurons in each layer  
          cout << "How many neurons in each layer?\n";
          cin >> maxnodes;
          
// ask user how many inputs
//          cout << "How many inputs in your network?\n";
//          cin >> inputs;
            inputs = maxnodes;
                    
// ask user how many outputs
//          cout << "How many outputs in your network?\n";
//          cin >> outputs;
            outputs = maxnodes;
                     
// create master neurual net file
          file0 = "neuralnet.masterfile";
          fstream myfile0(file0.c_str(), ios:: out);
          if (!myfile0)
          {
               myfile0.close();
               cout << "Failed to read file in line 152\n";
               cin >> x;
               exit(1);
          } 
          
// neural net type , total inputs , total outputs, total nodes in network, nodes per layer, total number of layers
          myfile0 << "Forward" << " " << inputs << " " << outputs << " " << maxlayers * maxnodes << " " << maxnodes << " " << maxlayers << "\n";
          
// set layers to zero
          layers = 0;
         
// count layers loop start
          do
          {
// increment layers
               layers++;

// set nodes to zero
               nodes = 0;
     // count nodes loop start
               do
               {
          // increment node count
                    nodes++; // counts nodes per layer
                    countnodes++; // counts what node on in the neural net
          // putting in file one string
//                          1. list node type, how many input nodes, how many output nodes.   
                    ss.clear();
                    file1 = "";
                    ss << countnodes;
                    ss >> file1;
                    file1 = file1 + mext;
                              
          // declare main master file
          // open main master file
          // create Write main master file
          // 1. list node type, how many input nodes, how many output nodes

                    fstream myfile1(file1.c_str(), ios:: out);
                    if (!myfile1)
                    {
                         myfile1.close();
                         cout << "Failed to read file in line 193\n";
                         cin >> x;
                         exit(1);
                    } 
                    
                    if (countnodes <= inputs)
                    {
                         myfile1 << "input" << " " << 1 << " " << maxnodes << "\n";
                    }
               
                    if (countnodes > inputs) 
                    {
                         if ((countnodes + outputs) <= (maxlayers * maxnodes))
                         {
                              myfile1 << "worker" << " " << maxnodes << " " << maxnodes << "\n";
                         }
                    }
               
                    if ((countnodes + outputs) > (maxnodes*maxlayers))
                    {
                         myfile1 << "output" << " " <<  maxnodes << " " << 0 << "\n";
                    }                

          // close 1
                    myfile1.close();
          
          // putting name in file two string
                    ss.clear();
                    file2 = "";
                    ss << countnodes;
                    ss >> file2;
                    file2 = file2 + miext;          

          // declare 2 master file
          // open 2 master file

                    fstream myfile2(file2.c_str(), ios:: out);
                    if (!myfile1)
                    {
                         myfile2.close();
                         cout << "Failed to read file in line 233\n";
                         cin >> x;
                         exit(1);
                    } 

          // create Write 2 master input file
          //  2. masater input nodes list. example 1, 2, 3    
          
                    if (countnodes <= inputs)
                    {
                         myfile2 << 0 << "\n";
                    }
               
                    if (countnodes > inputs) 
                    {
                    // Find ending input node
                         endingnode = (layers - 1) * maxnodes;
                    // find starting input node
                         startingnode = endingnode - maxnodes; // Will add one to this in the loop.
                    // write inputs to master file
                         do
                         {
                              startingnode++;
                              myfile2 << startingnode << "\n";
                         } while (startingnode < endingnode);    
                    }
          // close input file.
                    myfile2.close();                      

          // put name in master output file    
                    ss.clear();
                    file3 = "";
                    ss << countnodes;
                    ss >> file3;
                    file3 = file3 + moext;          

          // declare master output file
          // open master output file

                    fstream myfile3(file3.c_str(), ios:: out);
                    if (!myfile3)
                    {
                         myfile3.close();
                         cout << "Failed to read file in line 276\n";
                         cin >> x;
                         exit(1);
                    } 

          // create master output file
          
                    if (countnodes <= inputs)
                    {
                    // Find ending input node
                              endingnode = (layers + 1) * maxnodes;
                    // find starting input node
                              startingnode = endingnode - maxnodes; 
                    // write inputs to file
                         do
                         {
                              startingnode++;
                              myfile3 << startingnode << "\n";
                         } while (startingnode < endingnode);    

                    }

                    if (countnodes > inputs) 
                    {
                         if ((countnodes + outputs) <= (maxlayers * maxnodes)) 
                         {
                    // Find ending input node
                              endingnode = (layers + 1) * maxnodes;
                    // find starting input node
                              startingnode = endingnode - maxnodes; 
                    // write inputs to file
                              do
                              {
                                   startingnode++;
                                   myfile3 << startingnode << "\n";
                              } while (startingnode < endingnode);    

                         }
                    }
               
                    if ((countnodes + outputs) > (maxnodes*maxlayers))
                    {
                         myfile3 << 0 << "\n";
                    }                


          // close Master output file
                    myfile3.close();

          // put name in input log file
                    file4 = "";
                    ss.clear();
                    ss << countnodes;
                    ss >> file4;
                    file4 = file4 + iext;
                    
          // declare input log file
          // open input long log file
          // create input log file
                    fstream myfile4(file4.c_str(), ios:: out);
                    if (!myfile4)
                    {
                         myfile4.close();
                         cout << "Failed to read file in line 324\n";
                         cin >> x;
                         exit(1);
                    } 
          // close input log file
                    myfile4.close();          

          // put name in output log file
                    file5 = "";
                    ss.clear();
                    ss << countnodes;
                    ss >> file5;
                    file5 = file5 + oext;

          // declare output log file
          // open output log file
          // create output log file

                    fstream myfile5(file5.c_str(), ios:: out);
                    if (!myfile5)
                    {
                         myfile5.close();
                         cout << "Failed to read file in line 346\n";
                         cin >> x;
                         exit(1);
                    } 

          // close output log file
                    myfile5.close();
                    
          // put name in weight log file.
                    file6 = "";
                    ss.clear();
                    ss << countnodes;
                    ss >> file6;
                    file6 = file6 + wext;
                    
          // declare weight file.
          // open weight file.
          // create weight file.
                    fstream myfile6(file6.c_str(), ios:: out);
                    if (!myfile6)
                    {
                         myfile6.close();
                         cout << "Failed to read file in line 368\n";
                         cin >> x;
                         exit(1);
                    } 


          // close weight file.
                    myfile6.close();
                    

          // put name in data base file.
                    file7 = "";
                    ss.clear();
                    ss << countnodes;
                    ss >> file7;
                    file7 = file7 + dext;
          
          // declare data base file
          // open data base file
          // create data base file
                    fstream myfile7(file7.c_str(), ios:: out);
                    if (!myfile7)
                    {
                         myfile7.close();
                         cout << "Failed to read file in line 392\n";
                         cin >> x;
                         exit(1);
                    } 

          // close data base file
                    myfile7.close();
                          
          // put name in threshold file
                    file8 = "";
                    ss.clear();
                    ss << countnodes;
                    ss >> file8;
                    file8 = file8 + text;
          
          // declare threshold file
          // open threshold file
          // create threshold file
                    fstream myfile8(file8.c_str(), ios:: out);
                    if (!myfile8)
                    {
                         myfile8.close();
                         cout << "Failed to read file in line 414\n";
                         cin >> x;
                         exit(1);
                    } 
          
          // close threshold file
                    myfile8.close();

     // end nodes loop start
            } while (nodes < maxnodes);
// end layers loop start                      
          } while (layers < maxlayers); 
     } 
     
     if (choice=='2') 
     {
// ask user how many neurons in this network
// ask how many input nodes
// ask how many output nodes
// create master neural net file
// set nodes to zero
     // count nodes loop start
          // increment node count
          // putting in file one string
          // declare master files
          // open master files
          // create Write master files
          // 1. list node type, how many input nodes, how many output nodes
          // close 1
          // 2. input nodes list. WILL INCLUDE EVERY NODE IN THE ENTIRE NETWORK EXCEPT ITSELF
          // close 2
          // 3. output nodes list. WILL INCLUDE EVERY NODE IN THE ENTIRE NETWORK EXCEPT ITSELF
          // close 3
          // declare input file
          // open open input file
          // create input file
          // close input file
          // declare output file
          // open output file
          // create output file
          // close output file
          // declare weight file
          // open weight file
          // create weight file
          // close weight file
          // declare data base file
          // open data base file
          // write data base file
          // close data base file
          // declare threshold file
          // open threshold file
          // write threshold file
          // close threshold file
     // end nodes loop start
     }
     
     if (choice=='3') // This reads a file and creates the network according to the file.
     {

// open custom file.
// Read master neural net file and create it
// start main loop
// Read custom file and write files according to its paramaters
   // NODE NAME, NODE TYPE, TOTAL INPUTS, TOTAL OUTPUTS, INPUT LIST, OUTPUT LIST
// declare master files
          // open master files
          // create Write master files
          // 1. list node type, how many input nodes, how many output nodes
          // close 1
          // 2. input nodes list. example 1, 2, 3
          // close 2
          // 3. output nodes list. example 5, 6, 7  
          // close 3
          // declare input file
          // open open input file
          // create input file
          // close input file
          // declare output file
          // open output file
          // create output file
          // close output file
          // declare weight file
          // open weight file
          // create weight file
          // close weight file
          // declare data base file
          // open data base file
          // write data base file
          // close data base file
          // declare threshold file
          // open threshold file
          // write threshold file
          // close threshold file
// repeat main loop till end of file.                       
     
     }
     
     exit(0);
     
      
     
     
     
     





}         
