// This program generates a weight file for use with calculating strong check-sums
// Copyright (C) 2016 http://time-travel.institute
// NOTE TO PROGRAMMER - LATER SET THIS UP TO RUN WITH COMMAND LINE PARAMETERS.
// ============================================================================================
 // declare includes
     #include <cstdlib>
     #include <iostream>
     #include <stdlib.h>
     #include <fstream>
     #include <sstream>
     #include <string> 
     #include <cmath>
     #include <ctime>
     #include <cstdio>
     #include <iostream>
// ============================================================================================
    // Declare namespace
    using namespace std;
// ============================================================================================     
    // declare globals
// ============================================================================================     
// declare subs
// This is where all the work is done to make the program run.
// ============================================================================================
// declare main
    int main (int argc, char *argv[])
    { 
//              weight1 = (a * k + c) % (int)999999999;
//              decimal = (a * k + c) % (int)6
//               k = filesize2 = (rand() % 429940833); 

         // declare variables
         long long a = 3;
         long long c = 2361;
         long long m = 999999;
         long long k = 0;
         long long r = 0;
         long long filesize;
         char pause;
         srand((unsigned int) 5654940);
         time_t seconds;
         long long howmanyweights;
         long long count1 = 0;
         long long count2 = 0;
         long double weight2 = 0;
         int decimal = 0;
         int weight1 = 0;
// ============================================================================================
// test subs here

// ============================================================================================
         // Run program
// Ask user how many weights
         cout << "How many weights do we need today" << "\n";
         cin >> howmanyweights; 
// open weight file
         fstream c1myfile2("weights.txt", ios::out);
// start main loop
         do
         { 
              // increment count
              count1++;
// generate random weights
              time(&seconds);
              k = (rand() % 429940833);
              k = k + seconds; 
              weight1 = (a * k + c) % (int)999999999;
              decimal = (a * k + c) % (int)6;
              count2 = -1;
              weight2 = (long double)weight1;
              count2 = 0;
              do
              {
                   count2++;
                   weight2 = weight2/10;
//                   cout.precision(9);
//                   cout << weight2 << "\n";
              } while(count2 < 9);
//              decimal = 5;
//              cout << "---------------" << "\n";
              count2 = 0;
              do
              {
                   count2++;
                   weight2 = weight2/10;
              } while(count2 < decimal); 
//              cout.precision(15);
//              cout << weight2 << "\n";
// write weight to file
              c1myfile2.precision(16);
              c1myfile2 << weight2 << "\n";
// repeat for how many weights
         } while(count1 < howmanyweights);
        // close weaksums.txt
         c1myfile2.close();
         c1myfile2.clear();
         c1myfile2.flush();
// EXIT PROGRAM
         exit(0); 
    }     

