// ============================================================================================
//  Program description
//  This program makes a configure file for counter12.cpp from a known program for testing and backup.
//  WARNING YOU MUST USE GENERATEWEIGHTS.CPP FROM RANDOM NUMBER GENERATES BEFORE USING THIS. IT MAKES A FILE THIS PROGRAM NEEDS.
// ============================================================================================
//  Copyright
//  COPYRIGHT(C) 2017 http://time-travel.institute
// ============================================================================================
//  declare common includes
    #include <cstdlib>
    #include <iostream>
    #include <stdlib.h>
    #include <fstream>
    #include <sstream>
    #include <string> 
    #include <cmath>
    #include <ctime>
    #include <cstdio>
    #include <iostream>
// ============================================================================================
//  Include personal header files
    #include "timecheckhacking.h"
// ============================================================================================
    // Declare namespace
    using namespace std;
// ============================================================================================     
//  declare globals 
// ============================================================================================     
//  declare subs
// ============================================================================================
//  declare main
int main (int argc, char *argv[])
{
// ============================================================================================
//  declare variables
    string file1;
    int buffersize;
    long long howmanyweightedsums;
    long long filesize1;
    long double targetstrongchecksum;
// ============================================================================================
//  Test subs and functions here
// ============================================================================================  
//  pass commandline arguments
//  nameofprogram nameoffile buffersize howmanyweightedsums
    file1 = argv[1];
    buffersize = atoi( argv[2]); // How many bytes we are reading at a time.
    howmanyweightedsums = strtoull(argv[3],NULL,10); // This is how many files we are building to day.
// ============================================================================================  
//  Run program
    filesize1 = filesize(file1);

    targetstrongchecksum = getstrongchecksum(file1, howmanyweightedsums, buffersize);
    weakchecksum = getweakchecksum(buffersize, file1);

    // Load configure file
    fstream c1myfile("config.txt", ios::out);
    c1myfile <<  "Name " << "of " << "file. " << file1 << "\n";
    // set precision
    c1myfile.precision(36);
    // strong check sum
    c1myfile <<  "Target " << "strong " << "check-sum. " << targetstrongchecksum << "\n";
    // write file size
    c1myfile <<  "Size " << "of " << "file. " << filesize1 << "\n";
    // write how many weights
    c1myfile <<  "How " << "many " << "weighted " << "sums. " << howmanyweightedsums << "\n";
    // write buffersize
    c1myfile <<  "Buffer " << "size. " << buffersize << "\n";
    // write weak check-sum 
    c1myfile <<  "Weak " << "Check-sum " << weakchecksum << "\n";
    // close configure file
    c1myfile.close();
    c1myfile.clear();
    c1myfile.flush();
// ============================================================================================  
//  End program
    exit(0);
// ============================================================================================
}
