// this is firecodes renamed
// Get orginal outline and put it here with fire codes
// menu
// Get regression line and standard deviation of known files
// Generate whole file from strong check sum
// Generate config files for fire codes
// COPYRIGHT (C) 2016 Lloyd Burris
// Check sum hacking is a method of constructing computer files with there check sums.
// to compile g++ ./firecodes.cpp -o firecodes

#include <cstdlib>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <string> 
#include <cmath>
#include <ctime>
#include <cstdio>
#include <iostream>
#include </home/reactor1967/mersennetwister.h> // This is a dependancy.

using namespace std;

// ---------------------------------
// code example - KEEP THIS HERE.
//    count2 = 0;
//    do
//    {
//         std::stringstream ss;
//         count2++;
//         ss << count2;
//         ss >> file1;
//         file2 = file2 + ".bin";
//         cout << file2 << "\n";
//    } while(count2 < 10);
// ---------------------------------


// sub-routines

// =========================================================================================================
int babysumconfig2(string file1, long long filesize1, long long howmanyweightedsums, string file2, long long password2)
{
     // declare variables
     string pause;
     long long count1 = 0;
     long long count2 = 0;
     long long count3 = 0;
     int buffersize = 1;
     MTRand mtrand1a( 5654940 );
     long double babysum = 0;  
     unsigned char buffer;
     long double adultsum = 0;
     long long begin1;
     long double x1 = 0;
     ofstream c1myfile;
     int byte1 = 0;
     int byte2 = 0;
     int byte3 = 0;
     int byte4 = 0;
     long double destinationbabysum;
     long long weaksum = 0;
     long long filesize2 = 0;


     // open file1 of computer file to reconstruct
     fstream myfile1(file1.c_str(), ios:: in | ios:: binary);
     if (!myfile1)
     {
          cout << "Error in line 314 view file.\n";
          cin >> pause;
          myfile1.close();
          myfile1.clear();
          myfile1.flush();
          exit(1); // terminate with error
     }

     // open file2 config file for append     
     c1myfile.open(file2.c_str(),ios::app); 
     if (!c1myfile)
     {
          cout << "Unable to open file line 77\n";
          cin >> pause;
          // close configure file
          c1myfile.close();
          c1myfile.clear();
          c1myfile.flush();
          exit(1); // terminate with error
     }

     // count1 = 0;
     count1 = -1;
 
     // start main loop 
     do
     {   
          // babysum = 0;
          babysum = 0;
          // set seed for random number generator
          // get seed
          mtrand1a.seed(password2);

          // Set bytes and carry to zero
          byte1 = 0; byte2 = 0; byte3 = 0; byte4 = 0;

          // set destinationbabysum to 0
          destinationbabysum = 0;
  
          // set weaksum to 0
          weaksum = 0;

          // set weaksum to 0
          filesize2 = 0;

          // read byte1
          // count1++;
          count1++; // for file position
          myfile1.seekg(count1);
          myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellg();
          byte1 = (int)buffer;
          filesize2++;
          weaksum = weaksum + byte1;
          if (count1 == filesize1 - 1) // for when we have a partial counter
          {
               goto Jump1;
          }


          // read byte2
          // count1++;
          count1++; // for file position
          myfile1.seekg(count1);
          myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellg();
          byte2 = (int)buffer;
          filesize2++;
          weaksum = weaksum + byte2;
          if (count1 == filesize1 - 1) // for when we have a partial counter
          {
               goto Jump1;
          }

          // read byte3
          // count1++;
          count1++; // for file position
          myfile1.seekg(count1);
          myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellg();
          byte3 = (int)buffer;
          filesize2++;
          weaksum = weaksum + byte3;
          if (count1 == filesize1 - 1) // for when we have a partial counter
          {
               goto Jump1;
          }

          // read byte4
          // count1++;
          count1++; // for file position
          myfile1.seekg(count1);
          myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellg();
          byte4 = (int)buffer;
          filesize2++;
          weaksum = weaksum + byte4;
          if (count1 == filesize1 - 1) // for when we have a partial counter
          {
               goto Jump1;
          }

          

          // Set random number seed.
          mtrand1a.seed(password2);

Jump1:
          // I did not use filesize 2 here because any byte times 0 is a 0.
          // compute baby sum for 4 bytes then exit
          count2 = 0;
          do // computing Strong check sum for byte 1 for howmanychecksums
          {
               count2++;
	       x1 = mtrand1a.randExc(.9999999);
               destinationbabysum = destinationbabysum + (byte1 * x1);
          } while(count2 < howmanyweightedsums);

          count2 = 0;
          do // computing Strong check sum for byte 1 for howmanychecksums
          {
               count2++;
	       x1 = mtrand1a.randExc(.9999999);
               destinationbabysum = destinationbabysum + (byte2 * x1);
          } while(count2 < howmanyweightedsums);

          count2 = 0;
          do // computing Strong check sum for byte 1 for howmanychecksums
          {
               count2++;
	       x1 = mtrand1a.randExc(.9999999);
               destinationbabysum = destinationbabysum + (byte3 * x1);
          } while(count2 < howmanyweightedsums);

          count2 = 0;
          do // computing Strong check sum for byte 1 for howmanychecksums
          {
               count2++;
               x1 = mtrand1a.randExc(.9999999);
               destinationbabysum = destinationbabysum + (byte4 * x1);
          } while(count2 < howmanyweightedsums);
               
          // append baby strong check sum to config file
          c1myfile.precision(36);
          c1myfile << " Strong checksum " << destinationbabysum << " Weak checksum " << weaksum << " file size " << filesize2 << "\n";

          // repeat main loop while babycounters > 1
     } while(count1 < filesize1 - 1);

     // close main file
     myfile1.close();
     myfile1.clear();
     myfile1.flush();

     // close configure file
     c1myfile.close();
     c1myfile.clear();
     c1myfile.flush();
     return(0);
// end sub
}

// =======================================================================================================

// Roll counter for reconstruction of baby sums 
int RollBabyCounters(string file1, long long filesize1, long long babycounters, long long howmanyweightedsums, string file2, long long password2)
{

   // declare variables
     long long count1 = 0;
     long long count2 = 0;
     int byte1 = 0;
     int byte2 = 0;
     int byte3 = 0;
     int byte4 = 0;
     double long destinationbabysum;
     double long targetbabysum;
     MTRand mtrand1a(password2);
     long double destinationadultsum;
     long double targetadultsum;
     long long begin1;
     unsigned char buffer;
     long double x1;
     long long chevron;
     char pause;
     int buffersize = 1;
     string dummy;
     long double scksum;
     long long checksum;
     long long weaksum;
     int carry = 0;
     int abc = 0;
     int sizeoflastcounter = 0;
     long long filesize2 = 0;
     long long filesize3 = 0;    

     // Load configure file
     fstream c1myfile(file2.c_str(), ios::in);
     if (!c1myfile)
     {
          cout << "Error in line 256.\n";
          cin >> pause;
          c1myfile.close();
          c1myfile.clear();
          c1myfile.flush();
     }

     // read name of file
     c1myfile >>  dummy >> dummy >> dummy >> file1;
     // read weak check sum
     c1myfile >>  dummy >> dummy >> checksum;
     // read strong check sum 
     c1myfile >>  dummy >> dummy >> scksum;
     // read file size
     c1myfile >>  dummy >> dummy >> dummy >> filesize1;
     // read how many weights
     c1myfile >>  dummy >> dummy >> dummy>> dummy >> dummy >> howmanyweightedsums;
     // How Many Baby Counters Used
     c1myfile >>  dummy >> dummy >> dummy>> dummy >> dummy >> babycounters;
     // Size of Last Counter
     c1myfile >>  dummy >> dummy >> dummy>> dummy >> sizeoflastcounter;

     // open counter file
     fstream myfile1(file1.c_str(), ios:: out | ios:: binary);
     if (!myfile1)
     {
          cout << "Error in line 209 view file.\n";
          cin >> pause;
          myfile1.close();
          myfile1.clear();
          myfile1.flush();
          exit(1); // terminate with error
     }

     // adultsum = 0; 
     targetadultsum = 0;

     // babysum = 0; 
     targetbabysum = 0;
     // set CHEVRON to zero
     chevron = 0;

     // Set count1 for writing bytes to file
     count1 = -1;      
     // start second loop
     do // Read baby check sum
     {
          // read check sum from list
          c1myfile >>  dummy >> dummy >> targetbabysum >> dummy >> dummy >> weaksum >> dummy >> dummy >> filesize2;
          
         // set file size 3 for construction of weak sum in counter
          filesize3 = filesize2;

          // Set bytes and carry to zero
//        byte1 = 64; byte2 = 66; byte3 = 67; byte4 = 10; carry = 0;                    
          byte1 = 0; byte2 = 0; byte3 = 0; byte4 = 0; carry = 0;
          
          if (filesize3 > 0)
          {
               if (weaksum >= 255)
               {
                    byte1 = 255;
                    weaksum = weaksum - 255;
                    filesize3--;
               }
               else
               {
                    byte1 = weaksum;
                    weaksum = 0;
                    filesize3--;
               }                      

          }

          if (filesize3 > 0)
          {
               if (weaksum >= 255)
               {
                    byte2 = 255;
                    weaksum = weaksum - 255;
                    filesize3--;
               }
               else
               {
                    byte2 = weaksum;
                    weaksum = 0;
                    filesize3--;
               }                      

          }

          if (filesize3 > 0)
          {
               if (weaksum >= 255)
               {
                    byte3 = 255;
                    weaksum = weaksum - 255;
                    filesize3--;
               }
               else
               {
                    byte3 = weaksum;
                    weaksum = 0;
                    filesize3--;
               }                      

          }

          if (filesize3 > 0)
          {
               if (weaksum >= 255)
               {
                    byte4 = 255;
                    weaksum = weaksum - 255;
                    filesize3--;
               }
               else
               {
                    byte4 = weaksum;
                    weaksum = 0;
                    filesize3--;
               }                      

          }      
          
          // start third loop
          do // Construct baby check sum
          { 
               filesize3 = filesize2;

               // run counter for 4 bytes then exit
               if (filesize3 > 0)
               {
                    filesize3--;
                    byte1 = byte1 + 255;
                    if (byte1 > 255)
                    {
                         carry = 1;
                         byte1 = byte1 - 256;
                    }
                    else
                    {
                         carry = 0;
                    }
               }   

               if (filesize3 > 0)
               {

                    filesize3--;
                    if (carry == 1)
                    {
                         byte2++;
                         carry = 0;
                         if (byte2 > 255)
                         {
                              byte2 = byte2 - 256;
                              carry = 1;
                         }
                    }
               }

               if (filesize3 > 0)
               {
                    if (carry == 1)
                    {
                         filesize3--;
                         byte3++;
                         carry = 0;
                         if (byte3 > 255)
                         {
                              byte3 = byte3 - 256;
                              carry = 1;
                         }
                    }
               }

               if (filesize3 > 0)
               {

                    if (carry == 1)
                    {
                         filesize3 = 0;
                         byte4++;
                         carry = 0;
                         if (byte4 > 255)
                         {
                              byte4 = byte4 - 256;
                              carry = 0; // We don't advance carry anymore. Counter can roll over.
                         }
                    }
               }  
               
               // Set random number seed.
               mtrand1a.seed(password2);

               // set destinationsum to 0
               destinationbabysum = 0;

              // set filesize 3 again
              filesize3 = filesize2;

               // compute baby sum for 4 bytes then exit
               if (filesize3 > 0)
               {
                    filesize3--;
                    count2 = 0;
	            do // computing Strong check sum for byte 1 for howmanychecksums
                    {
                         count2++;
		         x1 = mtrand1a.randExc(.9999999);
                         destinationbabysum = destinationbabysum + (byte1 * x1);
                    } while(count2 < howmanyweightedsums);
               }
      
               if (filesize3 > 0)
               {
                    filesize3--;
                    count2 = 0;
	            do // computing Strong check sum for byte 1 for howmanychecksums
                    {
                         count2++;
		         x1 = mtrand1a.randExc(.9999999);
                         destinationbabysum = destinationbabysum + (byte2 * x1);
                    } while(count2 < howmanyweightedsums);
               }

               if (filesize3 > 0)
               {

                    filesize3--;
                    count2 = 0;
	            do // computing Strong check sum for byte 1 for howmanychecksums
                    {
                         count2++;
		         x1 = mtrand1a.randExc(.9999999);
                         destinationbabysum = destinationbabysum + (byte3 * x1);
                    } while(count2 < howmanyweightedsums);
               }
               
               if (filesize3 > 0)
               {
                    filesize3--;
                    count2 = 0;
	            do // computing Strong check sum for byte 1 for howmanychecksums
                    {
                         count2++;
		         x1 = mtrand1a.randExc(.9999999);
                         destinationbabysum = destinationbabysum + (byte4 * x1);
                    } while(count2 < howmanyweightedsums);
               }                     

               // End loop when baby check sum constructed
          } while(destinationbabysum != targetbabysum);
jump:
         
         // set filesize 3
         filesize3 = filesize2;

         if (filesize3 > 0)
         {
              // decrement filesize3
              filesize3--;
              // write byte1, byte2, byte3, byte4 to counter file 
              count1++;
              buffer = (unsigned char)byte1;
              myfile1.seekp(count1);
              myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
              begin1 = myfile1.tellp();
              if (count1 == filesize1 - 1) // for when we have a partial counter
              {
                   break;
              }
          }

         if (filesize3 > 0)
         {
              // decrement filesize 3
              filesize3--;
              // write byte1, byte2, byte3, byte4 to counter file 
              count1++;
              buffer = (unsigned char)byte2;
              myfile1.seekp(count1);
              myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
              begin1 = myfile1.tellp();
              if (count1 == filesize1 - 1) // for when we have a partial counter
              {
                   break;
              }
         }
         
         if (filesize3 > 0)
         {
              // decrement filesize 3
              filesize3--;
         
              // write byte1, byte2, byte3, byte4 to counter file 
              count1++;
              buffer = (unsigned char)byte3;
              myfile1.seekp(count1);
              myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
              begin1 = myfile1.tellp();
              if (count1 == filesize1 - 1) // for when we have a partial counter
              {
                  break;
              }
         }
         
         if (filesize3 > 0)
         {
              // decrement filesize 3
              filesize3--;
         
              // write byte1, byte2, byte3, byte4 to counter file 
              count1++;
              buffer = (unsigned char)byte4;
              myfile1.seekp(count1);
              myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
              begin1 = myfile1.tellp();
              if (count1 == filesize1 - 1) // for when we have a partial counter
              {
                   break;
              }
         }
         
         // increment CHEVRON
         chevron++;

         // PRINT TO USER CHEVRON NUMBER # LOCKED    
         cout << " Chevron Number " << chevron << " Locked " << "\n";                 
         // end second loop when all babysums constructed

    } while(count1 < filesize1 - 1);  
    myfile1.close();
    myfile1.clear();
    myfile1.flush();
    c1myfile.close();
    c1myfile.clear();
    c1myfile.flush();

    cout << " FILE RECONSTRUCTED!!! " << "\n";
    cin >> pause;
    return(0);    
// end sub
}

// ============================================================================================================

// int viewfile1
// ==========================================================================
int viewfile1(string file1, long long filesize1, int buffersize)
{
// declare variables
     int count = -1;
	 int byte1 = 0;
     long long begin1 = 0;
	 unsigned char buffer(buffersize);
	 string pause;
// open file 1
     fstream myfile1(file1.c_str(), ios:: in | ios:: binary);
     if (!myfile1)
     {
          cout << "Error in line 314 view file.\n";
          cin >> pause;
          myfile1.close();
          myfile1.clear();
          myfile1.flush();
	  exit(1); // terminate with error
     }
// read file view output   
     do
     {
          count++;

         // read file 1
          myfile1.seekg(count);
          myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellg();
          byte1 = (int)buffer;
	  cout << " count " << count << " " << " byte " << byte1 << "\n";

      } while (count < filesize1 - 1);


// close file1
// close file2
      myfile1.close();
      myfile1.clear();
      myfile1.flush();

      return(0);
}

// ============================================================================================================

int createcounterfile(string file1, long long checksum, long long filesize1)
{
// delcare variables
     string pause;
     int byte = 0;
     int count = 0;
     int weak1 = checksum;
     int test = 0;
     unsigned char buffer;
     int buffersize = 1;
     long long begin1 = 0;

    // open file1
     fstream myfile1(file1.c_str(), ios::out | ios::binary);
     if (!myfile1)
     {
          myfile1.close();
          cout << "Failed to read file one Line 141.\n";
          cin >> pause;
          exit(1);
     }
     myfile1.close();
     myfile1.clear();
     myfile1.flush();
     return(0);
}

// ============================================================================================================

// long double getstrongchecksum1 (for random strong check sums)
long double getstrongchecksum1(string file1, int buffersize, int howmanyweightedsums, long long password2)
{
//   cout << "Getting weighted check sum\n";
//   declare variables
     long double schecksum;
     int byte1 = 0;
     long long count = -1;
     long long count2 = 0;
     long long filesize1 = 0;
     long long begin1 = 0;
     long long end1 = 0;
     long long seednumber = 0;
     unsigned char buffer(buffersize);
     long double x1 = 0;
     MTRand mtrand1a(password2);
     string pause;
     

     // open file1
     fstream myfile1(file1.c_str(), ios::in | ios::binary);
     if (!myfile1)
     {
          myfile1.close();
          cout << "Failed to read file one line 178.\n";
          cin >> pause;
          exit(1);
     }

// get filesize1
     begin1 = myfile1.tellg();
     if (!myfile1)
     {
          myfile1.close();
          cout << "Failed to read file one line 188.\n";
          cin >> pause;
          exit(1);
     }
     myfile1.seekg (0, ios::end);
     end1 = myfile1.tellg();
     filesize1 = (end1-begin1);

// get seed
     mtrand1a.seed(password2);
// set count to 0
     count = 0;
// set strong check sum to 0
     schecksum = 0;
// start first loop
     do
     {
// set byte to 0
          byte1 = 0;
// read file1
          myfile1.seekg(count);
          myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellg();
          byte1 = (int)buffer;
// set count2 to 0
          count2 = 0;
// start second loop
          do
          {
// increment count2
               count2++;
// using random number generator get weight
	       x1 = mtrand1a.randExc(.9999999);
// calulate strong check sum
               schecksum = schecksum + (byte1 * x1);
// end second loop for count2 < how many weighted sums
          } while(count2 < howmanyweightedsums);
// count = count + buffer size
	  count++;
// end first loop for count < filesize1 - 1 + buffersize
     } while (count < filesize1 - 1);
// close files
     myfile1.close();
     myfile1.clear();
     myfile1.flush();
// return checksum
     return(schecksum);
// end sub
}

// ============================================================================================================

// long long weakchecksum
long long weakchecksum(string file1, int buffersize) // For some reason will not take buffer size. Debug - FOR NOW MANUALLY ENTER BUFFER SIZE THEN COMPILE.
{
// declare variables
     fstream myfile1;
     int x;
     int buffersize2 = buffersize;
     long long checksum = 0;
     long long begin1;
     long long count1;
     long long count2;
     unsigned char buffer(buffersize2);
     long long size1;
     long long size2;
     long long filesize;
     string pause;
// open file1
     myfile1.open(file1.c_str(), ios:: in | ios:: binary);
     if (!myfile1)
     {
          cout << "122608-12:02 am Unable to open file.\n";
          cin >> pause;
          exit(1); // terminate with error
     }
// get file size
     myfile1.seekg(0, ios::beg);
     size1 = myfile1.tellg();
     myfile1.seekg(0, ios::end);
     size2 = myfile1.tellg();
     filesize = size2 - size1;
// set count1 to 0
     count1 = 0;
// start first loop
     do
     {
// read byte
          begin1 = myfile1.tellg();
          myfile1.seekg(count1);
          if (!myfile1)
          {
               myfile1.close();
               cout << "error in line 51.\n";
               cin >> pause;
               exit(1);
          }
          myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
          x = (int)buffer;
// calculate weak check sum
          checksum = checksum + x;
// count1 = count1 + buffersize2
          count1 = count1 + buffersize2;
// end first loop while (count1 < ((filesize - 1) + buffersize2))
     } while (count1 <  ( ( filesize - 1 ) + buffersize2 ) );

// close files
     myfile1.close();
     myfile1.clear();
     myfile1.flush();

// return checksum
     return(checksum);
// end sub
}

// ============================================================================================================

// long long filesize
long long filesize(string file1)
{
//    cout << "Get file size.\n";
// declare variables
    long long begin1;
    long long end1;
    long long filesize1;
    string pause;

    // open file1
     fstream myfile1(file1.c_str(), ios::in | ios::binary);
     if (!myfile1)
     {
          myfile1.close();
          cout << "Failed to read file line 856" << "\n";
          cin >> pause;
          exit(1);
     }

// get filesize1
     begin1 = myfile1.tellg();
     if (!myfile1)
     {
          myfile1.close();
          cout << "Failed to read file one line 866." << "\n";
          cin >> pause;
          exit(1);
     }
     myfile1.seekg (0, ios::end);
     end1 = myfile1.tellg();
     filesize1 = (end1-begin1);

// close file 1
     myfile1.close();
     myfile1.clear();
     myfile1.flush();
// return filesize
     return(filesize1);
// end sub
}

// ============================================================================================================

// Start main
int main (int argc, char *argv[])
{

// Declare variables (Delete all these variables and compile to find out what needed and what not).
    string pause;
    long double scksum = 0;
    long long checksum = 0;
    int buffersize = 1;
    long long filesize1;
    long long howmanyweightedsums;
    char choice;
    string file1;
    long long babycounters = 0;
    int dummyfile;
    string dummy;
    int sizeoflastcounter;
    long long howmanycounters; 
    long long filesectionsize;
    long long howmanycounterstorun;
    long long count3;
    long long count4;
    long long count5;
    long long password2;
    string file2;
    string file3;
    string password;

// create menu 
    // print space
     cout << "\n";

    // 1. Recreate file from check sum.
     cout << "1. Reconstruct computer file from checksum." << "\n";

    // 2. Create a configure file for single program.
     cout << "2. Create configure file for a single file." << "\n";

    // 3. Create a configure file for single program.
     cout << "3. Create parallel bash config script to run project in parallel " << "\n";

    // 4. Create a configure file for single program.
     cout << "4. Create parallel bash run script for parallel bash config script to run project in parallel " << "\n";
// ======================================================================================================================== Starting computer time travel part of outline
    // Get regression line and standard deviation of known files
    // Generate whole file from strong check sum
    // Generate config files for fire codes



    // Enter Choice
     cin >> choice;

// if choice = 1.
     if (choice == '1')
     { 

          cout << "Please enter the name of your config file." << "\n";
          cin >> file2;

         // Get the password
         cout << "Please enter your password for this project." << "\n";
         cin >> password2;

          // Load configure file
          fstream c1myfile(file2.c_str(), ios::in);
          if (!c1myfile)
          {
               cout << "Unable to open file line 942 \n";
               cin >> pause;
               exit(1); // terminate with error
          }

          // read name of file
          c1myfile >>  dummy >> dummy >> dummy >> file1;
          // read weak check sum
          c1myfile >>  dummy >> dummy >> checksum;
          // read strong check sum 
          c1myfile >>  dummy >> dummy >> scksum;
          // read file size
          c1myfile >>  dummy >> dummy >> dummy >> filesize1;
          // read how many weights
          c1myfile >>  dummy >> dummy >> dummy>> dummy >> dummy >> howmanyweightedsums;
          // How Many Baby Counters Used
          c1myfile >>  dummy >> dummy >> dummy>> dummy >> dummy >> babycounters;
          // Size of Last Counter
          c1myfile >>  dummy >> dummy >> dummy>> dummy >> sizeoflastcounter;

         // close configure file
          c1myfile.close();
          c1myfile.clear();
          c1myfile.flush();

         // Print configure file to confirm loaded correctly
          cout << " file name > " << file1 << "\n";
          cout.precision(36);
          cout << " weak check-sum > " << checksum << "\n";
          cout.precision(36);
          cout << " strong check-sum > " << scksum << "\n";
          cout.precision(36);
          cout << " file size > " << filesize1 << "\n";
          cout.precision(36);
          cout << " how many weighted check-sums  > " << howmanyweightedsums << "\n";
          cout << " How many baby counters used > " << babycounters << "\n";
          cout << " Size of last counter > " << sizeoflastcounter << "\n";
          cout << "Is the configuration file loaded properly?" << "\n";
          cin >> pause;
//          exit(0);   

          // call roll counter (reads config file and reconstructs baby sums to counter file)          
          // start reconstruction // This constructs the computerfile from a check sum
          dummyfile = RollBabyCounters(file1, filesize1, babycounters, howmanyweightedsums, file2, password2);

// end if choice = 1;
     }

// if choice = 2
     if (choice=='2')
     {
          // Get seed for random number generator          
          // MTRand mtrand1a( 5654940 );

     // ask user file name
          cout << "Please enter the name of your target file." << "\n";
          cin >> file1;

     // Get the name of the config file
         cout << "Please enter the name of your config file." << "\n";
         cin >> file2; 

     // Get the password
         cout << "Please enter your seed number for this project." << "\n";
         cin >> password2;

     // ask how many weights to use for strong check sum
          cout << "How many weighted sums are we using?" << "\n";
          cin >> howmanyweightedsums;

     // get file size
          filesize1 = filesize(file1);

     // get weak check sum
          checksum = weakchecksum(file1,buffersize);

     // get strong check sum // Know which routine to fucking use.
          scksum = getstrongchecksum1(file1, buffersize, howmanyweightedsums, password2); 

     // Calculate baby counters
          babycounters = int((filesize1 - 1) / 4);// Change as needed here.
          if ((filesize1 - 1) - (babycounters * 4) > 0)
          {
               babycounters++;
          }

     // write to configure file
          fstream c1myfile(file2.c_str(), ios::out);
          if (!c1myfile)
          {
               cout << "Unable to open file line 1021 \n";
               cin >> pause;
               exit(1); // terminate with error
          }

          c1myfile << " Name of file " << file1 << "\n";
          c1myfile.precision(36);
          c1myfile << " Weak checksum " << checksum << "\n";
          c1myfile.precision(36);
          c1myfile << " Strong checksum " << scksum << "\n";
          c1myfile.precision(36);
          c1myfile << " Size of file " << filesize1 << "\n";
          c1myfile << " How Many Weighted Checksums used " << howmanyweightedsums << "\n";
          c1myfile << " How Many Baby Counters Used " << babycounters << "\n";
          c1myfile << " Size of Last Counter " << (filesize1 - 1) - int(((filesize1 - 1) / 4) * 4) << "\n";

          // close files
          c1myfile.close();
          c1myfile.clear();  
          c1myfile.flush();

          // call get baby check sums
          dummyfile = babysumconfig2(file1, filesize1, howmanyweightedsums, file2, password2);

          // tell user config file created  
          cout << "Config file created." << "\n";
          cin >> pause;
          // exit program
          exit(0);
     }

    if (choice == '3')
    {

          buffersize = 1; 
     // ask user file name
          cout << "Please enter the name of your target file." << "\n";
          cin >> file1;

     // ask how many weights to use for strong check sum
          cout << "How many weighted sums are we using?" << "\n";
          cin >> howmanyweightedsums;

         // get how many counters to run at a time
         cout << "How many programs to run at a time" << "\n";
         cin >> howmanycounters;

     // Get the password
         cout << "Please enter your seed number for this project." << "\n";
         cin >> password2;
         

         // get file size
         // filesize1 = filesize(file1); // I should probably delete this code.   

         // ask user to use the split command
         cout << "Please use split -b bytesizeperfile nameofyourfile." << "\n";
         cout << "Hit any key and enter when your ready." << "\n";
         cin >> pause;

         // make a list
         cout << "On the command line make sure you are in the same directory as your file." << "\n";
         cout << "Use the Terminal if needed." << "\n";
         cout << "In the command line type ls firstcharacterofsplitflies* > list.txt" << "\n";
         cout << "Hit any key and enter when ready." << "\n";
         cin >> pause;

         // open list.txt
         fstream c1myfile1("list.txt", ios::in);
         if (!c1myfile1)
         {
              cout << "Unable to open file line 996 \n";
              cin >> pause;
              exit(1); // terminate with error
         }

         // open bash script1.txt
         fstream c1myfile2("script1.sh", ios::out);
         if (!c1myfile2)
         {
              cout << "Unable to open file line 1004 \n";
              cin >> pause;
              exit(1); // terminate with error
         }
         // place this at beginning of bash script
         c1myfile2 << "#!/bin/bash" << "\n";
         // set count3 to 0
         count3 = 0;
         // set count 4 to 0
         count4 = 0;
         // set count 5 to 0
         count5 = 0;

         // start do loop
         do
         {
              count4++;
// ------------------------------------------------------- Name file 3
              std::stringstream ss;
              ss << count4;
              ss >> file3;
              file3 = file3 + ".sh";
// ------------------------------------------------------- finishing naming file 3
              // read list.txt
              c1myfile1 >> file2;
              // get size of file2
              filesectionsize = filesize(file2);

              if (!c1myfile1.eof())
              {
                   c1myfile2 <<  "./pbabysumconfig2 " << file2 << " " << filesectionsize << " " << howmanyweightedsums << " " << password2 << " &" << "\n"; 
                   // if how many counters reached write wait to bash script
                   if (count4 == howmanycounters)
                   {
                        c1myfile2 << "wait" << "\n";
                        count4 = 0;
                   }
              }
                   // repeat do loop till end of file
         } while(!c1myfile1.eof());

        c1myfile2 <<  "echo Make sure pbabysumconfig2 programs are done running before moving forward." << "\n"; 

         // delete list.txt
         system("rm list.txt");
         // close list.txt
         c1myfile1.close();
         c1myfile1.clear();  
         c1myfile1.flush();
         // close script1.txt
         c1myfile2.close();
         c1myfile2.clear();  
         c1myfile2.flush();
         // change file permissions
         system("chmod u+x script1.sh");
         cout << "You need to run script1.sh before going to step 4." << "\n";       
         exit(0); 
     } // condition 3        

    if (choice == '4')
     { 
          cout << " I am removing script1.sh " << "\n";

          cout << "\n";

          system("rm script1.sh");
     
          cout << "\n";

     // ask how many weights to use for strong check sum
          cout << "How many weighted sums are we using?" << "\n";
          cin >> howmanyweightedsums;

         // get how many counters to run at a time
         cout << "How many programs to run at a time" << "\n";
         cin >> howmanycounters;

     // Get the password
         cout << "Please enter your seed number for this project." << "\n";
         cin >> password2;

         // get how many sections
         system("ls *config > list.txt");

         // open list.txt
         fstream c1myfile1("list.txt", ios::in);
         if (!c1myfile1)
         {
              cout << "Unable to open file line 996 \n";
              cin >> pause;
              exit(1); // terminate with error
         }

         // open bash script1.txt
         fstream c1myfile2("script2.sh", ios::out);
         if (!c1myfile2)
         {
              cout << "Unable to open file line 1004 \n";
              cin >> pause;
              exit(1); // terminate with error
         }
         // place this at beginning of bash script
         c1myfile2 << "#!/bin/bash" << "\n";
         // set count3 to 0
         count3 = 0;
         // set count 4 to 0
         count4 = 0;
         // set count 5 to 0
         count5 = 0;

         // start do loop
         do
         {
              count4++;
// ------------------------------------------------------- Name file 3
//              std::stringstream ss;
//              ss << count4;
//              ss >> file3;
//              file3 = file3 + ".sh";
// ------------------------------------------------------- finishing naming file 3
              // read list.txt
              c1myfile1 >> file2;
              file1 = file2;
              file1.erase (3,7);

              if (!c1myfile1.eof())
              {
                    c1myfile2 <<  "./prollbabycounters " << file1 << " " << file2 << " " << howmanyweightedsums << " " << password2 << " &" << "\n";
                   // if how many counters reached write wait to bash script
                   if (count4 == howmanycounters)
                   {
                        c1myfile2 << "wait" << "\n";
                        count4 = 0;
                   }
              }
                   // repeat do loop till end of file
         } while(!c1myfile1.eof());
      
         c1myfile2 <<  "echo Run cat with parameters to join your files." << "\n"; 
         c1myfile2 <<  "echo Make sure prollbabycounters are done running before moving forward." << "\n";
         c1myfile2 <<  "rm script2.sh" << "\n"; 
         
         // delete list.txt
         system("rm list.txt");
         // close list.txt
         c1myfile1.close();
         c1myfile1.clear();  
         c1myfile1.flush();
         // close script1.txt
         c1myfile2.close();
         c1myfile2.clear();  
         c1myfile2.flush();
         // change file permissions
         system("chmod u+x script2.sh");
         cout << "Run script2.sh when your ready to reconstruct your file" << "\n";              
         cout << "Use cat with parameters to join your files." << "\n";
         exit(0);     
         
     } // end condition 4


// end main
}



 

