// COPYRIGHT(C) 2017 http://time-travel.institute
// This generates a configure file that can be used to setup a random number generator to find time travel computer media files
// ============================================================================================
 // declare includes
#include <cstdlib>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <string> 
#include <cmath>
#include <ctime>
#include <cstdio>
#include <iostream>
#include "basepower2.h"
// #include "generator.h"
// ============================================================================================
// Declare namespace
using namespace std;
// ==========================================================================================================================================
int codelist(long long numberbase, int buffersize)
{

// ---------------------------------
// code example - KEEP THIS HERE.
//    count2 = 0;
//    do
//    {
//         std::stringstream ss;
//         count2++;
//         ss << count2;
//         ss >> file1;
//         file2 = file2 + ".bin";
//         cout << file2 << "\n";
//    } while(count2 < 10);
// ---------------------------------

    string file1;
    string file2;
    string file3;
    int dummyfile;
    long long count2;
    char pause;

    // open list
    fstream c1myfile1("list.txt", ios::in);
    if (!c1myfile1)
    {
         cout << "There is no file list." << "\n";
         c1myfile1.close();
         c1myfile1.clear();
         c1myfile1.flush();
         exit(0);           
    }
    count2 = 0;
    // start loop
    do
    {
         // read list 
         if (!c1myfile1.eof( ))
         {
              c1myfile1 >> file1;
         }
         std::stringstream ss;
         count2++;
         ss << count2;
         file2 = "";
         ss >> file2;
         file3 = file2;
         file2 = file2 + ".chk";
         file3 = file3 + ".pwr";
//-------------------------------------------         
//         cout << file2 << "\n";
         if (!c1myfile1.eof( ))
         {
              // code file
              dummyfile = createbpchecksum(file1,numberbase, buffersize);
              rename("pbchecksum.txt", file2.c_str());
              rename("power.txt", file3.c_str());
         }
    // repeat loop till end of file
    } while(!c1myfile1.eof());
    // close list
    c1myfile1.close();
    c1myfile1.clear();
    c1myfile1.flush();
    // return
    return(0);   
}    

int main (int argc, char *argv[])
{
    // declare variables
    long long filesize1;
    long long howmanyfiles;
    long long begin1;
    long long end1;
    long long countpwr;
    long long countchk;
    long long count1;
    fstream c1myfile1;
    fstream c1myfile2;
    fstream c1myfile3;
    fstream c1myfile4;
    string low;
    string high;
    string pause;
    string file1;
    string file2;
    string file3;
    int dummyfile;
    string highfile;
    string lowfile;
    int buffersize = 1;
    long long numberbase = 99999999;
    long long dumnum;

//    //make list of sample files
//    cout << "Make your list of your sample files." << "\n";
//    cout << "On Linux ls *.yourextension > list.txt" << "\n";
//    cout << "On windows dir /b *.yourextension > list.txt" << "\n";
//    cout << "Hit any key and enter when done." << "\n";
//    cin >> pause;

    //open list and code the sample files to check-sums
    dummyfile = codelist(numberbase, buffersize);
    // exit program
    exit(0);

 }
