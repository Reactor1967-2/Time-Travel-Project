This project is still been written and upgraded but is usable right now.
Run these programs starting at step 1 then going to step 2 then step 3 and finally step 4.

In step one the first configure file looks for weak sums. This helps to determine the lowest file and the highest file. I plan to change this to something else later. Take the highest check-sum and the lowest check-sum files delete everything else. Put the highest as 1.txt and the lowest as 2.txt into a list.txt file and proceed to using config 2. It will generate power.txt files and base power check-sums for those two files.
In step the files from step one are used to generate suspected time travel media files. Step 3 decodes these files to base power check-sums. Step for is a robot you should of trained in advance from both the good files and the bad files. It will go through and delete the bad files. From there look at what you have and good luck.

This part of the project is slow and is still only suited for small files. It is possible to run this in parallel by cutting the file up working with the fragments then rejoining them at the end.

When I can I will get this upgraded and working better. In the mean time you are welcome to edit and compile my open source code to your needs.
