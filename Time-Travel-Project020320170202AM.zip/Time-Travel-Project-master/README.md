# Time-Travel-Project
Uses the science of check-sum hacking to map all computer files in space-time to a number that can be reconstructed as a computer file. Makes all computer files in space-time downloadable. This is process is called Time-Hacking or hacking space-time itself.
