This project will generate binary files from a weak check-sum.
This project is still under construction.
