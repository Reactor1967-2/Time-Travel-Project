// COPYRIGHT(C) 2017 http://time-travel.institute
// This is the cpp file use the base power counter header file.
// Base Power Counter 
// Load configure file
// Create configure file
// Encodes base power check-sum
// Decodes base power check-sum
// ============================================================================================
 // declare includes
    #include <cstdlib>
    #include <iostream>
    #include <stdlib.h>
    #include <fstream>
    #include <sstream>
    #include <string> 
    #include <cmath>
    #include <ctime>
    #include <cstdio>
    #include <iostream>
    #include "basepower2.h"

// ============================================================================================
    // Declare namespace
    using namespace std;
// ============================================================================================     
// declare subs
// ============================================================================================
// declare main
    int main (int argc, char *argv[])
    {
 
         // declare variables
         string file2;
         long long numberbase = 99999999;
         int dummyfile;
         int buffersize = 1;
         long long filesize1 = 0;
         string pause;
         long long end1;
         long long begin1;
         // declare variables
         fstream c1myfile1;
         // ASK USER TO CREATE LIST OF CHECK-SUMS TO DECODE
         cout << "Create a list.txt file of check-sums to decode";
         cin >> pause;
         // ASK USER TO SUPPLY A POWER.TXT FILE
         cout << "Make sure you have a power.txt file named powerbak.txt";
         cin >> pause;
         // ASK USER WHAT FILE SIZE ARE WE DECODING TODAY
         cout << "What file size are we decoding today?";
         cin >> filesize1;
         // OPEN LIST
         c1myfile1.open("list.txt", ios::in);
         if (!c1myfile1)
         {
              cout << "There is no file list." << "\n";
              c1myfile1.close();
              c1myfile1.clear();
              c1myfile1.flush();
              exit(0);           
         }
         // START DO LOOP
         do
         {
              // READ LIST
              file2="";
              if (!c1myfile1.eof());
              {
                   c1myfile1 >> file2;
                   rename(file2.c_str() , "pbchecksum.txt");
                   file2 = file2 + "bin";
              }
              // copy power back up file to power.txt
              system("cp powerbak.txt power.txt");
              // PAST FILE TO BE DECODED ALONG WITH NAME TO DECODED TO LIST
             cout << "Beginning Decode" << "\n";
             dummyfile = decodepbchecksum(file2, filesize1, numberbase, buffersize);
             cout << "FILE RECONSTRUCTED FROM ITS BASE POWER CHECK-SUM IN BASE 99999999!!!!" << "\n";
             system("rm pbchecksum.txt");
             system("rm power.txt");
        // REPEAT LOOP TILL END OF FILE
        } while(!c1myfile1.eof());

         
    }
