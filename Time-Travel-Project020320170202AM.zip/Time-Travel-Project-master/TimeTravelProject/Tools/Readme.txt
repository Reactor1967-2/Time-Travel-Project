buildbasepower2 is a upgrade to buildbasepower
