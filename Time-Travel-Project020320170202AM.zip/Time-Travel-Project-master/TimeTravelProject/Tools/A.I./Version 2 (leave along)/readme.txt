Use run.ann as a text file to runann.exe from a text file.
Use training.ann as a text file for trainann.exe
Can use runann.exe with input from a keyboard.

training.ann example - input output
                       input output

runann.ann example - inputonly

Then after training enter input from keyboard or file and
the input as a text file or binary file.