This project converts a binary file to a text file in a number base that is (256^buffersize) + 1
and converts a text file in a number base back to a binary file. By making text files as a 1 column
list of numbers from 0 to 256^buffersize you have access to every computer file within space-time.
All you have to do is create the text file with the number of the computer file you want in a buffer size
and decode to a binary file. I have tested this and it does work.
Einstein said all space-time exist at the same time. So all computer files exist at the same time.
These programs give you access to all computer files within space-time.
