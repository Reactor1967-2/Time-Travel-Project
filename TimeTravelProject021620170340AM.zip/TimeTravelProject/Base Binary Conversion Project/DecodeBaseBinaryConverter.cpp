// COPYRIGHT(C) http://time-travel.institute
// When making number list for this program to decode time travel media
// The base is (256^buffersize) + 1.
// So the numbers you will use is from 0 to 256^buffersize for the max size number you can have.
// You have to tell this program the size of the file you are creating.
// This program gives you access to every computer file that exist in space-time.
// Create the number in a text file you want to decode as a binary file.
// ============================================================================================
// Declare includes
#include <cstdlib>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <string> 
#include <cmath>
#include <ctime>
#include <cstdio>
#include <iostream>
// #include "timecheckhacking2.h"
// ============================================================================================
// Declare namespace
using namespace std;
// ============================================================================================     
// declare subs
// ============================================================================================
long long binaryreadwrite(string whatdo, string file1, long long byteposition, long long byte, long long buffersize)
{

     long long buffer = 8192;
     char pause;
     long long byte1 = byte;
     long long count1 = byteposition;
     long long begin1;    
     
       
     // open file
      fstream myfile1(file1.c_str(), ios::out  | ios::in | ios::binary);
     if (!myfile1)
     {
          myfile1.close();
          cout << "error in line 266" << " " << file1 << "\n";
          cin >> pause;
          exit(1);
     }
     if (whatdo == "read")
     {
// cout << byte1 << " We are reading bytes " << "\n"; // debug code
          myfile1.seekg(count1);
          myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellg();
          byte1 = buffer;
          myfile1.close();
          myfile1.clear();
          myfile1.flush();
          return(byte1);
     }
     if (whatdo == "write")
     {
// cout << byte1 << " We are writing bytes " << "\n"; // debug code
          buffer = byte1;
          myfile1.seekp(count1);
          myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellp();
          myfile1.close();
          myfile1.clear();
          myfile1.flush();
          return(0);
     } 
     

     cout << "Error in binary read and write" << "\n";
     cin >> pause;
     exit(1);
}
// ============================================================================================
// declare main
int main (int argc, char *argv[])
{
    // Declare variables
    long long count1;
    string dummyfile;
    string file1;
    string file2;
    long long pbnum2;
    long long byte;
    long long buffersize;
    string pause;
    string whatdo;
    long long filesize1;

    // Get command line arguments
    // ./program name // name of file to create // filesize creating // buffersize // get name of number file containing base number
     file1 = argv[1];
     filesize1 = strtoull(argv[2],NULL,10);
     buffersize = atoi( argv[3]); // How many bytes we are reading at a time.
     file2 = argv[4];

    // CREATE BINARY FILE WRITING TO WITH 0 SIZE and close it
    fstream myfile1(file1.c_str(), ios::out  | ios::binary);
    if (!myfile1)
    {
         myfile1.close();
         cout << "error in line 87" << " " << file1 << "\n";
         cin >> pause;
         exit(1);
    }
    myfile1.close();
    myfile1.clear();
    myfile1.flush();


    // open text file
    fstream c1myfile1(file2.c_str(), ios::in);
    if (!c1myfile1)
    {
         cout << "There is no file list." << "\n";
         c1myfile1.close();
         c1myfile1.clear();
         c1myfile1.flush();
         exit(0);           
    }


    // set count1 to buffersize * -1
    count1 = buffersize * -1;

    // Start do loop
    do
    {

         // increment count1 + buffersize
         if (!c1myfile1.eof())
         {
              count1 = count1 + buffersize; 
         }

         pbnum2 = 0;
         if (!c1myfile1.eof())
         {
               // read text file pbnum2
              c1myfile1 >> pbnum2;
              cout << pbnum2 << "\n";
         }
         if (pbnum2 == -1)
         {
              break;
         } 
         if (!c1myfile1.eof())
         {
              // call program to convert pbnum2 and write to binary file
              // dummyfile = createdestinationfile(file1, buffersize, pbnum2, count1);
              byte = pbnum2;
              whatdo = "write";
              dummyfile = binaryreadwrite(whatdo, file1, count1, byte, buffersize);

         }
      } while (count1 < filesize1 - buffersize);
//    } while(!c1myfile1.eof()); // This creates one extra loop so had to put in the file size.

    c1myfile1.close();
    c1myfile1.clear();
    c1myfile1.flush();

    // Exit program
    exit(0);
}
