I have written some programs for generating weights for strong check-sums and for generating random numbers for the programs that need a seed file and or a random number file. Linux has /dev/random and /dev/urandom. /dev random blocks when it is out of entropy but dev/urandom does not block it will keep running even when its results are not suitable for random numbers.

So, I have added some third party programs that will help keep your random devices filled with entropy. 

Other than that there are some TRNG generators that you can buy and plug into your computer for random numbers.

At Random.org you can download numbers to use as random numbers or as seed for random numbers.

I currently don't have any programs that directly access /dev/random. I used the c++ random number generators and made my on.

To access /dev/random use this for now.

It's a file like device, so you can do things like cat it or copy from it. For instance:

dd if=/dev/urandom of=~/urandom_test count=4 bs=1024

Creates a file containing 4K of random bytes.

cat /dev/urandom > ~/urandom_test2 

Will continue to write random bytes to that file until you hit Ctrl-C. Don't do this on a low performing system...

head -30 /dev/urandom > ~/urandom_test3

Will write 30 lines of random bytes

From there a c++ program can be written to access the /dev/random file.

To get random binary files use cat /dev/random/ > Random.bin
Then use split -b bytesizeperfile nameofyourfile to split these files up.

You can use the base to binary programs to decode a text to a binary or code a binary to a random number text file.


Good luck.
