Fire codes takes files in a special format as check-sums then decodes them to binary files.
You would have to use the other projects to find such files or use fire codes to code the known files
before using it to decode.
