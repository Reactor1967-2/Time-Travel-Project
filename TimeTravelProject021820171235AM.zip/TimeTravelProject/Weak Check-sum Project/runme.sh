#!/bin/bash

g++ weakcheck-sumcounter.cpp -o weakcheck-sumcounter
g++ binaryfilegenerator.cpp -o binaryfilegenerator
g++ BinaryGeneratorAdd.cpp -o BinaryGeneratorAdd
g++ BinaryGeneratorSubtract.cpp -o BinaryGeneratorSubtract

