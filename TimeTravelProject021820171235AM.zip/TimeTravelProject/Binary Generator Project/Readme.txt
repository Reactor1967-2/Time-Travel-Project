This project works by getting a destination file. Then using true random numbers generate difference files of varying file sizes. 

Run the time scanner to construct the target files within the ranges of the difference files. The time scanner will add or subtract the difference files from the target files. 

When enough targets have been constructed use a higher or lower destination file and repeat. You can use a differece file and add it or subtract it from the destination file to move the destination file up or down.

By moving the destination file up and down and constructing the
differences around that destination file we are scanning space-time for computer files. 

To get difference files it is best to use true random numbers. Create a random.bin file with this command in Linux:
cat /dev/random > random.bin

Next to get difference files use the split command:
split -b sizeoffilesneeded nameofrandom.bin prefexofdifffiles

You can rename one of the difference files as your destination file.

Once you have the difference files and the destination file run the timescanner and use one of the robots to sift through the time travel media files.

if you want to use the binary file generator you can. That is up to you. You can use the base conversion code program to convert random.bin to a seed file.

Happy "Time-Hacking"

Reactor1967
