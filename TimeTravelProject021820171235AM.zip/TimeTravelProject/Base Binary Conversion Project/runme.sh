#!/bin/bash

g++ differencefilescreater.cpp -o differencefilescreater
g++ BCtimescanner.cpp -o BCtimescanner
g++ CodeBaseBinaryConverter.cpp -o CodeBaseBinaryConverter
g++ DecodeBaseBinaryConverter.cpp -o DecodeBaseBinaryConverter


