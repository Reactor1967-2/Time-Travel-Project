// ============================================================================================
// Declare includes
#include <cstdlib>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <string> 
#include <cmath>
#include <ctime>
#include <cstdio>
#include <iostream>
// #include "timecheckhacking2.h"
// ============================================================================================
// Declare namespace
using namespace std;
// ============================================================================================     
// declare subs
// ============================================================================================
long long filesize(string file1)
{
// declare variables
    long long begin1;
    long long end1;
    long long filesize1;
    string pause;  
//    string file1 = globalfile;
      
    // open file1
     fstream myfile1(file1.c_str(), ios::in | ios::binary);
     if (!myfile1)
     {
          myfile1.close();
          cout << "Failed to read file one line 134.\n";
          cin >> pause;
          exit(1);
     }

// get filesize1
     begin1 = myfile1.tellg();
     if (!myfile1)
     {
          myfile1.close();
          cout << "Failed to read file one line 316.\n";
          cin >> pause;
          exit(1);
     }
     myfile1.seekg (0, ios::end);
     end1 = myfile1.tellg();
     filesize1 = (end1-begin1);     

// close file 1
     myfile1.close();
     myfile1.clear();
     myfile1.flush();

// return filesize
     return(filesize1);
// end sub
}
// ============================================================================================
long long binaryreadwrite(string whatdo, string file1, long long byteposition, long long byte, long long buffersize)
{

     long long buffer = 8192;
     char pause;
     long long byte1 = byte;
     long long count1 = byteposition;
     long long begin1;
     
       
     // open file
      fstream myfile1(file1.c_str(), ios::out  | ios::in | ios::binary);
     if (!myfile1)
     {
          myfile1.close();
          cout << "error in line 266" << " " << file1 << "\n";
          cin >> pause;
          exit(1);
     }
     if (whatdo == "read")
     {
// cout << byte1 << " We are reading bytes " << "\n"; // debug code
          myfile1.seekg(count1);
          myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellg();
          byte1 = buffer;
          myfile1.close();
          myfile1.clear();
          myfile1.flush();
          return(byte1);
     }
     if (whatdo == "write")
     {
// cout << byte1 << " We are writing bytes " << "\n"; // debug code
          buffer = byte1;
          myfile1.seekp(count1);
          myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellp();
          myfile1.close();
          myfile1.clear();
          myfile1.flush();
          return(0);
     } 
     

     cout << "Error in binary read and write" << "\n";
     cin >> pause;
     exit(1);
}
// ============================================================================================
// declare main
int main (int argc, char *argv[])
{


    // Declare variables    
    long long count1;
    string dummyfile;
    string file1;
    string file2;
    long long buffersize;
    string pause;
    long long filesize1;
    string whatdo;
    long long pbnum2;
    long long byte;
    long long base;
    fstream c1myfile1;

    // Get command line arguments
    // ./program name // name of file to create // buffersize // get name of binary file
    file2 = argv[1];
    buffersize = atoi( argv[2]); // How many bytes we are reading at a time.
    file1 = argv[3];


    // open text file
    c1myfile1.open(file2.c_str(), ios::out);
    if (!c1myfile1)
    {
         cout << "There is no file list." << "\n";
         c1myfile1.close();
         c1myfile1.clear();
         c1myfile1.flush();
         exit(0);           
    }

    filesize1 = filesize(file1);

    count1 = buffersize * -1;
    do
    {
         count1 = count1 + buffersize;
         whatdo = "read";
         pbnum2 = binaryreadwrite(whatdo, file1, count1, byte, buffersize);
         
         cout << pbnum2 << "\n";
         c1myfile1 << pbnum2 << "\n";

    } while(count1 < filesize1 - 1); 
    c1myfile1.close();
    c1myfile1.clear();
    c1myfile1.flush();

    // Exit program
    exit(0);
}
