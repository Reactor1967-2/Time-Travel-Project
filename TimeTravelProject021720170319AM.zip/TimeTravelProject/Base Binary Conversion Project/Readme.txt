This project works by getting a destination file. Then using true random numbers generate difference files of varying file sizes.
run the time scanner to construct the target files within the ranges of the difference files. When enough targets have been
constructed use a higher or lower destination file and repeat. By moving the destination file up and down and constructing the
differences around that destination file we are scanning space-time for computer files. The difference files can be used to 
add or subtract from the destination file.

You will need something to generate random numbers. That is in the tools directory.
