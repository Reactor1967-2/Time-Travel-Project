#!/bin/bash

g++ BCDecodegen.cpp -o BCDecodegen
g++ BCtimescanner.cpp -o BCtimescanner
g++ CodeBaseBinaryConverter.cpp -o CodeBaseBinaryConverter
g++ DecodeBaseBinaryConverter.cpp -o DecodeBaseBinaryConverter


