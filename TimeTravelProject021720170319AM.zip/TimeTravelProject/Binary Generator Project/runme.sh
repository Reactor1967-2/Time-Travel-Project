#!/bin/bash

g++ binaryfilegenerator.cpp -o binaryfilegenerator
g++ timescanner.cpp -o timescanner.cpp
g++ BinaryGeneratorAdd.cpp -o BinaryGeneratorAdd
g++ BinaryGeneratorSubtract.cpp -o BinaryGeneratorSubtract
