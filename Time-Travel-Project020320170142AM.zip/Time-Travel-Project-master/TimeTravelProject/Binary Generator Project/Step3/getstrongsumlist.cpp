// ============================================================================================
 // declare includes
     #include <cstdlib>
     #include <iostream>
     #include <stdlib.h>
     #include <fstream>
     #include <sstream>
     #include <string> 
     #include <cmath>
     #include <ctime>
     #include <cstdio>
     #include <iostream>
    
// ============================================================================================
    // Declare namespace
    using namespace std;
// ============================================================================================     
    // declare globals
// ============================================================================================     
// declare subs
// This is where all the work is done to make the program run.
// ======================================================================================================================
// open list of files. Get strong check sum for files and write them to strongchecksum.txt with file names
    int getstrongsumsfilelist(long long howmanyweightedsums, int buffersize)
    {
         // declare variables
         fstream c1myfile1("list.txt", ios::in);
         fstream c1myfile2("strongsums.txt", ios::out);
         // open file2 for weights
         fstream c1myfile3("weights.txt", ios::in);
         string file1; 
         fstream myfile1;
         long double x1;
         string x2;
         int byte1 = 0;
         long double schecksum = 0;
         long long begin1;
         long long count1;
         long long count2;
         unsigned char buffer(buffersize);
         long long size1;
         long long size2;
         long long filesize1;
         long long end1 = 0;
         string pause;
//         stringstream ss;
         
         // open main loop
         do
         {
              // read list
              c1myfile1 >> file1;
              if (c1myfile1.eof())
              {
                   break;
              }   
// get strong check sum

              // open file1 computer file1
              fstream myfile1(file1.c_str(), ios::in | ios::binary);
              if (!myfile1)
              {
                   myfile1.close();
                   cout << "Failed to read file one.\n";
                   cin >> pause;
                   exit(1);
              }

              // get filesize1
              begin1 = myfile1.tellg();
              if (!myfile1)
              {
                   myfile1.close();
                   cout << "Failed to read file one.\n";
                   cin >> pause;
                   exit(1);
              }
              myfile1.seekg (0, ios::end);
              end1 = myfile1.tellg();
              filesize1 = (end1-begin1);

              // Two loops that get the strong check-sum
              count1 = 0;
              schecksum = 0;
              // start loop 1
              do
              {
                   // read file1
                   byte1 = 0;
                   // read file1
                   myfile1.seekg(count1);
                   myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
                   begin1 = myfile1.tellg();
                   // byte1 = read from file 1
                   byte1 = (int)buffer;

                   count2 = 0;
                   // start loop 2
                   do
                   {
                        // count2++;
                        count2++;
                        // read weight file. 
                        c1myfile3.precision(36);
                        c1myfile3 >> x1;
                        // schecksum = schecksum + (byte1 * x1);
                        schecksum = schecksum + (byte1 * x1);
                   // end loop 2 for how many weighted sums
                   } while(count2 < howmanyweightedsums);
                   // count1 = count1 + buffersize;
                   count1 = count1 + buffersize;
              // end loop 1 for count1 < filesize1 - 1
              } while (count1 <  filesize1 - 1);
              // close file1 for program
              myfile1.close();
              myfile1.clear();
              myfile1.flush();     
              // write weak check-sum to file
              c1myfile2.precision(36);
              c1myfile2 << file1 << " " << schecksum << "\n";
        // repeat main loop to end of file
         } while(!c1myfile1.eof());
        // close list.txt
         c1myfile1.close();
         c1myfile1.clear();
         c1myfile1.flush();
        // close strongsums.txt
         c1myfile2.close();
         c1myfile2.clear();
         c1myfile2.flush();
        // close file2 for weights
         c1myfile3.close();
         c1myfile3.clear();
         c1myfile3.flush();
    }
// ======================================================================================================================

// ============================================================================================
// declare main
    int main (int argc, char *argv[])
    { 
         // declare variables
         long long howmanyweightedsums;
         int buffersize;
         int dummyfile;

         // read command line input
         buffersize = atoi( argv[1]); // How many bytes we are reading at a time.
         howmanyweightedsums = strtoull(argv[2],NULL,10);

         dummyfile = getstrongsumsfilelist(howmanyweightedsums, buffersize);
    }
