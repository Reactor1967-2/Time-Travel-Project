Use #1 to find the largest and smallest and largest file.
If running in parallel cut those files into sections
Use #2 to get those sections

Use the Random number generator from here to make check-sums. It will have to read the files from #2.
