// THIS PROGRAM WILL BE REWRITTEN AND ADAPTED FOR TIME TRAVEL PROJECT
// COPYRIGHT(C) 2016 http://time-travel.institute
#include <cstdlib>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <string>
#include <cmath>
#include <ctime>
#include <cstdio>
#include <iostream>

// to compile download g++ then do this g++ lotteryAI.cpp -o lotteryAI
// THIS IS A ARTIFICIALLY INTELLIGENT LOTTERY NUMBER PROGRAM TO FIND LOTTERY NUMBERS USING A NEURAL NET DATA BASE.
// THE DATA BASE IS TRAINED USING BACK PROPAGATION.
// 1. ENTER THE WINNING LOTTERY NUMBERS ONE AFTER ANOTHER FROM THE OLDEST WINNING NUMBERS TO THE NEWEST WINNING NUMBERS AND THE DATA BASE IS CREATED.
// 2. TAKE THE VERY LAST WINNING LOTTERY NUMBER AND ENTER IT TO FIND THE NEXT WINNING LOTTER NUMBER.
// CREATE A BLANK lotterydatabase.txt FILE BEFORE RUNNING THE PROGRAM. MAKE SURE THEY ARE IN THE SAME DIRECTORY
// COPYRIGHT C LLOYD BURRIS 2016

using namespace std;

int main (int argc, char *argv[])

{

long double num1;
long double num2;
long double weight;
long double dis;
long double num3;
long double weight2;
char choice;
char dummy;

cout << "Select your choice." << "\n";

     cout << "\n";

     cout << "1. Enter new lottery number." << "\n";

     cout << "\n";

     cout << "2. Find a new lottery number." << "\n";

     cout << "\n";

     cin >> choice;

 if (choice=='1')
     {
          fstream c1myfile("lotterydatabase.txt", ios::out | ios::app);
          if (!c1myfile)
          {
               cout << "Unable to open file line 923 \n";
               system("pause");
               exit(1); // terminate with error
          }

retry:          
          
          cout << " Enter lottery number 1. " << "\n";
          cin >> num1;
          cout << " Enter Lottery number 2. " << "\n";
          cin >> num2;
          weight = num2/num1;
          cout.precision(36);
          cout << weight << "\n";
          cout.precision(36);
          cout << weight * num1 << "\n";
          cout << " Enter c to continue or 0 to quite " << "\n";
          cin >> choice;
          c1myfile.precision(36);
          c1myfile << num1 << " " << weight << "\n";
          
          if (choice =='0')
          {
               c1myfile.close();
               c1myfile.clear();               
               exit(0);
          } 
          goto retry;

         exit(0);
     }

if (choice == '2')
   {
        cout << "Enter your lottery number " << "\n";
        cin >> num2;
        dis = 999999999999999999;
        fstream c1myfile("lotterydatabase.txt", ios::in);
        if (!c1myfile)
        {
             cout << "Unable to open file line 923 \n";
             system("pause");
             exit(1); // terminate with error
           

        }
        do
        {
             c1myfile.precision(36);
             c1myfile >> num1 >> weight;
             if (abs(num2 - num1) < dis)
             {
                  dis = abs(num2 - num1);
                  num3 = num1;
                  weight2 = weight;
             }
        } while(!c1myfile.eof());  
        cout << " Closest Numbers and weights " << "\n";
        cout.precision(36);
        cout << num3 << " " << weight2 << "\n";
        cout.precision(36);
        cout << " Your lottery number is " << "\n";
        cout << num2 * weight2 << "\n"; 
        cin >> choice;
        c1myfile.close();
        c1myfile.clear(); 
        exit(0);  


   } 



}

