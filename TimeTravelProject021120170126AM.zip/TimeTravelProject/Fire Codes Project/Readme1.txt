I was looking at making a file generator for fire codes to generate time travel projects for it.
But I relized it would be redundant because I would first need to generate binary then feed
it to firecodes to make a config file for it. Then I relized I already have a binary generator.
So this would be would worked backwards. Binary could be generated, the Robot would look at the
files. Any good files remaining could be be coded to a fire codes project. You would do this if
you did not want anyone to easily look at the time travel media. Use a long seed number when
coding it. The seed number is the password. Without that seed number the config file can not
be decoded. So here you go. This is the generator for fire codes.
