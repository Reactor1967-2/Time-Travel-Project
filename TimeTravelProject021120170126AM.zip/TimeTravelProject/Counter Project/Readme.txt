This project is still been written and upgraded but is usable right now.
These files need a weights.txt file. There is a program to generate that.
It also needs a random.txt file. I have been using random.org. I have a program to generate it
It also needs a destination file. That can be randomly generated or use a known good computer file. I have a program here too that can generate it.

