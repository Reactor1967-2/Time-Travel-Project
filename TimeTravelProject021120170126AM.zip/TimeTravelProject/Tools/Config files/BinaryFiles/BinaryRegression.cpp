// ============================================================================================         
// Example of how my software will use regression lines.
// =================================== Starting sample
// Example of Graphing a regression line by hand.
// When done write files with the x and y files and see if they get the same answers as this example.
// x  1| 3|10| 16| 26| 36
// -------------------------
// y 42|50|75|100|150|200

// Goal - Get equation y = a + bx where  a = y intercept and b = slop 

// 1. Count how many samples you have.
// 2. Get sum of X
// 3. Get sum of y

// Symbol Chart
// ---------------------------
// n = How many Samples I have = 6
// ex =  Sum of X
// ey =  Sum of Y
// ex^2 = Sum of x^2
// ey^2 = Sum of y^2
// exy = Sum of X times Y
// e = sum
// -
// y = average of y = 102.8333......
// -
// x = average of x = 15.3.....

//                                     divided
// average = sum of samples / how many samples

//     (n times (exy))-((ex) times (ey))
// b = --------------------------------     =  4.51
//      (n times (ex^2)) - ((ex)^2)
//     -            -
// a = y - (b times x) = 33.83

// Now plug values into regression line. THIS IS WHERE WE GET STRONG CHECK SUMS FOR TIME TRAVEL MEDIA FILES.

//   y = a + (b times x) 

// I think a is the intercept and b is the slop of the line. I think. Test the math!!!!!!!!!!!!!!!!!!!!!

//   y = 33.83 + (4.51 times x)
//   x = 12

//   so y = 33.83 + (4.51 times 12) = 87.95
//================================================= Ending sample   
// y  = a + bx

// x = y - a / b
