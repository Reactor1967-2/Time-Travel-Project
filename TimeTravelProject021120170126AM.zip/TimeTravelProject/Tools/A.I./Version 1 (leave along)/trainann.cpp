// Program gives choices of types of networks to create and gets information from user and creates those networks automatically.

// Choices will be 
//             1. Standard Feed forward neural net. How many input nodes. How many output nodes. 
//             2. Standard recurring neural net. How many input nodes. How many output nodes.
//             3. Customized Ann. 

// Node types
// 1. input
// 2. output
// 3. worker
// 4. input/output

// Each neural net has a master neural net file. It contains - Net type, how many inputs, how many outputs, total nodes, nodes per layer, total layers

// Each node has 4 files. Master file - Broken down into three files: 1. name. masterfile 2. name.Inputmaster 3. name.Outputmaster
//                          1. list node type, how many input nodes, how many output nodes.              
//                          2. input nodes list. example 1, 2, 3
//                          3. output nodes list. example 5, 6, 7
                       
//                        input log file. - All input data and what node they are recorded from are recorded here temporaly.
//                                            Node from | input
//                        output log file - The output and what nodes those outputs were recorded too.
//                                            Node too | output   
//                        weight file - Weight is recorded here temporaly 
//                                        Node from | weight
//                        data base - all inputs and their weights are recorded here.
//                                      Node From | input | weight 
//                        Threshold file - After training this will be calulated and held here. A 0 means no thresh-hold.
//                                           High | Low  
     
// Program will use backpropagation for training. 
// for output nodes and worker nodes - output will be devided by number of inputs to get weighted sum at each input. Weights picked input calulated.
// for input nodes - output will be devided by number of inputs to get weighted sum at each input. Weights calulated from known input.

// The data base per node will hold each input, where it is from, and its weight. After training thresh holds can be calulated and per node if wanted.


// This type of network remembers all of its training and applys all of its training to a problem. 

// Training Program.
// 1. Load Master file.
// 2. Load output.
// 3. Compute distrubitied sum.
// 4. if Input read compute weight and write it to log file.
// 5. if input read skip to number 8  
// 6. if Input empty select weight and write it to log file and compute input and write it to log file.
// 7. copy input to its output node. Read output node master file and copy output to their input nodes.
// 8. write input & weight to data base.
// 9. Go back to orginal node and repeat training for rest of inputs on that node.
// 10. Derement one node and repeat training program.
// 11. When all nodes exhausted end training program.


#include <cstdlib>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <string>
#include <cmath>
#include <d:\aiproject\mersenne\mersennetwister.h> 
#include <stdio.h>


using namespace std;

int main (int argc, char *argv[])

{

     long double layers = 0; // counts layers as they are created
     long double maxlayers = 0; // holds max number of layers for neural net
     long double nodes = 0; // counts nodes in each layer
     long double countnodes = 0; // Used with ss to name files.
     long double inputs = 0; // number of input nodes This is a constant dont mess with it.
     long double outputs = 0; // number of output nodes This is a constant dont mess with it.
     long double maxnodes = 0; // how many nodes per layer
     long double endingnode = 0; // ending node in output / input files.
     long double startingnode = 0; // starting node in output / input files.
     long double totalnodes = 0; // How many nodes in the net
     long double count = 0; // generic count can be used anywhere that visa or mastercard is accepted. (Joke)
     long double readinput; // A variable to read input to nodes from files. Not a constant use it.
     long double readoutput; // A variable to read output to nodes from files. Not a constant use it
     long double nodeinputs; // How many inputs a node has
     long double nodeoutputs; // How many outputs a node has
     long double node; // Used to read log files to tell what information comes or goes to what nodes. Not a constant use it.
     long double distributedsum = 0; // Hold output divided by input.
     long double weight = 0; // Holds weights of inputs for computing weighted sum.
     long begin; // Used to get size of file
     long end; // Used to get size of file
     long size = 0;
     long long countnodes1; // used specifically in one area of program.
     long long countnodes2; // used specifically in one area of program.
     long long previousnode;
     string networktype = ""; // Holds type of neural network
     string nodetype = ""; // Holds input, worker, or output nodetype
     string mext = ".masterfile"; // extension to denote master file.
     string miext = ".inputmasterfile";
     string moext = ".outputmasterfile";
     string iext = ".input"; // extension to denote input file.
     string oext = ".output"; // extension to denote output file.
     string wext = ".weight"; // extension to denote weight file
     string dext = ".database"; // extension to denote data base file.
     string text = ".threshold"; // extension to denote threshold file.
     string file0 = "";
     string file1 = "";
     string file2 = "";
     string file3 = "";
     string file4 = "";
     string file5 = "";
     string file6 = "";
     string file7 = "";
     string file8 = "";
     string file9 = "";
     string file10 = "";
     fstream myfile0;
     fstream myfile1;
     fstream myfile2;
     fstream myfile3;
     fstream myfile4;
     fstream myfile5;
     fstream myfile6;
     fstream myfile7;
     fstream myfile8;
     fstream myfile9;
     fstream myfile10;
               
     int x = 0; // dummy variable
     std::stringstream ss;    
     
//                                                      TRAINING NET
// open neural net master file load variables
// Each neural net has a master neural net file. It contains - Net type, how many inputs, how many outputs, total nodes, nodes per layer, total layers
     file0 = "neuralnet.masterfile";
     myfile0.open(file0.c_str(), ios:: in);
     if (!myfile0)
     {
          myfile0.close();
          cout << "Failed to read file in line 128\n";
          cin >> x;
          exit(1);
     } 
     
     myfile0 >> networktype >>  inputs >> outputs >> totalnodes >> nodes >> maxlayers;
     myfile0.close();
     myfile0.flush();
     myfile0.clear();

// open training file for reading.
     file1 = "training.ann";
     myfile1.open(file1.c_str(), ios:: in);
     if (!myfile1)
     {
          myfile1.close();
          cout << "Failed to read file in line 142\n";
          cin >> x;
          exit(1);
     }      
     
// training file read loop
do
{
     // Read training file. 
     // write inputs to input nodes.
     count = 0;
     do
     {
          count++;
          // read input from file
          myfile1 >> readinput;
          
          // assign name input node
          ss.clear();
          file2 = "";
          ss << count;
          ss >> file2;
          file2 = file2 + iext;
          
          // open input node input file
          myfile2.open(file2.c_str(), ios:: out);
          if (!myfile2)
          {
               myfile2.close();
               cout << "Failed to read file in line 171\n";
               cin >> x;
               exit(1);
          }           
          
          // write input to input file
          myfile2 << 0 << " " << readinput << "\n";
          // close input node file
          myfile2.close();
          myfile2.flush();          
          myfile2.clear();
          // repeat for number of inputs
                
     } while (count < inputs);  
 
// TESTED GOOD TO HERE <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<       
     
     // Read trainging file.
     // write outputs to outputs nodes
     count = totalnodes - outputs;
     do
     {
          count++;
          // read output from file
          myfile1 >> readoutput;
          
          // assign name output node
          ss.clear();
          file2 = "";
          ss << count;
          ss >> file2;
          file2 = file2 + oext;
          
          // open output node input file
          myfile2.open(file2.c_str(), ios:: out);
          if (!myfile2)
          {
               myfile2.close();
               cout << "Failed to read file in line 208\n";
               cin >> x;
               exit(1);
          }           
          
          // write output to output file
          myfile2 << readoutput << "\n";
          // close output node file
          myfile2.close();
          myfile2.flush();          
          myfile2.clear();

     // repeat for number of outputs
     } while (count < totalnodes);         
 
 // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Program tested to here. Works good.
     // loop node count.
     countnodes = totalnodes + 1;  
     do
     {
          countnodes--;

          // assign name to node being worked on
          ss.clear();
          file2 = "";
          ss << countnodes;
          ss >> file2;
          file2 = file2 + mext;

          // Load master 1 file and read how many inputs and outputs and assign those to variables
          myfile2.open(file2.c_str(), ios:: in); 
          if (!myfile2)
          {
               myfile2.close();
               cout << "Failed to read file in line 240\n";
               cin >> x;
               exit(1);
          }           
          
          // read node master file.
          myfile2 >> nodetype >> nodeinputs >> nodeoutputs;

          // close node master file.
          myfile2.close();
          myfile2.flush();          
          myfile2.clear();

// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< PROGRAM TESTED TO HERE for 2nd to last node.

          // load node output log file 
          // assign name output node
          ss.clear();
          file3 = "";
          ss << countnodes; 
          ss >> file3;
          file3 = file3 + oext;
          
          // open output node input file
          myfile3.open(file3.c_str(), ios:: in);
          if (!myfile3)
          {
               myfile3.close();
               cout << "Failed to read file in line 266\n";
               cin >> x;
               exit(1);
          }           
          
          // read output file
          myfile3 >> readoutput;
          // close output node file
          myfile3.close();  
          myfile3.flush();        
          myfile3.clear();
          
          distributedsum = (readoutput / nodeinputs); // Tested distributedsum equation correct.

//  <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< TESTED TO HERE for second to last node worked out previous unknown error.

         // Open nodes input file and read input and work it to train node.
         // assign name output node

         ss.clear();
         file4 = "";
         ss << countnodes;
         ss >> file4;
         file4 = file4 + iext;

          // open node input file
         myfile4.open(file4.c_str(), ios::in | ios::out);
         if (!myfile4)
         {
              myfile4.close();
              cout << "Failed to read file in line 295\n";
              cin >> x;
              exit(1);
         }           
         
 // Get size of input file  
         begin = myfile4.tellg();
         myfile4.seekg(0, ios::end);
         end = myfile4.tellg();
         size = end-begin;
         
         myfile4.close();
         myfile4.flush();
         myfile4.clear();

         ss.clear();
         file4 = "";
         ss << countnodes;
         ss >> file4;
         file4 = file4 + iext;

          // open node input file
         myfile4.open(file4.c_str(), ios::in | ios::out);
         if (!myfile4)
         {
              myfile4.close();
              cout << "Failed to read file in line 295\n";
              cin >> x;
              exit(1);
         }           

// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Tested good to here for last node 1st pass.

              // Read master node input file to get previous node 
         ss.clear();
         file7 = "";
         ss << countnodes;
         ss >> file7;
         file7 = file7 + miext;
        
         // open master node input file
         myfile7.open(file7.c_str(), ios:: in);
         if (!myfile7)
         {
              myfile7.close();
              cout << "Failed to read file in line 321\n";
              cin >> x;
              exit(1);
         }                        

// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Tested good to here for last node 1st pass.

         count = 0; // counts inputs node.
         // loop input count. As we read an input we also read the previous node that wrote that input. They go hand in hand like a married couple.           
         do 
         {
              count++;
              
              myfile7 >> previousnode; 
              
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Tested good to here for myfile7 >> previous node second pass

              // read output file and come up with weights and inputs.
              if (size > 0)
              {

                   myfile4 >> node >> readinput;

                  // if input read compute weight and append it to weight file. TO REPEAT.
                  if (node > -1)
                  {
                       if (readinput > -1)
                       {
                            weight = distributedsum / readinput;  

// <<<<<<<<<<<<<<<<<<<<<<<<<< tested good to here second to last node;

                           // write weight to weight file.
                           ss.clear();
                           file5 = "";
                           ss << countnodes;
                           ss >> file5;
                           file5 = file5 + wext;
          
                           // open weight file
                           myfile5.open(file5.c_str(), ios:: out | ios:: app);
                           if (!myfile5)
                           {
                                myfile5.close();
                                cout << "Failed to read file in line 366\n";
                                cin >> x;
                                exit(1);
                           }           
          
                           // write weight file
                           myfile5 << previousnode << " " << weight << "\n";
                          // close weight node file
                           myfile5.close();  
                           myfile5.flush(); 
                           myfile5.clear();                           

                  // write node, input, weight to data base file.
                          ss.clear();
                          file6 = "";
                          ss << countnodes;
                          ss >> file6;
                          file6 = file6 + dext;
          
                  // open output node input file
                          myfile6.open(file6.c_str(), ios:: out | ios:: app);
                          if (!myfile6)
                          {
                               myfile6.close();
                               cout << "Failed to read file in line 388\n";
                               cin >> x;
                               exit(1);
                          }
                 
                          myfile6 << previousnode << " " << readinput << " " << weight << "\n"; 
                          myfile6.close();
                          myfile6.flush();
                          myfile6.clear();

// <<<<<<<<<<<<<<< Tested to here for second to last node.

                       }              
                  }         

              }
//            if input empty select weight and comput input and append input and weight to their files then write that information to database.
              if (size == 0)  
              {
                   MTRand mtrand1;
                   weight = mtrand1.rand();              
                   readinput = distributedsum / weight; // <<<<<<<<<<<< EQUATION TESTED GOOD. INPUT * WEIGHT = DISTRIBUTED SUM ok ok AND MORE OK.

// tested good to here for 3 inputs.

                  // write weight to weight file.
                   ss.clear();
                   file5 = "";
                   ss << countnodes;
                   ss >> file5;
                   file5 = file5 + wext;
          
                  // open weight file
                   myfile5.open(file5.c_str(), ios:: out | ios:: app); 
                   if (!myfile5)
                   {
                        myfile5.close();
                        cout << "Failed to read file in line 421\n";
                        cin >> x;
                        exit(1);
                   }           
          
                  // write weight file
                   myfile5 << previousnode << " " << weight << "\n";

                  // close weight node file
                   myfile5.close();
                   myfile5.flush();
                   myfile5.clear();                             
                  // write input to input file with node it came from.
                   myfile4 << previousnode << " " << readinput << "\n";

// <<<<<<<<<<<<<<<< tested good here for three inputs.

                  // write node, input, weight to data base file.
                   ss.clear();
                   file6 = "";
                   ss << countnodes;
                   ss >> file6;
                   file6 = file6 + dext;
                   
                  // open data base file
                   myfile6.open(file6.c_str(), ios:: out | ios:: app);
                   if (!myfile6)
                   {
                         myfile6.close();
                         cout << "Failed to read file in line 451\n";
                         cin >> x;
                         exit(1);
                   }
                 
                   myfile6 << previousnode << " " << readinput << " " << weight << "\n"; 

                   myfile6.close();
                   myfile6.flush();
                   myfile6.clear();
                   
// <<<<<<<<<<<<< Tested to here for three inputs
                   // If there is no previous node get out of here now.

                  // copy input to previous nodes output file. 
                   ss.clear();
                   file8 = "";
                   ss << previousnode;
                   ss >> file8;
                   file8 = file8 + oext;
          
              // open previous node output file and write input to its output
                  myfile8.open(file8.c_str(), ios:: out);
                  if (!myfile8)
                  {
                       myfile8.close();
                       cout << "Failed to read file in line 471\n";
                       cin >> x;
                       exit(1);
                  }
             
                  myfile8 << readinput << "\n";

                  myfile8.close();
                  myfile8.flush();
                  myfile8.clear();
// <<<<<<<<<<<< Tested good to here for 3 inputs.

             // Read that nodes outputs and copy the output to other nodes inputs. 
             // copy input to previous nodes output file. 
                   ss.clear(); // This is the master output file for previous node. we are opeing it to read in data
                   file9 = "";
                   ss << previousnode;
                   ss >> file9;
                   file9 = file9 + moext;             
 
                   myfile9.open(file9.c_str(), ios:: in);
                   if (!myfile9)
                   {
                        myfile9.close();
                        cout << "Failed to read file in line 491\n";
                        cin >> x;
                        exit(1);
                   }

                   countnodes1 = 0;
                   do // The nodes numerical output is copied to the other nodes inputs.
                   {                   
                        countnodes1++;
                        // Put read statement here
                        myfile9 >> node;
                        
                        if (node != countnodes)
                        {
                             ss.clear(); // This is the input files for the next nodes. We need a doo loop here
                             file10 = "";
                             ss << node; // Change this to be the files that we write the output to the inputs
                             ss >> file10;
                             file10 = file10 + iext;             

                             myfile10.open(file10.c_str(), ios:: out | ios:: app);
                             if (!myfile10)
                             {
                                  myfile10.close();
                                  cout << "Failed to read file in line 513\n";
                                  cin >> x;
                                  exit(1);
                             }
                             
                             myfile10 << previousnode << " " << readinput << "\n";
                             myfile10.close();
                             myfile10.flush();
                             myfile10.clear();
                        }

                   } while (countnodes1 < outputs); // Put something in the while statement.
                   myfile9.close();
                   myfile9.flush();
                   myfile9.clear();    
// <<<<<<<<<<<<<<<<<<<<< Tested good to here for 3 inputs for second if
              }
      // repeat for all inputs 
     // loop until all INPUTS worked
         } while(count < nodeinputs);
         
         myfile7.close();
         myfile7.flush();
         myfile7.clear();  
         myfile4.close();
         myfile4.flush();
         myfile4.clear();

    // clear node log files  
    // Just recreate them that will clear them.
    
     } while (countnodes > 1); // We are starting at top and working are way to node 1. TRAINING FROM BACK TO FRONT.
 

//                                 <<<<<<<<<<<<<<<<<<<<<< TESTING TRAINED NET (Copy this section to running network and use its code to run the network)
// clear all log / output / input files.
     count = 0;
     do
     {

          count++;  
          ss.clear();
          file2 = "";
          ss << count;
          ss >> file2;
          file2 = file2 + iext;

          // open input files and clean it out.
          myfile2.open(file2.c_str(), ios:: out);
          if (!myfile2)
          {
               myfile2.close();
               cout << "Failed to read file in line 627\n";
               cin >> x;
               exit(1);
          } 
          myfile2.close();
          myfile2.flush();
          myfile2.clear();
          
          ss.clear();
          file2 = "";
          ss << count;
          ss >> file2;
          file2 = file2 + oext;
          
          // open output files and clean it out.
          myfile2.open(file2.c_str(), ios:: out);
          if (!myfile2)
          {
               myfile2.close();
               cout << "Failed to read file in line 646\n";
               cin >> x;
               exit(1);
          } 
          myfile2.close();
          myfile2.flush();
          myfile2.clear();
          
          ss.clear();
          file2 = "";
          ss << count;
          ss >> file2;
          file2 = file2 + wext;
          
          // open weight files and clean it out.
          myfile2.open(file2.c_str(), ios:: out);
          if (!myfile2)
          {
               myfile2.close();
               cout << "Failed to read file in line 654\n";
               cin >> x;
               exit(1);
          } 
          myfile2.close();
          myfile2.flush();
          myfile2.clear();
        
     } while(count < totalnodes);

// End read traing file loop    
} while (!myfile1.eof()); 

myfile1.close();
myfile1.flush();
myfile1.clear();

cout << "Program Completed.\n";
cin >> x;
exit(0);
     

}    
