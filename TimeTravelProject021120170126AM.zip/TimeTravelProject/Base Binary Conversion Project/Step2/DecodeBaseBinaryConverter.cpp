// ============================================================================================
// Declare includes
#include <cstdlib>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <string> 
#include <cmath>
#include <ctime>
#include <cstdio>
#include <iostream>
#include "timecheckhacking.h"
// ============================================================================================
// Declare namespace
using namespace std;
// ============================================================================================     
// declare subs
// ============================================================================================
long long createdestinationfile(string file1, int buffersize, long long pbnum2, long long count1)
{
    long long numberbase;
//    long long pbnum2;
    long long pbnum3; 
//    long long count1;
    long long carry;
    string pause;
    int dummyfile;
    string whatdo;

//    fstream myfile1(file1.c_str(), ios::out  | ios::binary | ios::app);
//    if (!myfile1)
//    {
//         myfile1.close();
//         cout << "error in line 245" << " " << file1 << "\n";
//         cin >> pause;
//         exit(1);
//    }
//    myfile1.close();
//    myfile1.clear();
//    myfile1.flush();

    numberbase = (buffersize * 255) + 1;
//    pbnum2 = (numberbase - 1) * counterspeed;
//    count1 = buffersize * -1;
    do
    {         
         count1 = count1 + buffersize;
         pbnum3 = (pbnum2 - (int(pbnum2/numberbase)*numberbase));
         pbnum2 = int(pbnum2/numberbase);
         //write pbnum3 to binary file
         whatdo = "write";
         dummyfile = binaryreadwrite(whatdo, file1, count1, pbnum3, buffersize);

         if(pbnum2 < numberbase)
         {
              // increment file pointer
              pbnum3 = pbnum2;
              // write pbnum3 to binary file
              whatdo = "write";
              dummyfile = binaryreadwrite(whatdo, file1, count1, pbnum3, buffersize);
              return(0);
         }

    } while(pbnum2 > numberbase);
    return(count1);

}
// ============================================================================================
// declare main
int main (int argc, char *argv[])
{
    // Declare variables
    long long count1;
    string dummyfile;
    string file1;
    string file2;
    long long pbnum2;
    int buffersize;
    string pause;

    // Get command line arguments
         // ./program name // name of file to create // buffersize // get name of number file containing base number
     file1 = argv[1];
     buffersize = atoi( argv[2]); // How many bytes we are reading at a time.
     file2 = argv[3];

    // CREATE BINARY FILE WRITING TO WITH 0 SIZE and close it
    fstream myfile1(file1.c_str(), ios::out  | ios::binary);
    if (!myfile1)
    {
         myfile1.close();
         cout << "error in line 87" << " " << file1 << "\n";
         cin >> pause;
         exit(1);
    }
    myfile1.close();
    myfile1.clear();
    myfile1.flush();


    // open text file
    fstream c1myfile1(file2.c_str(), ios::in);
    if (!c1myfile1)
    {
         cout << "There is no file list." << "\n";
         c1myfile1.close();
         c1myfile1.clear();
         c1myfile1.flush();
         exit(0);           
    }


    // set count1 to buffersize * -1
    count1 = buffersize * -1;

    // Start do loop
    do
    {

         // increment count1 + buffersize
         if (!c1myfile1.eof())
         {
              count1 = count1 + buffersize; 
         }

         pbnum2 = 0;
         if (!c1myfile1.eof())
         {
               // read text file pbnum2
              c1myfile1 >> pbnum2;
         }

         if (!c1myfile1.eof())
         {
              // call program to convert pbnum2 and write to binary file
              dummyfile = createdestinationfile(file1, buffersize, pbnum2, count1);
         }

    // End loop at end of file
    } while(!c1myfile1.eof());

    c1myfile1.close();
    c1myfile1.clear();
    c1myfile1.flush();

    // Exit program
    exit(0);
}
