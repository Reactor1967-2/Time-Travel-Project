// ===========================================================================================
// declare includes
#include <cstdlib>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <string>
#include <cmath>
#include <ctime>
#include <cstdio>
#include <iostream>
#include <stdio.h>
// ===========================================================================================
// declare name space
using namespace std;
// declare subs
//============================================================================================
int main (int argc, char *argv[])
{
    // declare variables
    string dummy1;
    string dummy2;
    string file3;
    // Get file format list
    system("file * > list.txt");
    int test2;

    // open file format list
    fstream c1myfile1("list.txt", ios::in);

    if (!c1myfile1)
    {
         cout << "Something went wrong" << "\n";
         exit(0);
    }

    do
    {
         c1myfile1 >> dummy1 >> dummy2;
         cout << dummy1 << " " << dummy2 << "\n";
         if (dummy2 == "data")
         {
              test2 = 2;
              file3 = dummy1;
              rename(dummy1.c_str(), "deleteme.bin");
              system("rm deleteme.bin"); 
         }
         if (test2 == 0)
         {
              if( remove( file3.c_str() ) != 0 )
               perror( "Error deleting file" );
               else
               puts( "File successfully deleted" );

         }

        
    } while(!c1myfile1.eof());

    // close list.txt
    c1myfile1.close();
    c1myfile1.clear();
    c1myfile1.flush();

    
}
