// This program goes through a list of randomly generated files and attempts to file the file closest
// to the targert check-sum. Use a upgraded Strong check-sum generator for a increased file buffer.
// ============================================================================================
 // declare includes
    #include <cstdlib>
    #include <iostream>
    #include <stdlib.h>
    #include <fstream>
    #include <sstream>
    #include <string> 
    #include <cmath>
    #include <ctime>
    #include <cstdio>
    #include <iostream>
    #include "timecheckhacking.h"
// ============================================================================================
    // Declare namespace
    using namespace std;
// ============================================================================================     
// declare globals 
    long double targetstrongchecksum;
    long double destinationstrongchecksum;
    long long filesize1;
    long long howmanyweightedsums;
    int buffersize;
// ============================================================================================     
// declare subs
// This is where all the work is done to make the program run.
// ======================================================================================================================
// loadconfig Note give name of config file
int loadconfig() 
{// Can't put this in a header and use globals
    // Declare these variables as global in your main file
    // declare variables
    string dummy;
    string pause;
// Load configure file
          fstream c1myfile("config.txt", ios::in);
          // read name of file
          c1myfile >>  dummy >> dummy >> dummy >> buffersize;
          // strong check sum
          c1myfile >>  dummy >> dummy >> dummy >> targetstrongchecksum;
          // read file size
          c1myfile >>  dummy >> dummy >> dummy >> filesize1;
          // read how many weights
          c1myfile >>  dummy >> dummy >> dummy>> dummy >> howmanyweightedsums;

         // close configure file
          c1myfile.close();
          c1myfile.clear();
          c1myfile.flush();

         // Print configure file to confirm loaded correctly
          cout << "buffersize > " << buffersize << "\n";
          cout.precision(36);
          cout << "Strong check-sum > " << targetstrongchecksum << "\n";
          cout.precision(36);
          cout << "File size > " << filesize1 << "\n";
          cout.precision(36);
          cout << "How many weighted check-sums > " << howmanyweightedsums<< "\n";
          cout << "\n"; 
          cout << "Is the configuration file loaded properly?" << "\n";
          cout << "Hit any key and enter." << "\n";
          cin >> pause;
          return(0);
//        
}
// ============================================================================================
// declare main
    int main (int argc, char *argv[])
    { 
         // declare variables
         string pause;
         string configfile;
         long double diff3;
         string lockfile = "lock.txt";
         int dummyfile = 0;
         string file1;
         int result;          

// ============================================================================================         
         // pass arguments to program. If no arguments run menu. If Arguments run program
         // pass arguments to program. If no arguments run menu. If Arguments run program
         if (argc == 1) 
         {
              cout << "No command line arguments. I can't run. Type nameofprogram help" << "\n";
              cin >> pause;
              exit(1);   
         }

         // passing command line arguments to program
         configfile = argv[1]; // name of config file only // contains lockfile, strong checksum, howmany weighted sums, and file size.

         if (configfile == "help")
         {
              cout << "This is help here." << "\n";
              cin >> pause;
              exit(0); 
         }

// ============================================================================================
         // open configure file here and read it.
         dummyfile = loadconfig();
// ============================================================================================
         // get destination for diff3
//       destinationstrongchecksum = getstrongchecksum(file1, howmanyweightedsums, buffersize);
// ============================================================================================
//       diff3 = abs(destinationstrongchecksum - targetstrongchecksum);
         diff3 = 999999999;
// ============================================================================================
//        comparetest == 0; // we start out and roll counter till both the experimental and the control are completely different
// ============================================================================================   
         // Open list.txt here      
         fstream c1myfile1("list.txt", ios::in);
// ============================================================================================         
        // run main loop for file construction
        do
        {
// ============================================================================================
              // Read list.txt
              c1myfile1 >> file1;

              // get destination
              destinationstrongchecksum = getstrongchecksum(file1, howmanyweightedsums, buffersize);

             
              // break loop if diff3 == 0
              if (abs(targetstrongchecksum - destinationstrongchecksum) == 0)
              {
                   if (targetstrongchecksum == destinationstrongchecksum)
                   {
                        system("rm closestsum.bin"); 
                        result= rename( file1.c_str() , "closestsum.bin" );
                        if ( result == 0 )
                        {
                             cout << "File successfully renamed" << "\n";
                             
                        }
                        else
                        {
                             cout << "Error renaming file" << "\n";
                             cin >> pause;
                        }

                        break;
                   }
              }

              // if abs(destination - target) < diff3 then backup counter 
              if (abs(targetstrongchecksum - destinationstrongchecksum) < diff3)
              {      system("rm closestsum.bin"); 
//                   system("cp counter.bin counterbak.bin"); // use cpp file commands here

                     result= rename( file1.c_str() , "closestsum.bin" );

                     if ( result == 0 )
                     {
                          cout << "File successfully renamed" << "\n";
                     }

                     if ( result != 0 )
                     {
                     
                          cout << "Error renaming file" << "\n";
                          cin >> pause;
                     }
 
              // if abs(destination - target) < diff3 then diff3 = abs(destination - target)
                   diff3 = abs(destinationstrongchecksum - targetstrongchecksum);

              }

              // check lock file
              dummyfile = checklockfile(lockfile);
 
              // display output (for testing only)
              cout << "Diff3 " << diff3 << " Destination sum " << destinationstrongchecksum << " Target sum " << targetstrongchecksum << "\n";

//              dummyfile = viewfile1(file1, buffersize, filesize1);

// ============================================================================================
        // end main loop for file construction   
        } while(!c1myfile1.eof()); // Change this to exit at end of file
        c1myfile1.close();
        c1myfile1.clear();
        c1myfile1.flush();
           
        // End program
        exit(0);  

    }
// ===========================================================================================
