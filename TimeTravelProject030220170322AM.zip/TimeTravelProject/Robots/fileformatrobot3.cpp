// ===========================================================================================
// declare includes
#include <cstdlib>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <string>
#include <cmath>
#include <ctime>
#include <cstdio>
#include <iostream>
#include <stdio.h>
// ===========================================================================================
// declare name space
using namespace std;
// declare subs
//============================================================================================
int main (int argc, char *argv[])
{
    // declare variables
    string list;
    string formats;
    string rejectformat;
    string pause;
    // All files must be named in alphabetical order!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    // Get file format list

//    system("ls *targets* > list.txt"); // ENTER YOUR PREFEX OR EXTENSION OF YOUR TIME TRAVEL COMPUTER MEDIA FILES BETWEEN **
//    system("file *targets* -b > formats.txt"); // ENTER YOUR PREFEX OR EXTENSION OF YOUR TIME TRAVEL COMPUTER MEDIA FILES BETWEEN **
//    cout << "Edit your list.txt and formats.txt for any unantended files to delete then hit any key and enter." << "\n";
    cout << "Make sure you have moved your time travel media files to the robot checking folder." << "\n";
    cout << "Make sure you have created a formats reject list called formatsreject.txt." << "\n";
    cout << "Enter your file formats to reject in this list. Can run file * on some files to get a bearing of what you need." << "\n";
    cout << "Hit any key and enter to continue." << "\n";
    cin >> pause;


    fstream c1myfile1;
    fstream c1myfile2;
    fstream c1myfile3;

    // open file list
    c1myfile1.open("list.txt", ios::in);
    if (!c1myfile1)
    {
         cout << "Something went wrong file list" << "\n";
         exit(0);
    }

    // open file format list
    c1myfile2.open("formats.txt", ios::in);
    if (!c1myfile2)
    {
         cout << "Something went wrong format list" << "\n";
         exit(0);
    }

    do // All these files must be in the correct alphabetical order or this will not work.
    {
         // read file list
         c1myfile1 >> list;
//         cout << " list " << list << "\n";
         // read format list
         c1myfile2 >> formats;
//         cout << " file format " << formats << "\n";
         // open reject list
         c1myfile3.open("formatsreject.txt", ios::in);
         if (!c1myfile3)
         {
              cout << "Something went wrong format list" << "\n";
              exit(0);
         }
         // start do loop
         do
         {
              // read reject list
              c1myfile3 >> rejectformat;
              cout << list << " " << formats << " " <<  rejectformat << "\n";

              // if format = reject delete file
              if (formats == rejectformat)
              {
                   // delete file
//                   remove(list.c_str());
                     if( remove( list.c_str() ) != 0 )
                     perror( "Error deleting file" );
                     else
                     puts( "File successfully deleted" );

                   // break
                   break;
              }
         } while(!c1myfile3.eof());

        // close formatsreject.txt
        c1myfile3.close();
        c1myfile3.clear();
        c1myfile3.flush();


    } while(!c1myfile1.eof());
    // close list.txt
    c1myfile1.close();
    c1myfile1.clear();
    c1myfile1.flush();

    // remove list.txt
    system("rm list.txt");

    // close formats.txt
    c1myfile2.close();
    c1myfile2.clear();
    c1myfile2.flush();

    // remove list.txt
    system("rm formats.txt");


    exit(0);
 
//       if (!c1myfile1.eof())
//         {
//              getline (c1myfile1,dummy1, ':');
//              getline (c1myfile1,dummy2);
//              size_t found = dummy2.find("data");
//              if (found < 100)
//              { 
//                   if (dummy2.size() < 20)
//                   {
//                        if( remove( dummy1.c_str() ) != 0 )
//                        perror( "Error deleting file" );
//                        else
//                        puts( "File successfully deleted" );(
//                   }
//              }
//         }
    
}
