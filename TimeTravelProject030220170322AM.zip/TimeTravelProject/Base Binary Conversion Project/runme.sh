#!/bin/bash

g++ differencefilescreater.cpp -o differencefilescreater
g++ BCtimescanner.cpp -o BCtimescanner
g++ BCtimescanner2.cpp -o BCtimescanner2
g++ CodeBaseBinaryConverter.cpp -o CodeBaseBinaryConverter
g++ DecodeBaseBinaryConverter.cpp -o DecodeBaseBinaryConverter
g++ generaterandomtxt.cpp -o generaterandomtxt


