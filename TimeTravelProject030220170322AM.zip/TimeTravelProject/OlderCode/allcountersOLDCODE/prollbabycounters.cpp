// COPYRIGHT(C) 2016 http://time-travel.institute
// this is a dependecy for firecodes and timetravel
// Roll counter for reconstruction of baby sums 
// g++ probabycounters.cpp -o prollbabycounters
#include <cstdlib>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <string> 
#include <cmath>
#include <ctime>
#include <cstdio>
#include <iostream>
#include </home/reactor1967/mersennetwister.h> // This is a dependancy.

using namespace std;


// Start main
int main (int argc, char *argv[])
{
   // declare variables
     long long count1 = 0;
     long long count2 = 0;
     int byte1 = 0;
     int byte2 = 0;
     int byte3 = 0;
     int byte4 = 0;
     double long destinationbabysum;
     double long targetbabysum;
     long double destinationadultsum;
     long double targetadultsum;
     long long begin1;
     unsigned char buffer;
     long double x1;
     long long chevron;
     char pause;
     int buffersize = 1;
     string dummy;
     long double scksum;
     long long checksum;
     long long weaksum;
     int carry = 0;
     int abc = 0;
     int sizeoflastcounter = 0;
     long long filesize2 = 0;
     long long filesize3 = 0;  
// ========================================= variables to pass to program
     string file1;
     long long filesize1;
     long long babycounters; // don't need this
     long long howmanyweightedsums;
     string file2;
     long long password2;
// =========================================


// ===================================================================================== GET PROGRAM ARGUMENTS HERE
//                      binary file                                                       config file
// int RollBabyCounters(string file1, long long filesize1, long long howmanyweightedsums, string file2, long long password2)

    // passing command line arguments to program 
    file1 = argv[1];

       // set file2
   file2 = argv[2];

    // passing command line arguments to program
    howmanyweightedsums = strtoull(argv[3],NULL,10);


   // PASSWORD FOR CALCULATING WEIGHTED SUMS
   password2 = strtoull(argv[4],NULL,10);
   
// ===================================================================================== END GET PROGRAM ARGUMENTS HERE
  
     MTRand mtrand1a(password2);

     // Load configure file
     fstream c1myfile(file2.c_str(), ios::in);
     if (!c1myfile)
     {
          cout << "Error in line 256.\n";
          cin >> pause;
          c1myfile.close();
          c1myfile.clear();
          c1myfile.flush();
     }


     // open counter file
     fstream myfile1(file1.c_str(), ios:: out | ios:: binary);
     if (!myfile1)
     {
          cout << "Error in line 209 view file.\n";
          cin >> pause;
          myfile1.close();
          myfile1.clear();
          myfile1.flush();
          exit(1); // terminate with error
     }

     // adultsum = 0; 
     targetadultsum = 0;

     // babysum = 0; 
     targetbabysum = 0;

     // Set count1 for writing bytes to file
     count1 = -1;      
     // start second loop
     do // Read baby check sum
     {
          // read check sum from list
          c1myfile >>  dummy >> dummy >> targetbabysum >> dummy >> dummy >> weaksum >> dummy >> dummy >> filesize2;
          if (c1myfile.eof())
          {
               break;
          }
   
         // set file size 3 for construction of weak sum in counter
          filesize3 = filesize2;

          // Set bytes and carry to zero
//        byte1 = 64; byte2 = 66; byte3 = 67; byte4 = 10; carry = 0;                    
          byte1 = 0; byte2 = 0; byte3 = 0; byte4 = 0; carry = 0;

          if (targetbabysum == 0)
          {
               goto jump;
          }           
          
          if (filesize3 > 0)
          {
               if (weaksum >= 255)
               {
                    byte1 = 255;
                    weaksum = weaksum - 255;
                    filesize3--;
               }
               else
               {
                    byte1 = weaksum;
                    weaksum = 0;
                    filesize3--;
               }                      

          }

          if (filesize3 > 0)
          {
               if (weaksum >= 255)
               {
                    byte2 = 255;
                    weaksum = weaksum - 255;
                    filesize3--;
               }
               else
               {
                    byte2 = weaksum;
                    weaksum = 0;
                    filesize3--;
               }                      

          }

          if (filesize3 > 0)
          {
               if (weaksum >= 255)
               {
                    byte3 = 255;
                    weaksum = weaksum - 255;
                    filesize3--;
               }
               else
               {
                    byte3 = weaksum;
                    weaksum = 0;
                    filesize3--;
               }                      

          }

          if (filesize3 > 0)
          {
               if (weaksum >= 255)
               {
                    byte4 = 255;
                    weaksum = weaksum - 255;
                    filesize3--;
               }
               else
               {
                    byte4 = weaksum;
                    weaksum = 0;
                    filesize3--;
               }                      

          }      
          
          // start third loop
          do // Construct baby check sum
          { 
               filesize3 = filesize2;

               // run counter for 4 bytes then exit
               if (filesize3 > 0)
               {
                    filesize3--;
                    byte1 = byte1 + 255;
                    if (byte1 > 255)
                    {
                         carry = 1;
                         byte1 = byte1 - 256;
                    }
                    else
                    {
                         carry = 0;
                    }
               }   

               if (filesize3 > 0)
               {

                    filesize3--;
                    if (carry == 1)
                    {
                         byte2++;
                         carry = 0;
                         if (byte2 > 255)
                         {
                              byte2 = byte2 - 256;
                              carry = 1;
                         }
                    }
               }

               if (filesize3 > 0)
               {
                    if (carry == 1)
                    {
                         filesize3--;
                         byte3++;
                         carry = 0;
                         if (byte3 > 255)
                         {
                              byte3 = byte3 - 256;
                              carry = 1;
                         }
                    }
               }

               if (filesize3 > 0)
               {

                    if (carry == 1)
                    {
                         filesize3 = 0;
                         byte4++;
                         carry = 0;
                         if (byte4 > 255)
                         {
                              byte4 = byte4 - 256;
                              carry = 0; // We don't advance carry anymore. Counter can roll over.
                         }
                    }
               }  
               
               // Set random number seed.
               mtrand1a.seed(password2);

               // set destinationsum to 0
               destinationbabysum = 0;

              // set filesize 3 again
              filesize3 = filesize2;

               // compute baby sum for 4 bytes then exit
               if (filesize3 > 0)
               {
                    filesize3--;
                    count2 = 0;
	            do // computing Strong check sum for byte 1 for howmanychecksums
                    {
                         count2++;
		         x1 = mtrand1a.randExc(.9999999);
                         destinationbabysum = destinationbabysum + (byte1 * x1);
                    } while(count2 < howmanyweightedsums);
               }
      
               if (filesize3 > 0)
               {
                    filesize3--;
                    count2 = 0;
	            do // computing Strong check sum for byte 1 for howmanychecksums
                    {
                         count2++;
		         x1 = mtrand1a.randExc(.9999999);
                         destinationbabysum = destinationbabysum + (byte2 * x1);
                    } while(count2 < howmanyweightedsums);
               }

               if (filesize3 > 0)
               {

                    filesize3--;
                    count2 = 0;
	            do // computing Strong check sum for byte 1 for howmanychecksums
                    {
                         count2++;
		         x1 = mtrand1a.randExc(.9999999);
                         destinationbabysum = destinationbabysum + (byte3 * x1);
                    } while(count2 < howmanyweightedsums);
               }
               
               if (filesize3 > 0)
               {
                    filesize3--;
                    count2 = 0;
	            do // computing Strong check sum for byte 1 for howmanychecksums
                    {
                         count2++;
		         x1 = mtrand1a.randExc(.9999999);
                         destinationbabysum = destinationbabysum + (byte4 * x1);
                    } while(count2 < howmanyweightedsums);
               }                     

               // End loop when baby check sum constructed
          } while(destinationbabysum != targetbabysum);
jump:
         
         // set filesize 3
         filesize3 = filesize2;

         if (filesize3 > 0)
         {
              // decrement filesize3
              filesize3--;
              // write byte1, byte2, byte3, byte4 to counter file 
              count1++;
              buffer = (unsigned char)byte1;
              myfile1.seekp(count1);
              myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
              begin1 = myfile1.tellp();
              if (count1 == filesize1 - 1) // for when we have a partial counter
              {
//                   break;
              }
          }

         if (filesize3 > 0)
         {
              // decrement filesize 3
              filesize3--;
              // write byte1, byte2, byte3, byte4 to counter file 
              count1++;
              buffer = (unsigned char)byte2;
              myfile1.seekp(count1);
              myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
              begin1 = myfile1.tellp();
              if (count1 == filesize1 - 1) // for when we have a partial counter
              {
//                   break;
              }
         }
         
         if (filesize3 > 0)
         {
              // decrement filesize 3
              filesize3--;
         
              // write byte1, byte2, byte3, byte4 to counter file 
              count1++;
              buffer = (unsigned char)byte3;
              myfile1.seekp(count1);
              myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
              begin1 = myfile1.tellp();
              if (count1 == filesize1 - 1) // for when we have a partial counter
              {
//                  break;
              }
         }
         
         if (filesize3 > 0)
         {
              // decrement filesize 3
              filesize3--;
         
              // write byte1, byte2, byte3, byte4 to counter file 
              count1++;
              buffer = (unsigned char)byte4;
              myfile1.seekp(count1);
              myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
              begin1 = myfile1.tellp();
              if (count1 == filesize1 - 1) // for when we have a partial counter
              {
//                   break;
              }
         }
         
    } while(!c1myfile.eof());
    myfile1.close();
    myfile1.clear();
    myfile1.flush();
    c1myfile.close();
    c1myfile.clear();
    c1myfile.flush();

    remove (file2.c_str());
    exit(0);    
// end main
}

