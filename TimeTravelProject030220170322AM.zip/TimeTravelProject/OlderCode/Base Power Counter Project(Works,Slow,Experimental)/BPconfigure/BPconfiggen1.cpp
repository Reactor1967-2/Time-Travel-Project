// COPYRIGHT(C) 2017 http://time-travel.institute

// This generates a configure file that can be used to setup a random number generator to find time travel computer media files
// ============================================================================================
 // declare includes
#include <cstdlib>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <string> 
#include <cmath>
#include <ctime>
#include <cstdio>
#include <iostream>
// ============================================================================================
// Declare namespace
using namespace std;
// ============================================================================================
// Declare subs// ======================================================================================================================
// open list of file. Get weak check sum for files and write then to weaksum.txt with file names
    int getweaksumsfilelist(int buffersize)
    {
         // declare variables
         fstream c1myfile1("list.txt", ios::in);
         fstream c1myfile2("weaksums.txt", ios::out);
         string file1; 
         fstream myfile1;
         int x;
         long long checksum = 0;
         long long begin1;
         long long count1;
         long long count2;
         unsigned char buffer(buffersize);
         long long size1;
         long long size2;
         long long filesize;
         string pause;
         // open main loop
         do
         {
              // read list
              c1myfile1 >> file1;
//              cout << file1 << "\n";
              if (c1myfile1.eof())
              {
                   break;
              }

              // get weak check-sum of file
// Start getting weak check sum
              // open file1
              myfile1.open(file1.c_str(), ios:: in | ios:: binary);
              if (!myfile1)
              {
                   cout << "122608-12:02 am Unable to open file.\n";
                   cin >> pause;
                   exit(1); // terminate with error
              }
              // get file size
              myfile1.seekg(0, ios::beg);
              size1 = myfile1.tellg();
              myfile1.seekg(0, ios::end);
              size2 = myfile1.tellg();
              filesize = size2 - size1;
              // set checksum to 0
              checksum = 0;
              // set count1 to 0
              count1 = -1;
              // start first loop
              do
              {
                   // count1 = count1 + buffersize2
                   count1 = count1 + buffersize;
                   // read byte
                   begin1 = myfile1.tellg();
                   myfile1.seekg(count1);
                   if (!myfile1)
                   {
                        myfile1.close();
                        cout << "error in line 51.\n";
                        cin >> pause;
                        exit(1);
                   }
                   myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
                   x = (int)buffer;
                   // calculate weak check sum
                   checksum = checksum + x;
              // end first loop while (count1 < ((filesize - 1) + buffersize2))
              } while (count1 <  filesize - 1);
              // close files
              myfile1.close();
              myfile1.clear();
              myfile1.flush();
// END GETTING WEAK CHECK STRONG
              if (c1myfile1.eof())
              {
                   break;
              }
              // write weak check-sum to file
              c1myfile2 << " Name= " << file1 << " file-size= " << filesize << " Weak-check-sum= " << checksum << "\n";
        // repeat main loop to end of file
         } while(!c1myfile1.eof());
        // close list.txt
         c1myfile1.close();
         c1myfile1.clear();
         c1myfile1.flush();
        // close weaksums.txt
         c1myfile2.close();
         c1myfile2.clear();
         c1myfile2.flush();
        // return(0);
        return(0);
    } 
// ======================================================================================================================


// ============================================================================================
int main (int argc, char *argv[])
{
   int dummyfile;
   int buffersize;
// passing command line arguments to program
    if ( argc > 1 ) 
    {
         buffersize = atoi( argv[1] );
    }
    if (argc < 1)
    {
         cout << "I need the buffersize to run" << "\n";
         exit(1);
    }
    dummyfile = getweaksumsfilelist(buffersize);
    // exit program
    exit(0);

}
