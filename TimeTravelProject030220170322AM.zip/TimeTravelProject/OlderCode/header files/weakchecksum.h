#ifndef weakchecksum_h
#define weakchecksum_h

     #include <cstdlib>
     #include <iostream>
     #include <stdlib.h>
     #include <fstream>
     #include <sstream>
     #include <string> 
     #include <cmath>
     #include <ctime>
     #include <cstdio>
     #include <iostream>
// ======================================================================================================================
    // Declare namespace
    using namespace std;
// ============================================================================================
long long binaryreadwrite(string whatdo, string file1, long long byteposition, long long byte, long long buffersize)
{

     long long buffer = buffersize;
     char pause;
     long long byte1 = byte;
     long long count1 = byteposition;
     long long begin1;
     
       
     // open file
      fstream myfile1(file1.c_str(), ios::out  | ios::in | ios::binary);
     if (!myfile1)
     {
          myfile1.close();
          cout << "error in line 266" << " " << file1 << "\n";
          cin >> pause;
          exit(1);
     }
     if (whatdo == "read")
     {
// cout << byte1 << " We are reading bytes " << "\n"; // debug code
          myfile1.seekg(count1);
          myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellg();
          byte1 = buffer;
          myfile1.close();
          myfile1.clear();
          myfile1.flush();
          return(byte1);
     }
     if (whatdo == "write")
     {
// cout << byte1 << " We are writing bytes " << "\n"; // debug code
          buffer = byte1;
          myfile1.seekp(count1);
          myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellp();
          myfile1.close();
          myfile1.clear();
          myfile1.flush();
          return(0);
     } 
     

     cout << "Error in binary read and write" << "\n";
     cin >> pause;
     exit(1);
}
// ============================================================================================
// ======================================================================================================================
long long filesize(string file1)
{
// declare variables
    long long begin1;
    long long end1;
    long long filesize1;
    string pause;  
//    string file1 = globalfile;
      
    // open file1
     fstream myfile1(file1.c_str(), ios::in | ios::binary);
     if (!myfile1)
     {
          myfile1.close();
          cout << "Failed to read file one line 134.\n";
          cin >> pause;
          exit(1);
     }

// get filesize1
     begin1 = myfile1.tellg();
     if (!myfile1)
     {
          myfile1.close();
          cout << "Failed to read file one line 316.\n";
          cin >> pause;
          exit(1);
     }
     myfile1.seekg (0, ios::end);
     end1 = myfile1.tellg();
     filesize1 = (end1-begin1);     

// close file 1
     myfile1.close();
     myfile1.clear();
     myfile1.flush();

// return filesize
     return(filesize1);
// end sub
}
// ======================================================================================================================
// ======================================================================================================================
#endif 
