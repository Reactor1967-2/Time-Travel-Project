// COPYRIGHT(C) 2017 http://time-travel.institute
// This is used to compare base power check-sum files
#ifndef compare_h
#define compare_h

#include <cstdlib>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <string> 
#include <cmath>
#include <ctime>
#include <cstdio>
#include <iostream>

// ======================================================================================================================
    // Declare namespace
    using namespace std;
// ======================================================================================================================
int comparechecksums(string file1,string file2,int buffersize)
{
         int test;
         int test2;
         long long tempnum1;
         long long tempnum2;
         long long pbnum1;
         long long pbnum2;
         long long count2;
         long long count1;
         fstream c1myfile2;
         fstream c1myfile3;

         // compare addition file to check-sum file
         // open addition file
         c1myfile2.open(file1.c_str(), ios::in);

         // open check sum file
         c1myfile3.open(file2.c_str(), ios::in);

         // set count1 and count2 to 0
         count1 = 0;
         count2 = 0;         
         // set pbnum1 to 0
         pbnum1 = 0;
         // set pbnum2 to 0
         pbnum2 = 0;

         // start do loop
         do
         {
              tempnum1 = 0;
              // read addition
              if (!c1myfile2.eof( ))
              {
                   c1myfile2 >> tempnum1;
                   if (tempnum1 > 0)
                   { 
                        count1++;
                   }
              }

              tempnum2 = 0;
              // read check sum
              if (!c1myfile3.eof( ))
              {
                   c1myfile3 >> tempnum2;
                   if (tempnum2 > 0)
                   {
                        count2++;
                   }
              }
              
              if (tempnum1 != tempnum2)
              {
                   pbnum1 = tempnum1;
                   pbnum2 = tempnum2;

              }

              // set test2 to 0
              test2 = 0;

              if (!c1myfile2.eof( ))
              {
                   test2 = 1;
              }

              if (!c1myfile3.eof( ))
              {
                   test2 = 2;
              }

         // end loop at end of file for addition and check sum file
         } while(test2 > 0); 

         // close addition and check-sum file
         // close temp file
         c1myfile2.close();
         c1myfile2.clear();
         c1myfile2.flush();

         // close power file
         c1myfile3.close();
         c1myfile3.clear();
         c1myfile3.flush();


         // initilize test
         test = 0;
         // if addition file point greater than check sum test = 1
         if (count1 > count2)
         {
              test = 1;
         } 
         // if check sum file point greater then addition test = 2
         if (count1 < count2)
         {
              test = 2;
         } 
         // if addition and checksum equal and addition number greater test = 1
         if (count1 == count2)
         {
                   if (pbnum1 > pbnum2)
                   {
                        test = 1;
                   }
         } 

         // if addition and checksum equal and checksum number greater test = 2
         if (count1 == count2)
         {
                   if (pbnum1 < pbnum2)
                   {
                        test = 2;
                   }
         }  

         // if addition and checksum file pointer and number equal test = 0
         if (count1 == count2)
         {
                   if (pbnum1 == pbnum2)
                   {
                        test = 0;
                   }
         }

         return(test);

// debugging
//if (test == 2 || test  == 0)
//{ 
//    cout << test << "\n";
//    cout << count1 << " " << count2 << " " << count3 << "\n";
//    cout << pbnum1 << " " << pbnum2 << " " << pbnum3 << "\n";
//    cout << byte1 << "\n";
//    myfile1.close();
//    myfile1.clear();
//    myfile1.flush();
//    cin >> pause;
//} 
     // exit sub
     return(0);
}
// ============================================================================================
string compairehigh(string high, int buffersize)
{

    int test;
    string file1;
    string file2;
    int dummyfile;

    // open list
    fstream c1myfile1("list.txt", ios::in);
    if (!c1myfile1)
    {
         cout << "There is no file list." << "\n";
         c1myfile1.close();
         c1myfile1.clear();
         c1myfile1.flush();
         exit(0);           
    }
    // start loop
    do
    {
         // read list 
         if (!c1myfile1.eof( ))
         {
              c1myfile1 >> file1;
              c1myfile1 >> file2;
         }
         // code file
         dummyfile = comparechecksums(file1,file2,buffersize);
         
         if (test == 1)
         {
              high = file1;
         }         
    // repeat loop till end of file
    } while(!c1myfile1.eof());
    // close list
    c1myfile1.close();
    c1myfile1.clear();
    c1myfile1.flush();
    // return
    return(high);   
}    
// ============================================================================================
string compairelow(string low, int buffersize)
{

    int test;
    int dummyfile;
    string file1;
    string file2;
    

    // open list
    fstream c1myfile1("list.txt", ios::in);
    if (!c1myfile1)
    {
         cout << "There is no file list." << "\n";
         c1myfile1.close();
         c1myfile1.clear();
         c1myfile1.flush();
         exit(0);           
    }
    // start loop
    do
    {
         // read list 
         if (!c1myfile1.eof( ))
         {
              c1myfile1 >> file1;
              c1myfile1 >> file2;
         }
         // code file
         dummyfile = comparechecksums(file1,file2, buffersize);
         
         if (test == 0)
         {
              low = file1;
         }  
          
         if (test == 2)
         {
              low = file1;
         }     
    
    // repeat loop till end of file
    } while(!c1myfile1.eof());
    
    // close list
    c1myfile1.close();
    c1myfile1.clear();
    c1myfile1.flush();
    // return
    return(low);   
}    
// ============================================================================================
#endif 
