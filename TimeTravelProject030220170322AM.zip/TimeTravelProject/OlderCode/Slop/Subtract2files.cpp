// THIS PROGRAM SUBTRACTS TWO FILES
// RUN IT LIKE THIS ./Subtract2files Largerfile Smallerfile
// It creates out.bin
// COPYRIGHT(C) 2017 http://time-travel.institute
// USE THIS FOR THE BINARY GENERATOR
// ============================================================================================
// declare includes
#include <cstdlib>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <string> 
#include <cmath>
#include <ctime>
#include <cstdio>
#include <iostream>
// ============================================================================================
    // Declare namespace
using namespace std;
// ============================================================================================     
// declare subs
// ============================================================================================
long long filesize(string file1)
{
// declare variables
    long long begin1;
    long long end1;
    long long filesize1;
    string pause;

    // open file1
    fstream myfile1(file1.c_str(), ios::in | ios::binary);
    if (!myfile1)
    {
         myfile1.close();
         cout << "Failed to read file one line 134.\n";
         cin >> pause;
         exit(1);
    }

// get filesize1
    begin1 = myfile1.tellg();
    if (!myfile1)
    {
         myfile1.close();
         cout << "Failed to read file one line 316.\n";
         cin >> pause;
         exit(1);
    }
    myfile1.seekg (0, ios::end);
    end1 = myfile1.tellg();
    filesize1 = (end1-begin1);     

// close file 1
    myfile1.close();
    myfile1.clear();
    myfile1.flush();

// return filesize
    return(filesize1);
// end sub
}
// ======================================================================================================================
// ======================================================================================================================
int binaryreadwrite(string whatdo, string file1, long long byteposition, int byte, int buffersize)
{

    unsigned char buffer(buffersize);
    char pause;
    int byte1 = byte;
    long long count1 = byteposition;
    long long begin1;
       
    // open file
    fstream myfile1(file1.c_str(), ios::out  | ios::in | ios::binary);
    if (!myfile1)
    {
         myfile1.close();
         cout << "error in line 79" << " " << file1 << "\n";
         cin >> pause;
         exit(1);
    }
    if (whatdo == "read")
    {
// cout << byte1 << " We are reading bytes " << "\n"; // debug code
         myfile1.seekg(count1);
         myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
         begin1 = myfile1.tellg();
         byte1 = (int)buffer;
         myfile1.close();
         myfile1.clear();
         myfile1.flush();
         return(byte1);
    }
    if (whatdo == "write")
    {
// cout << byte1 << " We are writing bytes " << "\n"; // debug code
         buffer = (unsigned char)byte1;
         myfile1.seekp(count1);
         myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
         begin1 = myfile1.tellp();
         myfile1.close();
         myfile1.clear();
         myfile1.flush();
         return(0);
    } 
     

    cout << "Error in binary read and write" << "\n";
    cin >> pause;
    exit(1);
}
// ======================================================================================================================

// ============================================================================================
// declare main
int main (int argc, char *argv[])
{
         string file1; // output file or difference file
         string file2; // Smaller file
         string destinationfile; // Large file
         string pause;  
         int  dummyfile;
         string  whatdo;
         int byte;
         int byte1;
         int byte2;
         int byte3;
         int carry;
         int count2;
         fstream myfile1;
         long long filesize2;
         long long filesize3;
         int buffersize;

         file1 = "Out.bin";
         buffersize = atoi( argv[1]);
         destinationfile = argv[2]; // Name of random number seed file. We are not using this just yet.
         file2 = argv[3]; // file extension for target files.

         filesize2 = filesize(destinationfile);
         filesize3 = filesize(file2);
         long long numberbase = (buffersize * 255) + 1;


         myfile1.open(file1.c_str(), ios::out  | ios::binary);
         if (!myfile1)
         {
              myfile1.close();
              cout << "error in line 207" << " " << file2 << "\n";
              cin >> pause;
              exit(1);
         }
         myfile1.close();
         myfile1.clear();
         myfile1.flush();



         carry = 0;
         count2 = buffersize * -1;
         // start third loop
         do
         {
              // increment file variable
              count2 = count2 + buffersize;

              // set byte1 to zero
              byte1 = 0;

              // read byte1 if less than filesize
              whatdo = "read";

              if (count2 < filesize2 - 1)
              {
                   byte1 = binaryreadwrite(whatdo, destinationfile, count2, byte, buffersize);
              }
              // // set byte2 to 0
              byte2 = 0;

              // read byte2 if less than filesize
              if (count2 < filesize3 - 1)
              {
                   byte2 = binaryreadwrite(whatdo, file2, count2, byte, buffersize);
              }

              // byte3 = byte1 - byte2 - carry;
              byte3 = byte1 - byte2 - carry;

              // carry = 0;
              carry = 0;

              // if byte < 0 subtract from the base
              if (byte3  < 0)
              {
                   byte3 = byte3 + numberbase;
                   carry = 1;
              }

              // Check for error
              if (byte3 > (numberbase - 1))
              {
                   cout << "Houston we have a problem\n";
                   cout << "byte3 greater than the base - 1\n";
                   cin >> pause;
                   exit(0);
              }

              // write random binary
              whatdo = "write";
              dummyfile = binaryreadwrite(whatdo, file1, count2, byte3, buffersize);


         // end third loop
         } while(count2 < filesize2 - 1); // use the largest file size here. We are subtracting for the difference.

         // if carry has value write it
         if (carry > 0)
         {
              // write random binary
              whatdo = "write";
              dummyfile = binaryreadwrite(whatdo, file1, count2, carry, buffersize);
              // write to addition file              
              carry = 0;
         }

    exit(0);
 
}
