//-----------------------------------------------------------   Program Plan   ------------------------------------------------------------------------    
// declare variables
// open network master file retrieve values
// close network master file
// node loop one (for nodes)
     // increment node count
     // open node master file retrieve values
     // close node master file
     // declare input data base array
     // open data base
     // open temp file
     // open database loop
          // open loop two (for inputs)
               // read database into array
               // compute weighted sum of inputs
          // close loop two
          
          // open loop three (for temp file
               // write data base array with weighted sum of inputs
               // clear array variables after writting them
          // end loop three
     // end data base loop (till end of data base)
     // close data base
     // delete database file
     // close temp file
     // reopen data base file
     // reopen temp file
          // open loop four (copy temp file to data base file)
               // read temp file
               // write to data base file
          // close loop four
          // close temp
          // close data base file
     // delete temp file
// end loop one (for nodes)
// delete input database input array
//-----------------------------------------------------------   Program Plan   ------------------------------------------------------------------------         
#include <cstdlib>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <string>
#include <cmath>
#include <d:\mersennetwister.h> 
#include <stdio.h>

using namespace std;

int main (int argc, char *argv[])

{
// declare variables
     long long countnodes = 0;
     
     string file0 = "";
     string file1 = "";
     string file2 = "";
     string file5 = "";
     string file6 = "";
     
     fstream myfile0;
     fstream myfile1;
     fstream myfile2; 
     fstream myfile6;

     int x = 0;
     string networktype = ""; // Holds the type of neural network we are working with. // Make this change in train and create ann too.
     string nodetype = ""; // Holds input, worker, or output nodetype
     string mext = ".masterfile"; // extension to denote master file.
     string miext = ".inputmasterfile";
     string dext = ".database"; // extension to denote data base file.
     string text = ".temp";
     long double inputs;
     long double outputs;
     long long totalnodes;
     long long nodes;
     long long maxlayers;
     long long nodeinputs;
     long long nodeoutputs;
     long double weightedsum;
     long long count;
     long long previousnode;
     long double readinput;
     long double weight;
     
// open network master file retrieve values
     std::stringstream ss;    
     
     // open neural net master file and load variables

     file0 = "neuralnet.masterfile";
     myfile0.open(file0.c_str(), ios:: in);
     if (!myfile0)
     {
          myfile0.close();
          cout << "Failed to read file in line 68\n";
          cin >> x;
          exit(1);
     } 
     
// close network master file
     myfile0 >> networktype >>  inputs >> outputs >> totalnodes >> nodes >> maxlayers; 
     myfile0.close();
     myfile0.flush();
     myfile0.clear();
     
// node loop one (for nodes)
     countnodes = 0;
     do
     {
     // increment node count
          countnodes++;
cout << "Now we goto node " << countnodes << "\n";
          
     // open node master file retrieve values
          ss.clear();
          file2 = "";
          ss << countnodes;
          ss >> file2;
          file2 = file2 + mext;

          // Load master 1 file and read how many inputs and outputs and assign those to variables
          myfile2.open(file2.c_str(), ios:: in); 
          if (!myfile2)
          {
               myfile2.close();
               cout << "Failed to read file in line 97\n";
               cin >> x;
               exit(1);
          }           

          // read node master file.
          myfile2 >> nodetype >> nodeinputs >> nodeoutputs;
          
          // close node master file.
          myfile2.close();
          myfile2.flush();          
          myfile2.clear();
     
     // declare input data base array
         long double previousnodes[nodeinputs];
         long double weights[nodeinputs];
         long double neuralinputs[nodeinputs];
         
     // open data base
          ss.clear();
          file6 = "";
          ss << countnodes;
          ss >> file6;
          file6 = file6 + dext;

     // append the temp file because we end it with eof which screws things up.
          myfile6.open(file6.c_str(), ios:: out | ios:: app); 
          if (!myfile6)
          {
               myfile6.close();
               cout << "Failed to read file in line 173\n";
               cin >> x;
               exit(1);
          }           

          myfile6 << -1 << " " << -1 << " " << -1 << "\n"; // So we know when to stop
          
          myfile6.close();
          myfile6.flush();
          myfile6.clear();

          myfile6.open(file6.c_str(), ios:: in); 
          if (!myfile6)
          {
               myfile6.close();
               cout << "Failed to read file in line 166\n";
               cin >> x;
               exit(1);
          }           

     // open temp file
          file1 = "temp.txt";

          myfile1.open(file1.c_str(), ios:: out); 
          if (!myfile1)
          {
               myfile1.close();
               cout << "Failed to read file in line 174\n";
               cin >> x;
               exit(1);
          }           

     // open database loop 
          do
          {

          // open loop two (for inputs)
               count = -1;
               weightedsum = 0; 
               do
               {
                    count++;
                    // read database into array
                    myfile6 >> previousnode >> readinput >> weight; 

                    if (previousnode == -1)
                    {
                         // close data base
                         myfile6.close();
                         myfile6.flush();
                         myfile6.clear();
                     
                         // close temp file
                         myfile1.close();
                         myfile1.flush();
                         myfile1.clear();
     
                         goto skip;
                    }                 

                    previousnodes[count] = previousnode;
                    neuralinputs[count] = readinput;
                    weights[count] = weight;

                    // compute weighted sum of inputs
                    weightedsum = weightedsum + (readinput * (.1 * (count + 1))); // We have to have a scheme for weighted sum comparison in runann

          // close loop two
               } while (count < nodeinputs - 1);

          // open loop three (for temp file
               count = -1;
               do
               {
                    count++;
                    // write data base array with weighted sum of inputs
                    myfile1 << previousnodes[count] << " " << neuralinputs[count] << " " << weights[count] << " " << weightedsum << "\n";
 
                    // clear array variables after writting them
                    previousnodes[count] = 0;
                    neuralinputs[count] = 0;
                    weights[count] = 0;
                    
          // end loop three
               } while (count < nodeinputs - 1);

     // end data base loop (till end of data base)
          } while(!myfile6.eof());

     // close data base
          myfile6.close();
          myfile6.flush();
          myfile6.clear();
                     
     // close temp file
          myfile1.close();
          myfile1.flush();
          myfile1.clear();

skip:     
     // reopen data base file
           myfile6.open(file6.c_str(), ios:: out); 
          if (!myfile6)
          {
               myfile6.close();
               cout << "Failed to read file in line 214\n";
               cin >> x;
               exit(1);
          }           

     // append the temp file with a stop variable
          myfile1.open(file1.c_str(), ios:: out | ios:: app); 
          if (!myfile1)
          {
               myfile1.close();
               cout << "Failed to read file in line 272\n";
               cin >> x;
               exit(1);
          }           

          myfile1 << -1 << " " << -1 << " " << -1 << "\n"; // So we know when to stop
          
          myfile1.close();
          myfile1.flush();
          myfile1.clear();


     // reopen temp file 
          myfile1.open(file1.c_str(), ios:: in); 
          if (!myfile1)
          {
               myfile1.close();
               cout << "Failed to read file in line 224\n";
               cin >> x;
               exit(1);
          }           

    // open loop four (copy temp file to data base file)
          do
          {
         // read temp file
               myfile1 >> previousnode >> readinput >> weight >> weightedsum; 

               if (previousnode == -1)
               {
                    break;
               }                 
         // write to data base file
               myfile6 << previousnode << " " << readinput << " " << weight << " " << weightedsum << "\n";

    // close loop four
          } while(!myfile1.eof());

     // close data base
          myfile6.close();
          myfile6.flush();
          myfile6.clear();
                     
     // close temp file
          myfile1.close();
          myfile1.flush();
          myfile1.clear();

     // delete temp file
          system("del temp.txt");
          cout << countnodes << " " << totalnodes << "\n";     

// end loop one (for nodes)
     } while(countnodes < totalnodes);

cout << "Program Completed.\n";
cin >> x;
exit(0);
}
