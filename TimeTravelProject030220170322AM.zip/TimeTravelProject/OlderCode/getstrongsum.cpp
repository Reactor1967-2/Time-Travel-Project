// COPYRIGHT(C) 2016 http://time-travel.institute
// THIS GETS A STRONG CHECK-SUM OF A COMPUTER FILE.
 // declare includes
    #include <cstdlib>
    #include <iostream>
    #include <stdlib.h>
    #include <fstream>
    #include <sstream>
    #include <string> 
    #include <cmath>
    #include <ctime>
    #include <cstdio>
    #include <iostream>
    #include "timecheckhacking.h"

// ============================================================================================
    // Declare namespace
    using namespace std;
// ============================================================================================     

// declare main
    int main (int argc, char *argv[])
    {
         string file1;
         long double sum = 0;
         long long howmanyweightedsums;
         int buffersize = 1;

         cout << "Please enter your file name" << "\n";
         cin >> file1;
         cout << "How many weighted sums" << "\n";
         cin >> howmanyweightedsums;
          
         sum = getstrongchecksum(file1, howmanyweightedsums, buffersize);;
         cout.precision(36);
         cout << sum << "\n";
        
         exit(0); 
    }

