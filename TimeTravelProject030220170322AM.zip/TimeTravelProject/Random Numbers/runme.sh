#!/bin/bash

g++ generaterandomnumbers.cpp -o generaterandomnumbers
g++ generaterandomtxt.cpp -o generaterandomtxt
g++ generateweights.cpp -o generateweights
