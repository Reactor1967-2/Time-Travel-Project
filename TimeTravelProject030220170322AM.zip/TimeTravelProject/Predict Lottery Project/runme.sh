#!/bin/bash

g++ lotteryAI.cpp -o lotteryAI
g++ lotteryAI2.cpp -o lotteryAI2
