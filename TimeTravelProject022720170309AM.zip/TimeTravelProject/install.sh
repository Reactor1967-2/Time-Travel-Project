#!/bin/bash

g++ TimeTravel.cpp -o TimeTravel

cd robotchecking

g++ airobot.cpp -o airobot
g++ fileformatrobot3.cpp -o fileformatrobot3

cd ..

cd bin

g++ BCtimescanner.cpp -o BCtimescanner
g++ CodeBaseBinaryConverter.cpp -o CodeBaseBinaryConverter
g++ DecodeBaseBinaryConverter.cpp -o DecodeBaseBinaryConverter

g++ timescanner.cpp -o timescanner

g++ weakcheck-sumcounter.cpp -o weakcheck-sumcounter

echo More upgrades are planned for this project. 
echo
echo The biggest problem with this program is information has to be entered correctly to make it work. 
echo The second biggest problem is you have to have enough entropy in /dev/random to make this work. I included some third party programs in tools under random numbers.
echo
echo The base conversion numbers have to be decoded. You can run the individual decode program or use the menu here. 
echo
echo The code in the bin directory and in the robot checking directory is my latest code. The other directories are out of date.
echo
echo Run TimeTrave like this ./TimeTravel
echo
echo Happy Time-Hacking Reactor1967
echo
echo Enjoy Ray Hudson, Darby Phillips, and Pamela.
echo You guys have been trying to get this for a long time. Well here it is.
cd ..


