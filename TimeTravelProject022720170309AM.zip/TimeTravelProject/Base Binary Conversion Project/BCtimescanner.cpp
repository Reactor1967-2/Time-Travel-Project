// CALCULATE NUMBERBASE = (256^BUFFERSIZE) + 1
// COPYRIGHT(C) 2017 http://time-travel.institute
// This program takes two files. A high file and low file.
// Then it reads a file list of files it will subtract from the high or add to the low. 
// The user tells whether or add or subtract.
// Make a file list first like this ls > list.txt
// Then edit the list for any unecessary files.
// Run the program like this // ./ProgramName Buffersize HighFileName LowFileName FileList addsubtract extension
// from the command line.
// It will output target files.
// This works on the principle that if you know any two variables you can calculate the third
// So we we know our high range and our low range and the difference we can calculate your time travel media target file.
// You will have to use a random binary file generator to make the difference files. 
// There is one at http://sourceforge.net/projects/timetravelproject/
// ============================================================================================
// Declare includes
#include <cstdlib>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <string> 
#include <cmath>
#include <ctime>
#include <cstdio>
#include <iostream>
// ============================================================================================
// Declare namespace
using namespace std;
// ============================================================================================     
// declare subs
// ============================================================================================
long long add(long long count3, long long buffersize, string destinationfile, string differencefile, string extension, long long numberbase, long long endoffile)
{
    // declare variables
    int carry;
    int test2;
    int test3;
    long long pbnum1;
    long long pbnum2;
    long long pbnum3;
    string pause;  
    string file1;

    // Reopen additon file
    fstream c1myfile2(destinationfile.c_str(), ios::in); 
    if (!c1myfile2)
    {
         cout << "Can not find destination file." << "\n";
         cin >> pause;
         exit(0);
    }
 
    // open check-sum file
    fstream c1myfile3(differencefile.c_str(), ios::in); 
    if (!c1myfile3)
    {
         cout << "Can not find difference file." << "\n";
         cin >> pause;
         exit(0);
    }

    // create temp file to hold result
    // open temp file for multiplication (This file will be renamed).
    fstream c1myfile4("temp.txt", ios::out);
    if (!c1myfile4)
    {
         cout << "Can not open temp.txt for out." << "\n";
         cin >> pause;
         exit(0);
    }

    test2 = 0;
    test3 = 0;
    if (!c1myfile2.eof())
    {
         test2 = 1;
    }

    if (!c1myfile3.eof())
    {
         test3 = 1;
    }

    // set carry to 0
    carry = 0;
    do
    {

         // set pbnum to 0
         pbnum1 = 0;
         // read addition file
         if (test2 + test3 == 2)
         {
              c1myfile2 >> pbnum1;
              if (pbnum1 == endoffile)
              {
                   break;
              }            
         }

         pbnum2 = 0;

         // check-sum file              
         if (test2 + test3 == 2)
         {
              c1myfile3 >> pbnum2;
              if (pbnum2 == endoffile)
              {
                   break;
              }            

         }

         // clear pbnum3
         pbnum3 = 0;
              
         // do base addition
         if (test2 + test3 == 2)
         {
              pbnum3 = pbnum1 + pbnum2 + carry;
         }

         // set carry to 0
         if (test2 + test3 == 2)
         {
              carry = 0;
         }

         if (test2 + test3 == 2)
         {
              // convert to base and set carry
              if (pbnum3 >= numberbase)
              {
                
                   // convert to numberbase
                   carry = pbnum3/numberbase;
                   pbnum3 = pbnum3 - (carry * numberbase);        

              }
         }
              

         // Error out if carry greater
         if (carry >= numberbase)
         {
              cout << "Carry greater than number base. line 127" << "\n";
              cin >> pause;
              exit(0);
         }

         if (pbnum3 >= numberbase)
         {
              cout << "Carry greater than number base. line 134" << "\n";
              cin >> pause;
              exit(0);
         }

         // write to addition file              
         if (test2 + test3 == 2)
         {
                   c1myfile4 << pbnum3 << "\n"; // This is a temporay fix. It might need fixed later.
         }

         if (test2 + test3 < 2)
         {
              if (carry > 0)
              {
                   c1myfile4 << carry << "\n";
                   carry = 0;
              } 
         }

         test2 = 0;
         test3 = 0;
         if (!c1myfile2.eof())
         {
              test2 = 1;
         }

         if (!c1myfile3.eof())
         {
              test3 = 1;
         }
 

    } while(test2 + test3 == 2); 


    // close temp file
    c1myfile4.close();
    c1myfile4.clear();
    c1myfile4.flush();

    // close check-sumfile file
    c1myfile3.close();
    c1myfile3.clear();
    c1myfile3.flush();

    // close addition file
    c1myfile2.close();
    c1myfile2.clear();
    c1myfile2.flush();

    // rename temp.txt count file name
    // get file name  from ss
    stringstream ss;
    file1 = "";
    ss << count3;
    ss >> file1;
    file1 = file1 + extension;
    rename("temp.txt", file1.c_str());
    return(0);
  
}
// ========================================================================================================================
long long subtract(long long count3, long long buffersize, string destinationfile, string differencefile, string extension, long long numberbase,long long endoffile)
{
    // declare variables
    string file1;
    int test2;
    string pause; 
    int carry;
    long long pbnum1;
    long long pbnum2;
    long long pbnum3;

    // Reopen additon file
    fstream c1myfile2(destinationfile.c_str(), ios::in); 
    if (!c1myfile2)
    {
         cout << "can not open destination file." << "\n";
         cin >> pause;
         exit(0);
    }


    // open check-sum file
    fstream c1myfile3(differencefile.c_str(), ios::in); 
    if (!c1myfile3)
    {
         cout << "can not open difference file." << "\n";
         cin >> pause;
         exit(0);
    }

    // open temp file
    fstream c1myfile4("temp.txt", ios::out); 
    if (!c1myfile4)
    {
         cout << "can not open temp.txt for out." << "\n";
         cin >> pause;
         exit(0);
    }

    // set carry to 0
    carry = 0;

    test2 = 0;
    if (!c1myfile2.eof())
    {
         test2++;
    }

    if (!c1myfile3.eof())
    {
         test2++;
    }


    // start do loop
    do
    {

         // set pbnum1 to 0
         pbnum1 = 0;
         
         // read destination file
         if (test2 == 2)
         {
              c1myfile2 >> pbnum1;
              if (pbnum1 == endoffile)
              {
                   break;
              }            

         }

         // set pbnum2 to 0
         pbnum2 = 0;
         // read difference file
         if (test2 == 2)
         {
              c1myfile3 >> pbnum2;
              if (pbnum2 == endoffile)
              {
                   break;
              }            

         }

         pbnum3 = 0;
         if (test2 == 2)
         {
              // byte3 = byte1 - byte2 - carry;
              pbnum3 = pbnum1 - pbnum2 - carry;
              carry = 0;
         }

         // if byte < 0 subtract from the base
         if (test2 == 2)
         {
              if (pbnum3  < 0)
              {
                   pbnum3 = pbnum3 + numberbase;
                   carry = 1;
              }
         }

         // Check for error
         if (pbnum3 > (numberbase - 1))
         {
              cout << "Houston we have a problem\n";
              cout << "pbnum3 greater than the base - 1\n";
              cin >> pause;
              exit(0);
         }

         // write remainder to temp file
         if (test2 == 2)
         {
              c1myfile4 << pbnum3 << "\n";
         }
            
         if (test2 < 2)
         {
              if (carry > 0)
              {  
                   c1myfile4 << carry << "\n";
                   carry = 0;
              }
         }

         test2 = 0;
         if (!c1myfile2.eof())
         {
              test2++;
         }

         if (!c1myfile3.eof())
         {
              test2++;
         }


         // End do loop for end of file
    } while(test2 == 2); 


    // close files
    // close addition file
    c1myfile2.close();
    c1myfile2.clear();
    c1myfile2.flush();

    // close check-sum file
    c1myfile3.close();
    c1myfile3.clear();
    c1myfile3.flush();

    // close temp file
    c1myfile4.close();
    c1myfile4.clear();
    c1myfile4.flush();

    // rename temp.txt count file name
    // get file name  from ss
    stringstream ss;
    file1 = "";
    ss << count3;
    ss >> file1;
    file1 = file1 + extension;
    rename("temp.txt", file1.c_str());
    return(0);


}
// ============================================================================================
// declare main
int main (int argc, char *argv[])
{
    // Declare variables
    long long buffersize;
    string highfile;
    string lowfile;
    string addsubtract;
    string destinationfile;
    string differencefile;
    string filelist;
    string extension;
    long long dummyfile;
    long long count3;
    long long numberbase;
    string pause;
    int test;
    long long endoffile;

    // Take command line arguments
    // ./ProgramName Buffersize HighFileName LowFileName FileList addsubtract extension numberbase
//    buffersize = atoi( argv[1]); // How many bytes we are reading at a time.
    buffersize = strtoull(argv[1],NULL,10);
    highfile = argv[2]; // High file as a number in a numerical base.
    lowfile = argv[3]; // Low file as a number in a numerical base.
    filelist = argv[4]; // filelist containing the names of the difference files. Use ls > list.txt then edit the list
    addsubtract = argv[5]; // Are we adding the differences or subtracting them.
    extension = argv[6]; // file extension to give to targets.
    endoffile = strtoull(argv[7],NULL,10); // Set this to a negative number if not using. Used to stop at end of files.

    numberbase = (pow(256,buffersize)) + 1;

    // open file list
    fstream c1myfile1(filelist.c_str(), ios::in);
    if (!c1myfile1)
    {
         cout << "There is no file list." << "\n";
         c1myfile1.close();
         c1myfile1.clear();
         c1myfile1.flush();
         exit(0);           
    }

    // if addsubtract == add
    if (addsubtract == "add")
    {
         // destination = Lowfile
         destinationfile = lowfile;
    }

    // if addsubtract = subtract
    if (addsubtract == "subtract")
    {
         // destination file = high file
         destinationfile = highfile;
    }

    // set count3 to 0
    count3 = 0;

    test = 0;
    if (!c1myfile1.eof())
    {
         test = 1;
    }
 
    // Start do loop
    do
    {

         if (test == 1)
         {
              // increment count3
              count3++; // This is the file name

              // read file list
              c1myfile1 >> differencefile;

              // if addsubtract = subtract call subtract 
              if (addsubtract == "subtract")
              {
                   dummyfile = subtract(count3, buffersize, destinationfile, differencefile, extension, numberbase, endoffile);
              }
  
              // if addsubtrct = add call add
              if (addsubtract == "add")
              {
                   dummyfile = add(count3, buffersize, destinationfile, differencefile, extension, numberbase, endoffile);
              }
         }

         test = 0;
         if (!c1myfile1.eof())
         {
              test = 1;
         }


    // repeat till end of file list
    } while(test == 1);

    // print to user "ALL TARGETS CONSTRUCTED!!!!!!"
    cout << "ALL TARGETS CONSTRUCTED!!!!!!!!!!!!!!!!" << "\n";

    // Exit program
    exit(0);
}
