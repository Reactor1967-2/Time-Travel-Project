// Declare includes
#include <cstdlib>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <string> 
#include <cmath>
#include <ctime>
#include <cstdio>
#include <iostream>
// #include "timecheckhacking2.h"
// ============================================================================================
// Declare namespace
using namespace std;
// ============================================================================================     
// declare subs
// ============================================================================================
// ============================================================================================
// declare main
int main (int argc, char *argv[])
{
    // Declare variables
    char choice;
    long long howmanyfiles;
    long long filesize1;
    string file1 = "runme.sh";
    string prefix;
    int bs;
    string pause;
    string addorsubtract;
    string build;
    long long endoffile;
    string diff;
    long long counterspeed;
    long long weakchecksum;
    string nameoftextfile;
    string file3;
atmenu:
// create menu 
    // print space
     cout << "\n";
     system("clear");

    // 1. Run a random time travel project..
     cout << "1. Run a random time travel project." << "\n";

    // 2. Run a binary time travel project.
     cout << "2. Run binary time travel project." << "\n";

    // 3. Run a encode base conversion time travel project.
     cout << "3. Run a base conversion encode time travel project." << "\n";

    // 4. Run a weak check-sum time travel project..
     cout << "4. Run a weak check-sum time travel project. " << "\n";

    // 5. Run the file format robot.
     cout << "5. Run the file format robot. " << "\n";

    // 6. Run the A.I. robot.
     cout << "6. Run the A.I. " << "\n";

     // 7. Add or subtract from binary destination file
     cout << "7. Add or subtract from your binary destination file" << "\n";;

     // 8. Add or subtract from base conversion destination file
     cout << "8. Add or subtract from your base conversion destination file" << "\n";

    // 9. Run a decode base conversion time travel project.
     cout << "9. Run a base conversion decode time travel project." << "\n";


     cout << "\n";
     
    // Enter Choice
     cout << "Enter your choice please. Type 0 and enter to exit program" << "\n";
     cin >> choice; // if choice = 1.

     if (choice == '0')
     {
         exit(0);
     }

    // if choice = 1.
     if (choice == '1')
     {
         cout << "How many time travel media files do you want. WARNING CONSIDER YOUR HARD DRIVE LIMITS!!!" << "\n"; 
         cin >> howmanyfiles;

         cout << "What is the file size for these time travel media files? WARING CONSIDER YOUR HARD DRIVE LIMITS!!!!" << "\n";
         cin >> filesize1;

         cout << "How many bytes per second do you want to run this time travel project" << "\n";
         cin >> bs;

         cout << "What is the prefix or extension of the target files?" << "\n";
         cin >> prefix;


         cout << "WARNING MAKE SURE /DEV/RANDOM HAS PLENTY OF ENTROPY!!!!!!!!!!!" << "\n";
         cout << "Hit any key and enter to start." << "\n";
         cin >> pause;

         cout << "Creating Bash scripts for the user to run." << "\n";

         // Open bash script.
         fstream c1myfile(file1.c_str(), ios::out);
         if (!c1myfile)
         {
              cout << "Unable to open file line 74 \n";
              cin >> pause;
              exit(1); // terminate with error
         }

         c1myfile << "#!/bin/bash" << "\n";
         c1myfile << "cd bin" << "\n";
         // dd if=/dev/urandom of=~/urandom_test count=4 bs=1024
         c1myfile << "echo Creating Random.bin" << "\n";
         c1myfile << "dd if=/dev/random of=random.bin count=" << filesize1 * howmanyfiles << " bs=" << bs << "\n";
         // split -b sizeoffiles random.bin prefixoftargets
         c1myfile << "echo splitting up random.bin" << "\n";  
         c1myfile << "split -b " << filesize1 << " random.bin " << prefix << "\n";
         c1myfile << "echo Run a robot" << "\n";
         c1myfile << "rm random.bin" << "\n"; 
         c1myfile << "cd .." << "\n"; 
         c1myfile << "rm runme.sh" << "\n"; 
         c1myfile.close();
         c1myfile.clear();
         c1myfile.flush();
         system("chmod 777 runme.sh");
         cout << "Your script when ran will goto the bin directory. That is where everything is ran from and that is where your computer time travel media files will be. Don't delete the executables." << "\n";  
         cout << "When your ready to run this random time travel project goto the command line and type ./runme.sh" << "\n";
         cout << "Hit any key and enter to continue." << "\n";
         cin >> pause;
         goto atmenu;
     }

     // if choice = 2.
     if (choice == '2')
     {
         cout << "How many time travel media files do you want. WARNING CONSIDER YOUR HARD DRIVE LIMITS!!!" << "\n"; 
         cin >> howmanyfiles;

         cout << "What is the file size for these time travel media files? WARING CONSIDER YOUR HARD DRIVE LIMITS!!!!" << "\n";
         cin >> filesize1;

         cout << "How many bytes per second do you want to run this time travel project" << "\n";
         cin >> bs;

         cout << "What is the prefix or extension of the target files?" << "\n";
         cin >> prefix;

         cout << "Are we adding or subtracting from the destination file?" << "\n";
         cout << "Type add or type subtract anything else won't create targets" << "\n";
         cin >> addorsubtract;

         cout << "Do you have your own destination file or do I need to build that for you? Answer yes for have your own or no I need to build it for you in lower case letters." << "\n";
         cin >> build;
   
         if (build == "yes")
         {
              cout << "Name your destination file destination.bin or this won't work." << "\n";
              cout << "Hit any key and enter to continue" << "\n";
              cin >> pause;
         }

         cout << "WARNING MAKE SURE /DEV/RANDOM HAS PLENTY OF ENTROPY!!!!!!!!!!!" << "\n";
         cout << "Hit any key and enter to start." << "\n";
         cin >> pause;

         cout << "Creating Bash scripts for the user to run." << "\n";

         // Open bash script.
         fstream c1myfile(file1.c_str(), ios::out);
         if (!c1myfile)
         {
              cout << "Unable to open file line 74 \n";
              cin >> pause;
              exit(1); // terminate with error
         }

//       buffersize = atoi( argv[1]); // How many bytes we are reading at a time.
//       highfile = argv[2]; // High file as a number in a numerical base.
//       lowfile = argv[3]; // Low file as a number in a numerical base.
//       filelist = argv[4]; // filelist containing the names of the difference files.
//       addsubtract = argv[5]; // Are we adding the differences or subtracting them.
//       extension = argv[6]; // file extension to give to targets.

         c1myfile << "#!/bin/bash" << "\n";
         c1myfile << "cd bin" << "\n";
         // dd if=/dev/urandom of=~/urandom_test count=4 bs=1024
         c1myfile << "echo Creating Random.bin for difference files" << "\n";
         c1myfile << "dd if=/dev/random of=random.bin count=" << filesize1 * howmanyfiles << " bs=" << bs << "\n";
         if (build == "yes");
         {
              c1myfile << "echo Creating destination.bin file" << "\n";
              c1myfile << "dd if=/dev/random of=destination.bin count=" << filesize1 << " bs=" << bs << "\n";
         }              
         // split -b sizeoffiles random.bin prefixoftargets
         c1myfile << "echo splitting up random.bin for difference files" << "\n";  
         c1myfile << "split -b " << filesize1 << " random.bin " << "diff" << "\n";
         c1myfile << "ls *"<< "diff" << "* > list.txt" << "\n";
         c1myfile << "./timescanner " << bs << " destination.bin " << " destination.bin " << " list.txt " << addorsubtract << " " << prefix << "\n"; // <<<<<<<<<<<<< run binary time scanner
         c1myfile << "echo Run a robot" << "\n";
         c1myfile << "rm *diff*" << "\n"; 
         c1myfile << "rm list.txt" << "\n"; 
         c1myfile << "rm random.bin" << "\n"; 
         c1myfile << "cd .." << "\n";
         c1myfile << "rm runme.sh" << "\n";
         c1myfile.close();
         c1myfile.clear();
         c1myfile.flush();
         system("chmod 777 runme.sh");
         cout << "Your script when ran will goto the bin directory. That is where everything is ran from and that is where your computer time travel media files will be. Don't delete the executables." << "\n";  
         cout << "When your ready to run this binary time travel project goto the command line and type ./runme.sh" << "\n";
         cout << "Hit any key and enter to continue." << "\n";
         cin >> pause;
         goto atmenu;
     }

     // if choice = 3.
     if (choice == '3')
     {
         cout << "How many time travel media files do you want. WARNING CONSIDER YOUR HARD DRIVE LIMITS!!!" << "\n"; 
         cin >> howmanyfiles;

         cout << "What is the file size for these time travel media files? WARING CONSIDER YOUR HARD DRIVE LIMITS!!!!" << "\n";
         cin >> filesize1;

         cout << "How many bytes per second do you want to run this time travel project" << "\n";
         cin >> bs;

         cout << "What is the prefix or extension of the target files?" << "\n";
         cin >> prefix;

         cout << "Are we adding or subtracting from the destination file?" << "\n";
         cin >> addorsubtract;

         cout << "Do you have your own destination file or do I need to build that for you? Answer yes for have your own or no I need to build it for you in lower case letters." << "\n";
         cin >> build;
   
         if (build == "yes")
         {
              cout << "Name your destination file destination.txt or this won't work." << "\n";
              cout << "Hit any key and enter to continue" << "\n";
              cin >> pause;
         }

         cout << "If you have a specific number at the end of your destination text file to exit on enter it here else enter -999" << "\n";
         cout << "If you do not know what this is just type -999 and hit enter and don't worry about it." << "\n";
         cin >> endoffile;

         cout << "WARNING MAKE SURE /DEV/RANDOM HAS PLENTY OF ENTROPY!!!!!!!!!!!" << "\n";
         cout << "Hit any key and enter to start." << "\n";
         cin >> pause;

         cout << "Creating Bash scripts for the user to run." << "\n";

         // Open bash script.
         fstream c1myfile(file1.c_str(), ios::out);
         if (!c1myfile)
         {
              cout << "Unable to open file line 74 \n";
              cin >> pause;
              exit(1); // terminate with error
         }

//    buffersize = strtoull(argv[1],NULL,10);
//    highfile = argv[2]; // High file as a number in a numerical base.
//    lowfile = argv[3]; // Low file as a number in a numerical base.
//    filelist = argv[4]; // filelist containing the names of the difference files. Use ls > list.txt then edit the list
//    addsubtract = argv[5]; // Are we adding the differences or subtracting them.
//    extension = argv[6]; // file extension to give to targets.
//    endoffile = strtoull(argv[7],NULL,10); // Set this to a negative number if not using. Used to stop at end of files.

         c1myfile << "#!/bin/bash" << "\n";
         c1myfile << "cd bin" << "\n";
         // dd if=/dev/urandom of=~/urandom_test count=4 bs=1024
         c1myfile << "echo Creating Random.bin for difference files" << "\n";
         c1myfile << "dd if=/dev/random of=random.bin count=" << filesize1 * howmanyfiles << " bs=" << bs << "\n";
         // CODE RANDOM.BIN TO A TEXT FILE BEFORE SPLITTING <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
// ./program name // name of file to create // buffersize // get name of binary file
// file2 = argv[1];
// buffersize = atoi( argv[2]); // How many bytes we are reading at a time.
// file1 = argv[3];
         c1myfile << "echo Coding Random.bin to Random.txt for difference files" << "\n";
         c1myfile << "./CodeBaseBinaryConverter random.txt "<< bs << " random.bin " << "\n";              
         c1myfile << "rm random.bin" << "\n";              
         // split -b sizeoffiles random.bin prefixoftargets
         c1myfile << "echo splitting up random.txt for difference files" << "\n";  
         c1myfile << "split -b " << filesize1 << " random.txt " << "diff" << "\n";
         c1myfile << "ls *" << " diff " << "* > list.txt" << "\n";
         if (build == "yes");
         {
              c1myfile << "echo Creating destination.bin file" << "\n";
              c1myfile << "dd if=/dev/random of=destination.bin count=" << filesize1 << " bs=" << bs << "\n";
              // CODE destination.bin TO A TEXT FILE <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
// ./program name // name of file to create // buffersize // get name of binary file
// file2 = argv[1];
// buffersize = atoi( argv[2]); // How many bytes we are reading at a time.
// file1 = argv[3];
              c1myfile << "echo Coding destination.bin file to destination.txt" << "\n";
              c1myfile << "./CodeBaseBinaryConverter destination.txt "<< bs << " destination.bin " << "\n"; 
              c1myfile << "rm destination.bin" << "\n";             
         }   
// parameters to run BCtimescanner
//    buffersize = strtoull(argv[1],NULL,10);
//    highfile = argv[2]; // High file as a number in a numerical base.
//    lowfile = argv[3]; // Low file as a number in a numerical base.
//    filelist = argv[4]; // filelist containing the names of the difference files. Use ls > list.txt then edit the list
//    addsubtract = argv[5]; // Are we adding the differences or subtracting them.
//    extension = argv[6]; // file extension to give to targets.
//    endoffile = strtoull(argv[7],NULL,10); // Set this to a negative number if not using. Used to stop at end of files.
           
         c1myfile << "./BCtimescanner " << bs << " destination.txt " << " destination.txt " << " list.txt " << addorsubtract << " " << prefix << " " << endoffile << "\n"; // <<<<<<<<<<<<< run bcbinary time scanner
         c1myfile << "echo Run a robot" << "\n";
         c1myfile << "rm list.txt" << "\n"; 
         c1myfile << "rm random.bin" << "\n";
         c1myfile << "rm *diff*" << "\n";
         c1myfile << "rm random.txt" << "\n";
         c1myfile << "cd .." << "\n";
         c1myfile << "rm runme.sh" << "\n"; 
         c1myfile.close();
         c1myfile.clear();
         c1myfile.flush();
         system("chmod 777 runme.sh");
         cout << "Your script when ran will goto the bin directory. That is where everything is ran from and that is where your computer time travel media files will be. Don't delete the executables." << "\n";  
         cout << "When your ready to run this base conversion time travel project goto the command line and type ./runme.sh" << "\n";
         cout << "Hit any key and enter to continue." << "\n";
         cin >> pause;
         goto atmenu;
     }

     // if choice = 4.
     if (choice == '4')
     {
         cout << "How many time travel media files do you want. WARNING CONSIDER YOUR HARD DRIVE LIMITS!!!" << "\n"; 
         cin >> howmanyfiles;

         cout << "What is the weak check-sum for these time travel media files?" << "\n";
         cin >> weakchecksum;

         cout << "How many bytes per second do you want to run this time travel project" << "\n";
         cin >> bs;

         cout << "What is the prefix or extension of the target files?" << "\n";
         cin >> prefix;

         cout << "Do you have your own destination file or do I need to build that for you? Answer yes for have your own or no I need to build it for you in lower case letters." << "\n";
         cin >> build;

         cout << "What is the counter speed we are using for this counter today." << "\n";
         cin >> counterspeed;

   
         cout << "Creating Bash scripts for the user to run." << "\n";

         // Open bash script.
         fstream c1myfile(file1.c_str(), ios::out);
         if (!c1myfile)
         {
              cout << "Unable to open file line 74 \n";
              cin >> pause;
              exit(1); // terminate with error
         }

    // get command line arguments
//    extension = argv[1];
//    buffersize = atoi( argv[2]); // How many bytes we are reading at a time. 
//    weakchecksum = strtoull(argv[3],NULL,10); // This is how many files we are building to day.
//    counterspeed = strtoull(argv[4],NULL,10); // How many weak check-sums to skip at a time. This is the counter speed
//    howmanyfiles = strtoull(argv[5],NULL,10); // How many target files to generate
//    test1 = atoi(argv[6]); // if 0 user supplies destination file. If 1 program creates destination file.
//    test2 = atoi(argv[7]); // if 0 user supplies check-sum file. If 1 program creates check-sum file.

         c1myfile << "#!/bin/bash" << "\n";
         c1myfile << "cd bin" << "\n";
         if (build == "yes")
         {
              c1myfile << "./weakcheck-sumcounter " << prefix << " " <<  bs << " " << weakchecksum << " " << counterspeed << " " << howmanyfiles << " 0 0" << "\n"; // 
         }              

         if (build == "no")
         {
              c1myfile << "./weakcheck-sumcounter " << prefix << " " <<  bs << " " << weakchecksum << " " << counterspeed << " " << howmanyfiles << " 1 1" << "\n"; // 

         }              

         c1myfile << "echo Run a robot" << "\n";
         c1myfile << "cd .." << "\n";
         c1myfile << "rm runme.sh" << "\n";
         c1myfile << "rm checksum.bin" << "\n"; 
         c1myfile << "rm speed.bin" << "\n"; 
         c1myfile.close();
         c1myfile.clear();
         c1myfile.flush();
         system("chmod 777 runme.sh");
         cout << "When your ready to run this binary time travel project goto the command line and type ./runme.sh" << "\n";
         cout << "Hit any key and enter to continue." << "\n";
         cin >> pause;
         goto atmenu;
     }

     // if choice = 5.
     if (choice == '5')
     {
         cout << "Move your time travel media files to robot checking folder as robots can delete your executables." << "\n";          

         cout << "What is the prefix or extension of the target files?" << "\n";
         cout << "Enter this correctly or this will not delete the bad files" << "\n";
         cin >> prefix;


         // Open bash script.
         fstream c1myfile(file1.c_str(), ios::out);
         if (!c1myfile)
         {
              cout << "Unable to open file line 74 \n";
              cin >> pause;
              exit(1); // terminate with error
         }


         c1myfile << "#!/bin/bash" << "\n";
         c1myfile << "cd robotchecking" << "\n";
         c1myfile << "echo running robot" << "\n";
// system("ls *targets* > list.txt");
         c1myfile << "ls *"<< prefix << "* > list.txt" << "\n";
// system("file *targets* -b > formats.txt");
         c1myfile << "file *"<< prefix << "* -b > formats.txt" << "\n";
         c1myfile << "./fileformatrobot3" << "\n";
         c1myfile << "echo scan your files with a virus scanner before opening. Your time travel media files are ready." << "\n";
         c1myfile << "cd .." << "\n";
         c1myfile << "rm runme.sh" << "\n"; 
         c1myfile.close();
         c1myfile.clear();
         c1myfile.flush();
         system("chmod 777 runme.sh");
         cout << "When your ready to run this robot goto the command line and type ./runme.sh" << "\n";
         cout << "Hit any key and enter to continue." << "\n";
         cin >> pause;
         goto atmenu;
     }

     // if choice = 6.
     if (choice == '6')
     {
         cout << "Move your time travel media files to robot checking folder as robots can delete your executables." << "\n";          
         cout << "Hit any key and enter" << "\n";
         cin >> pause;

         // Open bash script.
         fstream c1myfile(file1.c_str(), ios::out);
         if (!c1myfile)
         {
              cout << "Unable to open file line 74 \n";
              cin >> pause;
              exit(1); // terminate with error
         }


         c1myfile << "#!/bin/bash" << "\n";
         c1myfile << "cd robotchecking" << "\n";
         c1myfile << "echo running robot" << "\n";
         c1myfile << "./airobot" << "\n";
         c1myfile << "echo scan your travel travel computer media files with a virus scanner before opening. Your time travel media files are ready." << "\n";
         c1myfile << "cd .." << "\n";
         c1myfile << "rm runme.sh" << "\n"; 
         c1myfile.close();
         c1myfile.clear();
         c1myfile.flush();
         system("chmod 777 runme.sh");
         cout << "Your script when ran will goto the bin directory. That is where everything is ran from and that is where your computer time travel media files will be. Don't delete the executables." << "\n";  
         cout << "When your ready to run this robot goto the command line and type ./runme.sh" << "\n";
         cout << "Hit any key and enter to continue." << "\n";
         cin >> pause;
         goto atmenu;
     }

     // if choice = 7.
     if (choice == '7')
     {

         cout << "MAKE SURE YOU HAVE destination.bin IN THE BIN DIRECTORY!!!!" << "\n";
         cout << "RENAME newdestination.bin TO destination.bin." << "\n";

         howmanyfiles = 1;

         cout << "How many bytes are we adding or subtracting from the destination file." << "\n";
         cin >> filesize1;

         cout << "How many bytes per second do you want to run this" << "\n";
         cin >> bs;

         prefix = "newdestination.bin";

         cout << "Are we adding or subtracting from the destination file?" << "\n";
         cout << "Type add or type subtract anything else won't create targets" << "\n";
         cin >> addorsubtract;

         cout << "WARNING MAKE SURE /DEV/RANDOM HAS PLENTY OF ENTROPY!!!!!!!!!!!" << "\n";
         cout << "Hit any key and enter to start." << "\n";
         cin >> pause;

         cout << "Creating Bash scripts for the user to run." << "\n";

         // Open bash script.
         fstream c1myfile(file1.c_str(), ios::out);
         if (!c1myfile)
         {
              cout << "Unable to open file line 74 \n";
              cin >> pause;
              exit(1); // terminate with error
         }

//       buffersize = atoi( argv[1]); // How many bytes we are reading at a time.
//       highfile = argv[2]; // High file as a number in a numerical base.
//       lowfile = argv[3]; // Low file as a number in a numerical base.
//       filelist = argv[4]; // filelist containing the names of the difference files.
//       addsubtract = argv[5]; // Are we adding the differences or subtracting them.
//       extension = argv[6]; // file extension to give to targets.

         c1myfile << "#!/bin/bash" << "\n";
         c1myfile << "cd bin" << "\n";
         // dd if=/dev/urandom of=~/urandom_test count=4 bs=1024
         c1myfile << "echo Creating diff.bin for difference file" << "\n";
         c1myfile << "dd if=/dev/random of=diff.bin count=" << filesize1 << " bs=" << bs << "\n";
         // split -b sizeoffiles random.bin prefixoftargets
         c1myfile << "ls *"<< "diff" << "* > list.txt" << "\n";
         c1myfile << "./timescanner " << bs << " destination.bin " << " destination.bin " << " list.txt " << addorsubtract << " " << prefix << "\n"; // <<<<<<<<<<<<< run binary time scanner
         c1myfile << "rm *diff*" << "\n"; 
         c1myfile << "rm list.txt" << "\n"; 
         c1myfile << "cd .." << "\n";
         c1myfile << "rm runme.sh" << "\n"; 
         c1myfile.close();
         c1myfile.clear();
         c1myfile.flush();
         system("chmod 777 runme.sh");
         cout << "Your script when ran will goto the bin directory. That is where everything is ran from and that is where your computer time travel media files will be. Don't delete the executables." << "\n";  
         cout << "When your ready to run this binary time travel project goto the command line and type ./runme.sh" << "\n";
         cout << "Hit any key and enter to continue." << "\n";
         cin >> pause;
         goto atmenu;
     }

     // if choice = 8.
     if (choice == '8')
     {

         cout << "MAKE SURE YOU HAVE destination.txt IN THE BIN DIRECTORY!!!!" << "\n";
         cout << "RENAME newdestination.txt TO destination.txt." << "\n";

         howmanyfiles = 1;


         cout << "How many bytes are we adding or subtracting from the destination file." << "\n";
         cin >> filesize1;

         cout << "How many bytes per second do you want to run this time travel project" << "\n";
         cin >> bs;

         prefix = "newdestination.txt";

         cout << "Are we adding or subtracting from the destination file?" << "\n";
         cout << "Type add or type subtract anything else won't create targets" << "\n";
         cin >> addorsubtract;

         cout << "If you have a specific number at the end of your destination text file to exit on enter it here else enter -999" << "\n";
         cout << "If you do not know what this is just type -999 and hit enter and don't worry about it." << "\n";
         cin >> endoffile;

         cout << "WARNING MAKE SURE /DEV/RANDOM HAS PLENTY OF ENTROPY!!!!!!!!!!!" << "\n";
         cout << "Hit any key and enter to start." << "\n";
         cin >> pause;

         cout << "Creating Bash scripts for the user to run." << "\n";

         // Open bash script.
         fstream c1myfile(file1.c_str(), ios::out);
         if (!c1myfile)
         {
              cout << "Unable to open file line 74 \n";
              cin >> pause;
              exit(1); // terminate with error
         }

//    buffersize = strtoull(argv[1],NULL,10);
//    highfile = argv[2]; // High file as a number in a numerical base.
//    lowfile = argv[3]; // Low file as a number in a numerical base.
//    filelist = argv[4]; // filelist containing the names of the difference files. Use ls > list.txt then edit the list
//    addsubtract = argv[5]; // Are we adding the differences or subtracting them.
//    extension = argv[6]; // file extension to give to targets.
//    endoffile = strtoull(argv[7],NULL,10); // Set this to a negative number if not using. Used to stop at end of files.

         c1myfile << "#!/bin/bash" << "\n";
         c1myfile << "cd bin" << "\n";
         // dd if=/dev/urandom of=~/urandom_test count=4 bs=1024
         c1myfile << "echo Creating diff.bin for difference files" << "\n";
         c1myfile << "dd if=/dev/random of=diff.bin count=" << filesize1 << " bs=" << bs << "\n";
         // CODE RANDOM.BIN TO A TEXT FILE BEFORE SPLITTING <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
// ./program name // name of file to create // buffersize // get name of binary file
// file2 = argv[1];
// buffersize = atoi( argv[2]); // How many bytes we are reading at a time.
// file1 = argv[3];
         c1myfile << "echo Coding diff.bin to diff.txt for difference files" << "\n";
         c1myfile << "./CodeBaseBinaryConverter diff.txt "<< bs << " diff.bin " << "\n";              
         c1myfile << "rm diff.bin" << "\n";              
         // split -b sizeoffiles random.bin prefixoftargets
         c1myfile << "ls *" << " diff " << "* > list.txt" << "\n";
// parameters to run BCtimescanner
//    buffersize = strtoull(argv[1],NULL,10);
//    highfile = argv[2]; // High file as a number in a numerical base.
//    lowfile = argv[3]; // Low file as a number in a numerical base.
//    filelist = argv[4]; // filelist containing the names of the difference files. Use ls > list.txt then edit the list
//    addsubtract = argv[5]; // Are we adding the differences or subtracting them.
//    extension = argv[6]; // file extension to give to targets.
//    endoffile = strtoull(argv[7],NULL,10); // Set this to a negative number if not using. Used to stop at end of files.
           
         c1myfile << "./BCtimescanner " << bs << " destination.txt " << " destination.txt " << " list.txt " << addorsubtract << " " << prefix << " " << endoffile << "\n"; // <<<<<<<<<<<<< run bcbinary time scanner
         c1myfile << "echo Run a robot" << "\n";
         c1myfile << "rm list.txt" << "\n"; 
         c1myfile << "rm diff.bin" << "\n";
         c1myfile << "rm *diff*" << "\n";
         c1myfile << "rm diff.txt" << "\n";
         c1myfile << "cd .." << "\n";
         c1myfile << "rm runme.sh" << "\n"; 
         c1myfile.close();
         c1myfile.clear();
         c1myfile.flush();
         system("chmod 777 runme.sh");
         cout << "Your script when ran will goto the bin directory. That is where everything is ran from and that is where your computer time travel media files will be. Don't delete the executables." << "\n";  
         cout << "When your ready to run this base conversion time travel project goto the command line and type ./runme.sh" << "\n";
         cout << "Hit any key and enter to continue." << "\n";
         cin >> pause;
         goto atmenu;

     }

     // if choice = 9.
     if (choice == '9')
     {
         long long count1;

         cout << "Make sure your files to decode are in the bin directory." << "\n";          
         cout << "\n";
         cout << "What is the file size for these time travel media files? WARING CONSIDER YOUR HARD DRIVE LIMITS!!!!" << "\n";
         cin >> filesize1;
         cout << "\n";
         cout << "How many bytes per second do you want to run this time travel project" << "\n";
         cin >> bs;
         cout << "\n";
         cout << "What is the prefix or extension of the target files?" << "\n";
         cin >> prefix;

        // Open bash script.
         fstream c1myfile(file1.c_str(), ios::out);
         if (!c1myfile)
         {
              cout << "Unable to open file line 74 \n";
              cin >> pause;
              exit(1); // terminate with error
         }

         cout << "On the command line goto the bin directy and type ls *prefixofyourfiles* > list.txt" << "\n";
         cout << "After making that list move it to where TimeTravel program is so I can read it." << "\n";
         cout << "When that is done hit any key and enter" << "\n";
         cin >> pause;

         c1myfile << "#!/bin/bash" << "\n";
         c1myfile << "cd bin" << "\n";
//         c1myfile << "ls *"<< prefix << "* > list.txt" << "\n";

         // Open list.
         fstream c1myfile2("list.txt", ios::in);
         if (!c1myfile2)
         {
              cout << "Unable to open file line 655 \n";
              cin >> pause;
              exit(1); // terminate with error
         }
         count1 = 0;
         do
         {
              c1myfile2 >> nameoftextfile; 
    // Get command lid
    // ./program name // name of file to create // filesize creating // buffersize // get name of number file containing base number
//     file1 = argv[1];
//     filesize1 = strtoull(argv[2],NULL,10);
//     buffersize = atoi( argv[3]); // How many bytes we are reading at a time.
//     file2 = argv[4];
// ------------------------------------------------------- Name file 3
              file3 = "";
              count1++;
              std::stringstream ss;
              ss << count1;
              ss >> file3;
              file3 = file3 + ".bcoutbin";
// ------------------------------------------------------- finishing naming file 3
              c1myfile << "./DecodeBaseBinaryConverter " << file3 << " " << filesize1 << " " << bs << " " << nameoftextfile << "\n";
         } while(!c1myfile2.eof());
         c1myfile.close();
         c1myfile.clear();
         c1myfile.flush();
         system("chmod 777 runme.sh");
         cout << "Your script when ran will goto the bin directory. That is where everything is ran from and that is where your computer time travel media files will be. Don't delete the executables." << "\n";  
         cout << "When your ready to run this base conversion time travel project goto the command line and type ./runme.sh" << "\n";
         cout << "After the decode script is ran delete your text files, runme.sh, list.txt and any other unecessary files." << "\n";
         cout << "Don't delete your file format reject list, AI data base, or your executables." << "\n";
         cout << "Hit any key and enter to continue." << "\n";          
         cin >> pause;
         goto atmenu;
     }



     // Exit program
     exit(0);

}

