// COUNTER9.CPP CLIENT PROGRAM
// NOTE - I STILL HAVE A LOT TO DO WITH THIS. THE MAIN CHANGE HERE IS I AM LOSING THE RESTORE COUNTER AND ADDING ONLY.
// I HAVE TO ADD IN ANOTHER ALGORITHM FOR THE SPEED. I AM PLAYING 3 DECRYPT FUNCTIONS
// 1. RANDOM 2. LINEAR MOVING SECTIONS 3. PENDALUM 
// README
// THIS IS A PROGRAM THAT CAN TAKE A COMPUTER FILE AND CREATE A STRONG CHECK SUM FROM A COMPUTER FILE AND LOAD IT TO A CONFIG FILE.
// THIS PROGRAM CAN ALSO LOAD A CONFIG FILE AND RECREATE THAT CHECK SUM. 
// THIS PROGRAM CAN BE USED TO RECONSTRUCT A STRONG CHECK SUM IN LINEAR OR PARALLEL MODE AS PART OF ANOTHER PROGRAM.
// This program will be used by the Armageddon A.I. in the Armageddon project.

// Copyright (C) 2016 http://time-travel.institute
// ============================================================================================
 // declare includes
     #include <cstdlib>
     #include <iostream>
     #include <stdlib.h>
     #include <fstream>
     #include <sstream>
     #include <string> 
     #include <cmath>
     #include <ctime>
     #include <cstdio>
     #include <iostream>
     #include </home/reactor1967/mersennetwister.h> // This is a dependancy. I MIGHT NOT USE THIS IN THE FINAL PROGRAM. ITS OUTDATED
// ============================================================================================
    // Declare namespace
    using namespace std;
// ============================================================================================     
// declare globals
    // declare global array counter to max file size
    int counter[100]; // max file size
    // declare global array speed1 to max file size
    int speed1[100];
    // declare global array speed2 to max file size
    int speed2[100];
    // declare global array backup to max file size
    int backup[100];
    // declare global array weights to max file size
    long double weights[100];
    // declare global file name
    string globalfile = "";
    // declare global file size
    long long globalfilesize = 0;
    // declare global strong check sum;
    long double globalstrongchecksum = 0;
    // declare global how many weighted sums
    long long globalhowmanyweightedsums = 0;
    // declare global password for weights Constant
    long long globalpassword = 0;
    // declare global destination
    long double globaldestination = 0;
    // declare global target
    long double globaltarget = 0;
    // declare global count1
    long long count1 = 0;
    // declare globalcounterspeedmode
    int globalcounterspeedmode;
    // declare config
    int config;

    // Later use entropy here for Armageddon Will start new globals and new subs and new sections of main
// ============================================================================================     
// declare subs
// This is where all the work is done to make the program run.
// ============================================================================================
int tweak()
{
    // declare variables
    long long howmanybytestotweak = 0;
    long long byte1 = 0;
    long long count1;
    long long count2 = 1;
    long long count3 = -1;
    string pause;
// declaring variable to hold time in seconds from timer.
    time_t seconds;
// getting time in seconds from time.
    time(&seconds);
                  
    // converting time in seconds to unsigned interger and seeding the random number generator
    srand((unsigned int) seconds);
//    howmanybytestotweak = rand() % globalfilesize;  
//    count3 = -1;            
//    do
//    {
//         count3++;
         count1 = rand() % globalfilesize;
         if (count1 == globalfilesize)
         {
              cout << "Wrong position tweak" << "\n";
              cin >> pause;
              exit(1);
         } 
         byte1 = rand() % 256; 
         counter[count1] = byte1;
// converting time in seconds to unsigned interger and seeding the random number generator
         srand((unsigned int) seconds);
//    } while(count3 < howmanybytestotweak);
    return(0); 
}
// ============================================================================================
int subtractspeed2()
{

     // declare variables
     int carry = 0;
     int byte1 = 0;
     int byte2 = 0;
     int byte3 = 0;
     string pause;
     long long count1 = -1;

     do
     {

          // increment counter variable
          count1++;

          // read arrays
          byte1 = counter[count1];
          byte2 = speed2[count1];

          byte3 = byte1 - byte2 - carry;
          carry = 0;

          // if file1 + file2 + carry => base subtract the base and set carry to 1 else carry = 0
          if (byte3  < 0)
          {
               byte3 = byte3 + 256;
               carry = 1;
          }

          // write remainder to file 1
          if (byte3 > 255)
          {
               cout << "Houston we have a problem\n";
               cout << "Byte3 greater than the base - 1\n";
               cin >> pause;
               exit(1);
          }

          counter[count1] = byte3;
          
     } while (count1 < globalfilesize - 1) ;
     return(0);

}

// ============================================================================================
int subtractspeed1()
{

     // declare variables
     int carry = 0;
     int byte1 = 0;
     int byte2 = 0;
     int byte3 = 0;
     string pause;
     long long count1 = -1;

     do
     {

          // increment counter variable
          count1++;

          // read arrays
          byte1 = counter[count1];
          byte2 = speed1[count1];

          byte3 = byte1 - byte2 - carry;
          carry = 0;

          // if file1 + file2 + carry => base subtract the base and set carry to 1 else carry = 0
          if (byte3  < 0)
          {
               byte3 = byte3 + 256;
               carry = 1;
          }

          // write remainder to file 1
          if (byte3 > 255)
          {
               cout << "Houston we have a problem\n";
               cout << "Byte3 greater than the base - 1\n";
               cin >> pause;
               exit(1);
          }

          counter[count1] = byte3;
          
     } while (count1 < globalfilesize - 1) ;
     return(0);

}
// ============================================================================================
    // int setspeed2linear(long long globalfilesize) // Linear speed // Sets a linear speed of the counter
long long setspeedlinear2(long long globalfilesize, long long linear2count)
{ 
     int carry = 0;
     if (speed2[linear2count + 1] == 255) //WHAT EVER YOU ADD HERE.
     {
          linear2count++;
          if (linear2count == globalfilesize - 1) // YOU MUST SUBTRACT HERE. SO EXAMPLE PLUS 1 MINUES 1
          {
               linear2count = 0;
          }
 
          count1 = -1;
          do
          {
               count1++;
               speed2[count1] = 0;
          } while(count1 < globalfilesize - 1);
     }


     count1 = linear2count - 1;                       
     do
     {
          count1++;
          if (count1 == linear2count)
          {
               speed2[count1] = speed2[count1] + 1 + carry;
               carry = 0;
          }

          if (count1 > linear2count)
          {
               speed2[count1] = speed2[count1] + carry;
               carry = 0;
          }

          // speed[count1] = speed[count1] + speed[count1] + carry;              
          if (speed2[count1] > 255)
          {
               speed2[count1] = speed2[count1] - 256;
               carry = 1;
          }

    } while(count1 < globalfilesize - 1);
    return(linear2count);
}
// ============================================================================================
    // int initilizearrays(long long maxarraysize) // sets all arrays to zero.
    int initilizearrays(long long maxarraysize)
    {
         // declare variables
         long long count1 = -1; 
         do
         {
              count1++;
              counter[count1] = 0; // max file size
              speed1[count1] = 0; // max file size
              speed2[count1] = 0; // max file size
              backup[count1] = 0; // max file size
              weights[count1] = 0; // max file size
         } while(count1 < maxarraysize - 1);
         return(0);
    }
// ============================================================================================
    int addarraysspeed1(long long globalfilesize)
    {

         // declare variables
         long long count1 = 0;
         int carry = 0;
         char pause;
         
         // add speed array to counter array
         count1 = -1; 
         carry = 0;
         do
         {
              count1++;
              counter[count1] = counter[count1] + speed1[count1] + carry;
              carry = 0;
              if (counter[count1] > 255)
              {
                   counter[count1] = counter[count1] - 256;
                   carry = 1;
              }           
              
         } while(count1 < globalfilesize - 1);
         return(0);      
    }

// ============================================================================================
    // int addarraysspeed2(long long globalfilesize) // Linear speed // Adds counter to linear speed.
    int addarraysspeed2(long long globalfilesize)
    {

         // declare variables
         long long count1 = 0;
         int carry = 0;
         char pause;
         
         // add speed array to counter array
         count1 = -1; 
         carry = 0;
         do
         {
              count1++;
              counter[count1] = counter[count1] + speed2[count1] + carry;
              carry = 0;
              if (counter[count1] > 255)
              {
                   counter[count1] = counter[count1] - 256;
                   carry = 1;
              }           
              
         } while(count1 < globalfilesize - 1);
         return(0);      
    }
// ============================================================================================
    // int setspeed1random(long long globalfilesize) // Random speed1 // Sets a random throttled speed of the counter.
    int setspeed1random(long long globalfilesize) // when running in parallel wait one second before starting another application
    {
         long long a = 3;
         long long c = 2361;
         long long m = 999999;
         long long k = 0;
         long long r = 0;
         char pause;
         long long count2 = 0;
         long long filesize2 = 0;
         int byte1 = 0;
         filesize2 = globalfilesize; 
//    Declare variable to hold seconds on clock.
         time_t seconds;
         count2 = -1;
         do
         {
              count2++;
              speed1[count2] = 0;
         } while(count2 < 100); // set this for max array size!!!!!!!!!!!!!!!!!!!!!!!!!!!!

         count1 = count1 + 1;
         time(&seconds);
         k = count1 + seconds;         
         srand((unsigned int) seconds);
         filesize2 = (rand() % globalfilesize);
         if (filesize2 == globalfilesize)
         {
              cout << "Wrong position setspeed1random" << "\n";
              cin >> pause;
              exit(1);
         } 


//         filesize2 = (a * k + c) % globalfilesize + 1;

// cout << filesize2 << " " << k << "\n";
// cin >> pause;

         count2 = -1;
         do
         {
              count1 = count1 + 1;
              if (count1 == 999999)
              {
                    count1 = 1;
              }  
 //             k = count1;
              time(&seconds);
              k = count1 + seconds; 
              byte1 = (a * k + c) % (int)256;
              count2++;
              speed1[count2] = byte1;
              if (count2 == filesize2)
              {
                   break;
              }
          } while(count2 < filesize2); 
//         } while(count2 < globalfilesize - 1);
         return(0);
    } 
// ============================================================================================
    // int setspeed2linear(long long globalfilesize) // Linear speed // Sets a linear speed of the counter
int setspeedlinear1(long long globalfilesize, long long bytesadded, int linearmode)
{ // Come back and rewrite this Using distance = speed * time
         // declare variables 
         int carry;
         long long count1;
         string pause;
  
         if (linearmode == 1) // speed increases some # of bytes. Variable
         {
        // add speed array to speed array (Put do loop around this to magnify it if needed)
//         counterspeed++;
              carry = 0;
              count1 = -1;                       
              do
              {
                   count1++;
                   if (count1 < bytesadded)
                   {
                        speed2[count1] = speed2[count1] + 1 + carry;
                        carry = 0;
                   }

                   if (count1 >= bytesadded)
                   {
                        speed2[count1] = speed2[count1] + carry;
                        carry = 0;
                   }

              // speed[count1] = speed[count1] + speed[count1] + carry;              
                   if (speed2[count1] > 255)
                   {
                        speed2[count1] = speed2[count1] - 256;
                        carry = 1;
                   }

              } while(count1 < globalfilesize - 1);
         }
         
         if (linearmode == 0) // speed stays at specific number of bytes. Constant
         {

              count1 = -1;
              do
              {
                   count1++;
                   speed2[count1] = 0;

              } while(count1 < globalfilesize - 1);

              count1 = -1;
              do
              {
                   count1++;
                   speed2[count1] = 1;

              } while(count1 < bytesadded - 1);
         }

         return(0);
}
// ============================================================================================
    // Add more decrypt functions here as needed <<<<<<<<<<<<<<<<<<< // Adds more functions to program as needed.
// ============================================================================================
    // long long filesize(string globalfile) // Gets the file size of a computer file.
long long filesize(string globalfile)
{
// declare variables
    long long begin1;
    long long end1;
    long long filesize1;
    string pause;  
    string file1 = globalfile;
      
    // open file1
     fstream myfile1(file1.c_str(), ios::in | ios::binary);
     if (!myfile1)
     {
          myfile1.close();
          cout << "Failed to read file one line 134.\n";
          cin >> pause;
          exit(1);
     }

// get filesize1
     begin1 = myfile1.tellg();
     if (!myfile1)
     {
          myfile1.close();
          cout << "Failed to read file one line 316.\n";
          cin >> pause;
          exit(1);
     }
     myfile1.seekg (0, ios::end);
     end1 = myfile1.tellg();
     filesize1 = (end1-begin1);     

// close file 1
     myfile1.close();
     myfile1.clear();
     myfile1.flush();

// return filesize
     return(filesize1);
// end sub
}
// ============================================================================================
    // long long strongchecksum(string globalfile, globalfilesize) // Gets a strong checksum of a computer file
long double getstrongchecksumfile(string globalfile, long long globalpassword , int globalhowmanyweightedsums)
{
//     cout << "Getting weighted check sum\n";
     long double schecksum;
     int byte1 = 0;
     long long count = -1;
     long long count2 = 0;
     long long filesize1 = 0;
     long long begin1 = 0;
     long long end1 = 0;
     long long seednumber = 0;
     int buffersize = 1;
     unsigned char buffer(buffersize);
     long double x1 = 0;
     long long x2 = 0;
     string pause;
     string file1 = globalfile;
     long long password = globalpassword;
     MTRand mtrand1a( password );
     
     // open file1
     fstream myfile1(file1.c_str(), ios::in | ios::binary);
     if (!myfile1)
     {
          myfile1.close();
          cout << "Failed to read file one.\n";
          cin >> pause;
          exit(1);
     }

// get filesize1
     begin1 = myfile1.tellg();
     if (!myfile1)
     {
          myfile1.close();
          cout << "Failed to read file one.\n";
          cin >> pause;
          exit(1);
     }
     myfile1.seekg (0, ios::end);
     end1 = myfile1.tellg();
     filesize1 = (end1-begin1);

     mtrand1a.seed(password);
     count = 0;
     schecksum = 0;
	 do
     {

          byte1 = 0;
// read file1
          myfile1.seekg(count);
          myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellg();
          byte1 = (int)buffer;
          count2 = 0;
	      do
          {
               count2++;
		       x1 = mtrand1a.randExc(.9999999);
                       // Change the password (It has to be different to get different results)
                       password++;
                       mtrand1a.seed(password);
//               weightedsumarray2[count] = weightedsumarray2[count] + (byte1 * x1);
               schecksum = schecksum + (byte1 * x1);
          } while(count2 < globalhowmanyweightedsums);
//           schecksum = schecksum + weightedsumarray2[count];
	       count = count + buffersize;
     } while (count < globalfilesize - 1);
     myfile1.close();
     myfile1.clear();
     myfile1.flush();
     return(schecksum);

}
// ============================================================================================
    // Used for running the program without user input.
    // int loadconfig file // Will use only 5 variables 1. File name 2. File size 3. Strong checksum 4. How many weights 5. password
    // Load project from config file
// check if test = 1
int loadconfig()
{
//    long long globalfilesize = 0;

//    long double globalstrongchecksum = 0;

//    long long globalweakchecksum = 0;

//    string globalfile = "";
    // declare variables
    string dummy;
    string pause;


// Load configure file
          fstream c1myfile("filechecksumconfig.txt", ios::in);
          // read name of file
          c1myfile >>  dummy >> dummy >> dummy >> globalfile;
          // read weak check sum
//          c1myfile >>  dummy >> dummy >> globalweakchecksum;
          // read strong check sum 
          c1myfile >>  dummy >> dummy >> globalstrongchecksum;
          // read file size
          c1myfile >>  dummy >> dummy >> dummy >> globalfilesize;
          // read how many weights
          c1myfile >>  dummy >> dummy >> dummy>> dummy >> dummy >> globalhowmanyweightedsums;
          // read mode for counter speed for linear or random or none
//          c1myfile >>  dummy >> dummy >> dummy>> dummy >> globalcounterspeedmode;
          // read mode for tweak counter for linear or random or none
//          c1myfile >>  dummy >> dummy >> dummy>> dummy >> globaltweakcountermode;
          // read password for weights
          c1myfile >> dummy >> dummy >> dummy >> globalpassword;

         // close configure file
          c1myfile.close();
          c1myfile.clear();
          c1myfile.flush();

         // Print configure file to confirm loaded correctly
          cout << "File name > " << globalfile << "\n";
//          cout.precision(36);
//          cout << "Weak check-sum > " << globalweakchecksum << "\n";
          cout.precision(36);
          cout << "Strong check-sum > " << globalstrongchecksum << "\n";
          cout.precision(36);
          cout << "File size > " << globalfilesize << "\n";
          cout.precision(36);
          cout << "How many weighted check-sums > " << globalhowmanyweightedsums << "\n";
//          cout << "Global counter mode > " << globalcounterspeedmode << "\n";    
//          cout << "Global tweak counter mode > " << globaltweakcountermode << "\n";
          cout << "Global password for weights > " << globalpassword << "\n";
          cout << "\n"; 
          cout << "Is the configuration file loaded properly?" << "\n";
          cin >> pause;
          return(0);
//        
}
// ============================================================================================
    // int restorecounter(long long globalfilesize) // Restores backed up counter.
int restorecounter(long long globalfilesize)
{
     
     // declare variables
     long long count1;

     // declare variables
     count1 = -1;
     do
     {
          count1++;
          counter[count1] = backup[count1];
     } while(count1 < globalfilesize - 1); 
     return(0);
}
// ============================================================================================
    // int backupcounter(long long globalfilesize) // Backups counter.
int backupcounter(long long globalfilesize)
{
     // declare variables
     long long count1 = -1;
     do
     {
          count1++;
          backup[count1] = counter[count1];
     } while(count1 < globalfilesize - 1);
     return(0);     
}
// ============================================================================================
    // int generateweights(long long globalpassword, long long globalfilesize) // weights for getting weighted sum
// Generate weights
int generateweights(long long globalpassword, long long globalfilesize)
{
// declare variables
    long long password = globalpassword;
    MTRand mtrand1a(password);
    mtrand1a.seed(password);
    long long count2;
    long double x1;
    long double x2;
    int test;
    string pause;

// Generate weights
    count2 = -1;
    do
    {
         count2++;
         x1 = mtrand1a.randExc(.9999999);
         // Change the password (It has to be different to get different results)
         password++;
         mtrand1a.seed(password);
         weights[count2] = x1;
    } while (count2 < (globalhowmanyweightedsums * globalfilesize));
    
    // do bubble sort of weights
    do
    {
         count2 = -1;
         test = 0;
         do
         { 
              count2++;
              if (weights[count2] > weights[count2 + 1])
              {
                   x1 = weights[count2];
                   x2 = weights[count2 + 1];
                   test = 1;
                   weights[count2] = x2;
                   weights[count2 + 1] = x1;
              }
         } while(count2 < (globalhowmanyweightedsums * globalfilesize));         
    } while(test > 0);
    return(0);
}
// ============================================================================================
    // int displayoutput(long double globaldestination, long double globaltarget) // Displays output of program for testing
    int displayoutput(long double diff3, long double globaldestination, long double globalstrongchecksum, long double destinationstrongsum, long long linear2count) // Displays output of program for testing
    {
         // cout << diff3 << " ";
//         long long count1 = -1;
//         string pause;
//         do
//         {
//              count1++;
//              cout.precision(36);
//              cout << speed2[count1] << " ";
//         } while (count1 < globalfilesize);
//         cout << "\n";
//         cin >> pause;
//-----------------------------------------------
//     cout << diff3 << " ";
//     count1 = -1;
//     do
//     {
//          count1++;
//          cout.precision(36);
//          cout << backup[count1] << " ";
//     } while (count1 < globalfilesize - 1);
//     cout << "\n";
//     count1 = -1;
//     do
//     {
//          count1++;
//          cout.precision(36);
//          cout << speed1[count1] << " ";
//     } while (count1 < globalfilesize - 1);  
// -------------------------------------------------  
//     cout.precision(36);
//      cout << "Diff3 " << diff3 << " Destination sum " << destinationstrongsum << " Target sum "<< globalstrongchecksum << " linear2count " << linear2count << "\n";
// -----------------------------------------------------------------------------
      cout << "Diff3 " << diff3 << " Destination sum " << destinationstrongsum << " Target sum "<< globalstrongchecksum << "\n";
//      count1 = -1;
//     do
//     {
//          count1++;
//          cout.precision(36);
//          cout << speed2[count1] << " ";
//     } while (count1 < globalfilesize - 1);
//     cout << "\n";  
     return(0);
    }
// ============================================================================================
    // int writecountertofile(long long globalfilesize, string globalfile) // writes counter in memory to file.
// Write counter to file.
int writecountertofile(long long globalfilesize, string globalfile)
{
     long long count1 = -1;
     string file1 = globalfile;
     unsigned char buffer;
     int buffersize = 1;
     long long begin1;
     char pause;
     int byte1;

    // open counter file
     fstream myfile1(file1.c_str(), ios:: out | ios:: binary);
     if (!myfile1)
     {
          cout << "Error in line 841.\n";
          cin >> pause;
          myfile1.close();
          myfile1.clear();
          myfile1.flush();
          exit(1); // terminate with error
     }
     
     do
     {

         count1++;
         byte1 = counter[count1];
         buffer = (unsigned char)byte1;
         myfile1.seekp(count1);
         myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
         begin1 = myfile1.tellp();

     } while(count1 < globalfilesize-1);
     return(0);         

 
}
// ============================================================================================
long double getstrongchecksumarray(long long globalpassword, int globalhowmanyweightedsums, long long globalfilesize)
{
     long double schecksum;
     int byte1 = 0;
     long long count = -1;
     long long count2 = 0;
     long double x1 = 0;
     long long x2 = 0;      
     long long password = globalpassword;
     MTRand mtrand1a(password);
     string pause;
     mtrand1a.seed(password);
     count = 0;
     schecksum = 0;
	 do
     {

          byte1 = 0;
// read array
          byte1 = counter[count];
          count2 = 0;
	      do
          {
               count2++;
		       x1 = mtrand1a.randExc(.9999999);
                       // Change the password (It has to be different to get different results)
                       password++;
                       mtrand1a.seed(password);
               schecksum = schecksum + (byte1 * x1);
          } while(count2 < globalhowmanyweightedsums);
          count = count + 1;
     } while (count < globalfilesize - 1);
     return(schecksum);

}
// ============================================================================================
// declare main
    int main (int argc, char *argv[])
    { 
         // declare variables
         int dummyfile = 0;
         int count1 = 0;
         string pause;
         long double diff3 = 0;
         long long bytesadded = 0;
         int linearmode = 0;
         stringstream ss;
         long long maxarraysize = 0;
         long double destinationstrongsum = 0;
         long long linear2count = 0;
// ============================================================================================         
         // pass arguments to program. If no arguments run menu. If Arguments run program
         if (argc == 1) 
         {
              goto jump1;
         }
// passing command line arguments to program
//    test = strtoull(argv[11],NULL,10);
 


     // WE GET SEGMENTATION FAULT WHEN NO VALUES PASSED
    // passing command line arguments to program
    globalfile = argv[1];


    if (globalfile == "help")
    {
         cout << "Order of command line arguments." << "\n";
         cout << "1 file" << "\n";
//         cout << "2 weak check sum" << "\n";
         cout << "2 strong check sum" << "\n";
         cout << "3 file size" << "\n";
         cout << "4 How many weighted sums" << "\n";
//         cout << "6 speed mode - 2=Random 1=linear 0=none" << "\n";
//         cout << "7 tweak mode - 2=Random 1=linear 0=none" << "\n";
         cout << "5 menu choice 1 only right now. So use 1" << "\n";
         cout << "6 config file - 1 = yes 0 = no" << "\n";
         cout << "7 password" << "\n";
//         cout << "11 test 1 = yes 0 = no" << "\n";
         cin >> pause;
         exit(0);
    }    

    // passing command line arguments to program
//    globalweakchecksum = strtoull(argv[2],NULL,10);

    // passing command line arguments to program
    ss << argv[2];
    ss >> globalstrongchecksum;


    // passing command line arguments to program 
    globalfilesize = strtoull(argv[3],NULL,10); // NEVER MORE THAN 4 BYTES. I USE THIS FOR COUNTERS LESS THAN 2 BYTES


   // passing command line arguments to program
   globalhowmanyweightedsums = strtoull(argv[4],NULL,10);


    // passing command line arguments to program
    globalcounterspeedmode = strtoull(argv[5],NULL,10);


// passing command line arguments to program
//    globaltweakcountermode = strtoull(argv[7],NULL,10);
 


// passing command line arguments to program
    config = strtoull(argv[6],NULL,10);
 

// passing command line arguments to program
    globalpassword = strtoull(argv[7],NULL,10); // constant

// getting globalpassword2 non-constant
//    globalpassword2 = globalpassword;
 

   // passing command line arguments to program 
//   choice2 = argv[8];

    
//    if (choice2 == "1")
//    {
//         choice = '1';
//         goto jump2;
//    }    
 // ============================================================================================         
         // if arguments load config file
         if (config == 1)
         {
              dummyfile = loadconfig();
              goto jump3;

         }
// ============================================================================================
         // if no arguments go here
jump1:
         // Menu
         // if no arguments get user input (Later this will create config file for backup) This will be used to run in parallel. 
    // ask user if this is a config file yes or no
    cout << "If you have a config file type 1 and enter. Else type 0 and enter." << "\n";
    cin >> config;

// if config file goto jump
         if (config == 1)
         {
              dummyfile = loadconfig();
              goto jump3;
         }

    // ask user file name
         cout << "Please enter the name of your target file." << "\n";
         cin >> globalfile;


         cout << "What is your max array size?" << "\n";
         cin >> maxarraysize;


// ask how many weights to use for strong check sum
         cout << "How many weighted sums are we using?" << "\n";
         cin >> globalhowmanyweightedsums;


    // ask seed number for random number generator
         cout << "What is the seed number for your weights?" << "\n";
         cin >> globalpassword;


         // setting non-constant password for seeding random number generator.
//         globalpassword2 = globalpassword;

// ============================================================================================
jump3:
    // initiliaze all arrays   
         dummyfile = initilizearrays(maxarraysize);

cout << " Initilize arrays " << "\n";   

     // get file size of file (do from sub)
         globalfilesize =  filesize(globalfile); 

//globalfilesize = 3;

cout << " Get file size " << "\n"; 

    // Generate weights in array // Bubble sort weights
         dummyfile = generateweights(globalpassword, globalfilesize);

cout << " Generate weights " << "\n";
        
    
    // get strong check sum of file (do from sub)
         globalstrongchecksum = getstrongchecksumfile(globalfile, globalpassword , globalhowmanyweightedsums);

cout << " Get strong check sum " << "\n";         

    // get strong checksum of array (do from sub)
//    strongchecksumarray1 = getstrongchecksumarray(globalpassword, globalhowmanyweightedsums, globalfilesize);

    if (config == 0)
    {
         cout << "Please move or delete your file. It may get over written." << "\n";
         cin >> pause;
    }

    destinationstrongsum = getstrongchecksumarray(globalpassword, globalhowmanyweightedsums, globalfilesize);
    
   // diff3 = 9999999999999999999999999999999999
   diff3 = abs(globalstrongchecksum - destinationstrongsum);


// ============================================================================================         
         // run main loop for file construction
         do
         {
// ============================================================================================
// Test subs here
         // Test subs
//         count1 = 0;
//         do
//         {
//              dummyfile = setspeed1random(globalfilesize);
//                bytesadded = 2;
//                linearmode = 0;
//                dummyfile = setspeedlinear(globalfilesize, bytesadded, linearmode);


//              dummyfile = displayoutput(diff3, globaldestination, globaltarget); // Displays output of program for testing

//         } while(count1 != -1);
 
// ============================================================================================
// Decrypt
// Function1  // Running in Random
              // set speed
              dummyfile = setspeed1random(globalfilesize);

              // add arrays
              dummyfile = addarraysspeed1(globalfilesize);

              // get destination strong check sum of counter array 
              destinationstrongsum = getstrongchecksumarray(globalpassword, globalhowmanyweightedsums, globalfilesize);

              // break loop if destination strong sum = target strong check sum
              if (abs(globalstrongchecksum - destinationstrongsum) == 0)
              {
                   if (globalstrongchecksum == destinationstrongsum)
                   {
                        break;
                   }
              }

              // if abs(destination - target) < diff3 then backup counter 
              if (abs(globalstrongchecksum - destinationstrongsum) < diff3)
              {
                   dummyfile = backupcounter(globalfilesize);
              // if abs(destination - target) < diff3 then diff3 = abs(destination - target)
                   diff3 = abs(globalstrongchecksum - destinationstrongsum); 
              }

              // IF abs(destination - target) < diff3 then pass counter to server program
              
              // if abs(diff2 - diff1) > diff3 restore backup
              if (abs(globalstrongchecksum - destinationstrongsum) > diff3)
              {
//                   dummyfile = restorecounter(globalfilesize);
              }

              // Display output (FOR TESTING ONLY)
//              dummyfile = displayoutput(diff3, globaldestination, globalstrongchecksum, destinationstrongsum, linear2count);
// ============================================================================================
// Decrypt
// Function2  // Running in Linear mode
              // set speed
//                linear2count = setspeedlinear2(globalfilesize, linear2count);

              // add arrays
//              dummyfile = addarraysspeed2(globalfilesize);

              // get destination strong check sum of counter array 
              destinationstrongsum = getstrongchecksumarray(globalpassword, globalhowmanyweightedsums, globalfilesize);

              // break loop if destination strong sum = target strong check sum
              if (abs(globalstrongchecksum - destinationstrongsum) == 0)
              {
                   if (globalstrongchecksum == destinationstrongsum)
                   {
                        break;
                   }
              }

              // if abs(destination - target) < diff3 then backup counter 
              if (abs(globalstrongchecksum - destinationstrongsum) < diff3)
              {
                   dummyfile = backupcounter(globalfilesize);
              // if abs(destination - target) < diff3 then diff3 = abs(destination - target)
                   diff3 = abs(globalstrongchecksum - destinationstrongsum); 
              }

              // IF abs(destination - target) < diff3 then pass counter to server program
              
              // if abs(diff2 - diff1) > diff3 restore backup
              if (abs(globalstrongchecksum - destinationstrongsum) > diff3)
              {
//                   dummyfile = restorecounter(globalfilesize);
              }

              // Display output (FOR TESTING ONLY)
//              dummyfile = displayoutput(diff3, globaldestination, globalstrongchecksum, destinationstrongsum, linear2count);
// ============================================================================================
// Decrypt
// Function 5 tweak()

//               dummyfile = tweak(); // This needs looked at for errors!!!!!!!!!!!!!!!!!!!!

              // get destination strong check sum of counter array 
              destinationstrongsum = getstrongchecksumarray(globalpassword, globalhowmanyweightedsums, globalfilesize);

              // break loop if destination strong sum = target strong check sum
              if (abs(globalstrongchecksum - destinationstrongsum) == 0)
              {
                   if (globalstrongchecksum == destinationstrongsum)
                   {
                        break;
                   }
              }

              // if abs(destination - target) < diff3 then backup counter 
              if (abs(globalstrongchecksum - destinationstrongsum) < diff3)
              {
                   dummyfile = backupcounter(globalfilesize);
              // if abs(destination - target) < diff3 then diff3 = abs(destination - target)
                   diff3 = abs(globalstrongchecksum - destinationstrongsum); 
              }

              // IF abs(destination - target) < diff3 then pass counter to server program
              
              // if abs(diff2 - diff1) > diff3 restore backup
              if (abs(globalstrongchecksum - destinationstrongsum) > diff3)
              {
//                   dummyfile = restorecounter(globalfilesize);
              }

              // Display output (FOR TESTING ONLY)
//              dummyfile = displayoutput(diff3, globaldestination, globalstrongchecksum, destinationstrongsum, linear2count);
// ============================================================================================
// Decrypt
// Function# // Put more decrypt functions in program as needed.
// ============================================================================================
// Display output
              // Display output (FOR TESTING ONLY)
              dummyfile = displayoutput(diff3, globaldestination, globalstrongchecksum, destinationstrongsum, linear2count);
// ============================================================================================
         // end main loop for file construction
         } while(globalstrongchecksum != destinationstrongsum);
// ============================================================================================
         // write counter to file
         dummyfile = writecountertofile(globalfilesize, globalfile);
// ============================================================================================
         if (argc == 1) 
         {
 // Display output 
              dummyfile = displayoutput(diff3, globaldestination, globalstrongchecksum, destinationstrongsum, linear2count);

              cout << "FILE RECONSTRUCTED!!!" << "\n";
              cin >> pause;
         }
         // end program
         exit(0);
    }
// BYE ========================================================================================
