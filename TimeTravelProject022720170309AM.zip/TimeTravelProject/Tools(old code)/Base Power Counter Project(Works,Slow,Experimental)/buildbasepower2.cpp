// COPYRIGHT(C) 2017 http://time-travel.institute
// THIS BUILD A BASE POWER FILE FOR DECODING BASE POWER CHECK-SUMS
// YOU CAN GET A SEED FILE FROM RANDOM.ORG
// ============================================================================================
 // declare includes
     #include <cstdlib>
     #include <iostream>
     #include <stdlib.h>
     #include <fstream>
     #include <sstream>
     #include <string> 
     #include <cmath>
     #include <ctime>
     #include <cstdio>
     #include <iostream>
// ============================================================================================
    // Declare namespace
    using namespace std;
// ============================================================================================     
// declare main
int main (int argc, char *argv[])
{ // Begin main
    long long filesize1;
    long long pbnum3;
    string pause;
    long long numberbase = 99999999;
    long long pbnum2;
    long long pbnum1;
    long long carry;
    fstream c1myfile4;
    fstream c1myfile2;
    long long count1;
    long long numberbase2;
    int buffersize;
 
    cout << "Enter the file size to decode" << "\n";
    cin >> filesize1;

    cout << "Enter the buffersize" << "\n";
    cin >> buffersize;

    numberbase2 = (buffersize * 255) + 1;


// open power.txt for output
    c1myfile2.open("power.txt", ios::out);
    if (!c1myfile2)
    {
         cout << "The output file is not opened." << "\n";
         c1myfile2.close();
         c1myfile2.clear();
         c1myfile2.flush();
         exit(1);           
    }

// create power file
    fstream c1myfile1("power.txt", ios::out);
    c1myfile1 << 1 << "\n";
    c1myfile1.close();
    c1myfile1.clear();
    c1myfile1.flush();

    count1 = -1;

    do
    {
         count1++; 
    

        // multiply power file by (buffersize * 255) + 1 <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< 
        if (count1 == filesize1 - 1) // Getting out if done because won't need the power file again.
        {
             break;
        }
 
        // open power file
        fstream c1myfile1("power.txt", ios::in);

        // create temp file to hold result
        // open temp file for multiplication (This file will be renamed).
        c1myfile4.open("temp.txt", ios::out); 

        // set carry to 0
        carry = 0;

        // multiple power file by (buffersize * 255) + 1
        do
        {    
             pbnum1 = 0;
             // Read power file
             if (!c1myfile1.eof( ))
             {
                  c1myfile1 >> pbnum1;
             }

             pbnum2 = 0;
             // multiply number * byte
             pbnum2 = (pbnum1 * numberbase2) + carry;

             if (!c1myfile1.eof( ))
             {
                  carry = 0;
             }

             // convert to base and set carry
             if (pbnum2 >= numberbase)
             {
                   pbnum3 = 0;

                // convert to numberbase
//                carry = int(pbnum2 / numberbase);
//                pbnum3 = pbnum2 - (int(pbnum2/numberbase) * numberbase);
                  carry = pbnum2 / numberbase;
                  pbnum3 = pbnum2 - (carry * numberbase);
             }

             if (pbnum2 < numberbase)
             {
                  pbnum3 = 0;
                  pbnum3 = pbnum2;
             }            
              
             // Error out if carry greater
             if (carry >= numberbase)
             {
                  cout << "Carry greater than number base." << "\n";
                  cin >> pause;
                  exit(0);
             }

              if (pbnum3 >= numberbase)
              {
                   cout << "Carry greater than number base. line 413" << "\n";
                   cin >> pause;
                   exit(0);
              }


             // write to temp file              
//             c1myfile4 << pbnum3 << "\n";
             if (!c1myfile1.eof( ))
             {
                   if (pbnum3 > 0)
                   {
                        c1myfile4 << pbnum3 << "\n";
                   }
             }

             if (c1myfile1.eof( ))
             {
                  if (carry > 0)
                  {
                       c1myfile4 << carry << "\n";
                       carry = 0;
                  }
             }


        } while(!c1myfile1.eof( )); 

        // close temp file
       c1myfile4.close();
       c1myfile4.clear();
       c1myfile4.flush();

        // close power file
       c1myfile1.close();
       c1myfile1.clear();
       c1myfile1.flush();

        // delete power.txt
        system("rm power.txt");

        // rename temp.txt power.txt
        system("mv temp.txt power.txt");

    } while(count1 < filesize1 -1);

} 

