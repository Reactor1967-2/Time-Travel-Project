#include <cstdlib>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <string>
#include <cmath>
#include <d:\Projects\AI project\aiproject\mersenne\mersennetwister.h> 
#include <stdio.h>


using namespace std;

int main (int argc, char *argv[])

{
     int x;
     long double a = 2.49839274973883838;
     cout << "Before " << a << "\n";
     if (a - int(a) >= .5)
     {
           a++;
     }
     a = int(a);
     cout << "After " << a << "\n";
     cin >> x;
     exit(0);
    
    
}    
