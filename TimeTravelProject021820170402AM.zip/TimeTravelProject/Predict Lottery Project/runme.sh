#!/bin/bash

g++ lotteryAI.cpp -o lotteryAI
