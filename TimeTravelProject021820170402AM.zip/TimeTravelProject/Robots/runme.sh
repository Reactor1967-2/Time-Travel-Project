#!/bin/bash

g++ airobot.cpp -o airobot
g++ fileformatrobot.cpp -o fileformatrobot
