// COPYRIGHT(C) 2017 http://time-travel.institute (THIS IS OPEN SOURCE)
// WARNING YOU NEED A random.txt number file to use this program.
// This runs an experimental counter and a control counter to hack a weighted strong check-sum to a computer file.
// Delete the lock.txt file to end the program.
 // declare includes
    #include <cstdlib>
    #include <iostream>
    #include <stdlib.h>
    #include <fstream>
    #include <sstream>
    #include <string> 
    #include <cmath>
    #include <ctime>
    #include <cstdio>
    #include <iostream>
    #include "timecheckhacking.h"
// ============================================================================================
    // Declare namespace
    using namespace std;
// ============================================================================================     
// declare globals 
    long double targetstrongchecksum;
    long double destinationstrongchecksum;
    string file3; // destination file
    long long filesize1;
    long long howmanyweightedsums;

// ============================================================================================     
// declare subs
// ======================================================================================================================
int binaryreadwrite(string whatdo, string file1, long long byteposition, int byte, int buffersize)
{

    unsigned char buffer(buffersize);
    char pause;
    int byte1 = byte;
    long long count1 = byteposition;
    long long begin1;
//     int buffersize = 1;
       
    // open file
    fstream myfile1(file1.c_str(), ios::out  | ios::in | ios::binary);
    if (!myfile1)
    {
         myfile1.close();
         cout << "error in line 79" << " " << file1 << "\n";
         cin >> pause;
         exit(1);
    }
    if (whatdo == "read")
    {
// cout << byte1 << " We are reading bytes " << "\n"; // debug code
         myfile1.seekg(count1);
         myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
         begin1 = myfile1.tellg();
         byte1 = (int)buffer;
         myfile1.close();
         myfile1.clear();
         myfile1.flush();
         return(byte1);
    }
    if (whatdo == "write")
    {
// cout << byte1 << " We are writing bytes " << "\n"; // debug code
         buffer = (unsigned char)byte1;
         myfile1.seekp(count1);
         myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
         begin1 = myfile1.tellp();
         myfile1.close();
         myfile1.clear();
         myfile1.flush();
         return(0);
    } 
     

    cout << "Error in binary read and write" << "\n";
    cin >> pause;
    exit(1);
}
// =============================================================================================
// loadconfig Note give name of config file
int loadconfig() 
{// Can't put this in a header and use globals
    // Declare these variables as global in your main file
    // declare variables
    string dummy;
    string pause;
    int buffersize;

// Load configure file
    fstream c1myfile("config.txt", ios::in);
    // read name of file destination file
    c1myfile >>  dummy >> dummy >> dummy >> file3;
    // strong check sum
    c1myfile >>  dummy >> dummy >> dummy >> targetstrongchecksum;
    // read file size
    c1myfile >>  dummy >> dummy >> dummy >> filesize1;
    // read how many weights
    c1myfile >>  dummy >> dummy >> dummy>> dummy >> howmanyweightedsums;
    // read buffersize
    c1myfile >>  dummy >> dummy >> buffersize;

    // close configure file
    c1myfile.close();
    c1myfile.clear();
    c1myfile.flush();

    // Print configure file to confirm loaded correctly
    cout << "File name > " << file3 << "\n";
    cout.precision(36);
    cout << "Strong check-sum > " << targetstrongchecksum << "\n";
    cout.precision(36);
    cout << "File size > " << filesize1 << "\n";
    cout.precision(36);
    cout << "How many weighted check-sums > " << howmanyweightedsums<< "\n";
    cout << "Buffer size " << buffersize << "\n";
    cout << "\n"; 
    cout << "Is the configuration file loaded properly?" << "\n";
    cout << "Hit any key and enter." << "\n";
    cin >> pause;
    return(0);
//       
}
// ============================================================================================
// declare main
int main (int argc, char *argv[])
{
// ============================================================================================
    // declare variables
    int result = -999;
    string pause;
    int byte;
    int byte1;
    int byte2;
    int byte3;
    int carry;
    string whatdo;
    int seed;
    long double diff3 = 999999999;
    long long numberbase;
    string file1;
    string file2;
    int buffersize;
    long long count2;
    fstream myfile1;
    long long filesize2;
    string seedfile = "random.txt";
    fstream c1myfile1;
    int dummyfile;
    string lockfile = "lock.txt";
    string destinationfile;
    string configfile;

// ============================================================================================
// Test subs and functions here
// ============================================================================================  

    // pass arguments to program. If no arguments run menu. If Arguments run program
    if (argc == 1) 
    {
         cout << "No command line arguments. I can't run. Type nameofprogram help" << "\n";
         cin >> pause;
         exit(1);   
    }

    // passing command line arguments to program
    configfile = argv[1]; // name of config file only // contains lockfile, strong checksum, howmany weighted sums, and file size.

    destinationfile = argv[2]; // This needs to be the same size as the file it is trying to recreate

    if (configfile == "help")
    {
         cout << "This is help here." << "\n";
         cout << "NAMEOFPROGRAM CONFIGFILE DESTINATIONFILE" << "\n";
         exit(0); 
    }

// ============================================================================================
    // open configure file here and read it.
    dummyfile = loadconfig();
// ============================================================================================
    // create lockfile
    dummyfile = createemptyfile(lockfile);
// ============================================================================================
      // open seed file
    c1myfile1.open(seedfile.c_str(), ios::in);
    if (!c1myfile1)
    {
         cout << "There is no file list." << "\n";
         c1myfile1.close();
         c1myfile1.clear();
         c1myfile1.flush();
         exit(0);           
    }


// ============================================================================================
// start 
Startprogram:
 
    // remove counter.bin
    system("remove counter.bin"); // if it exist
    // remove temp.bin
    system("remove temp.bin"); // if it exist
  
// =======================================================================================================================
    // Generate random file
    if (!c1myfile1.eof())
    {
         c1myfile1 >> seed; 
         srand((unsigned int) seed);
    }
    if (c1myfile1.eof())
    {
         c1myfile1.close();
         c1myfile1.clear();
         c1myfile1.flush();
         cout << "Please load another random seed file" << "\n";
         cin >> pause;
         c1myfile1.open(seedfile.c_str(), ios::in);
         if (!c1myfile1)
         {
              cout << "There is no file list." << "\n";
              c1myfile1.close();
              c1myfile1.clear();
              c1myfile1.flush();
              exit(0);           
         }
         c1myfile1 >> seed; 
         srand((unsigned int) seed);
    }
// =======================================================================================================================
         filesize2 = filesize1;        
         system("rm temp.bin"); // removing the previous file
         file2 = "temp.bin";
         // create temp bin
         myfile1.open(file2.c_str(), ios::out  | ios::binary);
         if (!myfile1)
         {
              myfile1.close();
              cout << "error in line 38" << " " << file2 << "\n";
              cin >> pause;
              exit(1);
         }
         myfile1.close();
         myfile1.clear();
         myfile1.flush();
         // Get random binary          
         count2 = buffersize * -1;
         // start second loop
         do
         {
              count2 = count2 + buffersize;
              byte = (rand() % (255*buffersize));
              whatdo = "write";
              file2 = "temp.bin";
              // write random binary
              dummyfile = binaryreadwrite(whatdo, file2, count2, byte, buffersize);

              // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< NOTE CAN ADD RESEEDED RANDOM NUMBER GENERATOR WHERE WITH SEED FILE
//              c1myfile1 >> seed; 
//              srand((unsigned int) seed);

          // end second loop for random file size
         } while(count2 < filesize2);

// =========================================================================================================================
    // add destination file to random file output counter.bin file
         file1 = "counter.bin";
         myfile1.open(file1.c_str(), ios::out  | ios::binary);
         if (!myfile1)
         {
              myfile1.close();
              cout << "error in line 245" << " " << file1 << "\n";
              cin >> pause;
              exit(1);
         }
         myfile1.close();
         myfile1.clear();
         myfile1.flush();
         numberbase = (buffersize * 255) + 1;
         carry = 0;
         count2 = buffersize * -1;
         // start third loop
         do
         {
              // increment file variable
              count2 = count2 + buffersize;

              // set byte1 to zero
              byte1 = 0;

              // read byte1 if less than filesize
              whatdo = "read";

              if (count2 < filesize1 - 1)
              { 
                   byte1 = binaryreadwrite(whatdo, destinationfile, count2, byte, buffersize);
              }

              // // set byte2 to 0
              byte2 = 0;

              // read byte2 if less than filesize
              if (count2 < filesize1 - 1) // Dont have to use minus one here because it is upto filesize1 - 1 already.
              {
                   byte2 = binaryreadwrite(whatdo, file2, count2, byte, buffersize);
              }

              // byte3 = byte1 - byte2 - carry;
              byte3 = byte1 + byte2 + carry;

              // carry = 0;
              carry = 0;

              // if byte < 0 subtract from the base
              if (byte3  > numberbase - 1)
              {
                   byte3 = byte3 - numberbase;
                   carry = 1;
              }

              // Check for error
              if (byte3 > (numberbase - 1))
              {
                   cout << "Houston we have a problem\n";
                   cout << "byte3 greater than the base - 1\n";
                   cin >> pause;
                   exit(0);
              }

              if (byte3 < 0)
              {
                   cout << "Houston we have a problem\n";
                   cout << "byte3 less than 0\n";
                   cin >> pause;
                   exit(0);
              }



              // write random binary
              whatdo = "write";
              dummyfile = binaryreadwrite(whatdo, file1, count2, byte3, buffersize);


         // end third loop
         } while(count2 < filesize1 -1); // We can use filesize2 or filesize3 here as our stop. I chose filesize2 so it would not copy into output file.
                                      // from the destination file.
         // if carry has value write it
//         if (carry > 0)
//         {
//              // write random binary
//              whatdo = "write";
//              dummyfile = binaryreadwrite(whatdo, file1, count2, carry, buffersize);
//              // write to addition file              
//              carry = 0;
//         }
// =========================================================================================================================

    // get destination
    destinationstrongchecksum = getstrongchecksum(file1, howmanyweightedsums, buffersize);

    // break loop if diff3 == 0
    if (abs(targetstrongchecksum - destinationstrongchecksum) == 0)
    {
         if (targetstrongchecksum == destinationstrongchecksum)
         {
              // copy new counter.bin to counterbak.tin
              dummyfile= rename( "counter.bin" , file3.c_str() );
              cout << "File Reconstructed" << "\n";
              cout << "PROGRAM ENDED!!!!!!" << "\n";
              // close seed file
              c1myfile1.close();
              c1myfile1.clear();
              c1myfile1.flush();
              // remove temp.bin
              system("rm temp.bin"); // if it exist
              // remove counterbak.bin
              system("rm counterbak.bin");
              exit(0);
         }
    }

    // Run the pendulum algorithm  
    // if abs(destination - target) < diff3 then backup counter 
    if (abs(targetstrongchecksum - destinationstrongchecksum) < diff3)
    {
         // get new diff3  
         // if abs(destination - target) < diff3 then diff3 = abs(destination - target)
         diff3 = abs(destinationstrongchecksum - targetstrongchecksum);

         if (result == 1)
         {
              // remove destination file
              dummyfile= rename( destinationfile.c_str(), "deleme.bin" );
           
              system("rm deleme.bin");
          
              // rename old counterbak.bin destinationfile if there is one
              dummyfile= rename( "counterbak.bin" , destinationfile.c_str() );
         }
         
           // copy new counter.bin to counterbak.tin
         system("cp counter.bin counterbak.bin");
    
         result = 1;
    }

    // check lock file
    dummyfile = checklockfile(lockfile);

    // display output (for testing only)
    cout << "Diff3 " << diff3 << " Destination sum " << destinationstrongchecksum << " Target sum "<< targetstrongchecksum << "\n";

//  dummyfile = viewfile1(file1, buffersize, filesize1);

// ====================================================================================================================================================
// Subtracting from destination file

    // remove counter.bin
    system("remove counter.bin"); // if it exist
  
// =======================================================================================================================
    // Generate random file
    if (!c1myfile1.eof())
    {
         c1myfile1 >> seed; 
         srand((unsigned int) seed);
    }
    if (c1myfile1.eof())
    {
         c1myfile1.close();
         c1myfile1.clear();
         c1myfile1.flush();
         cout << "Please load another random seed file" << "\n";
         cin >> pause;
         c1myfile1.open(seedfile.c_str(), ios::in);
         if (!c1myfile1)
         {
              cout << "There is no file list." << "\n";
              c1myfile1.close();
              c1myfile1.clear();
              c1myfile1.flush();
              exit(0);           
         }
         c1myfile1 >> seed; 
         srand((unsigned int) seed);
    }
// =======================================================================================================================
         filesize2 = filesize1;        
         system("rm temp.bin"); // removing the previous file
         file2 = "temp.bin";
         // create temp bin
         myfile1.open(file2.c_str(), ios::out  | ios::binary);
         if (!myfile1)
         {
              myfile1.close();
              cout << "error in line 38" << " " << file2 << "\n";
              cin >> pause;
              exit(1);
         }
         myfile1.close();
         myfile1.clear();
         myfile1.flush();
         // Get random binary          
         count2 = buffersize * -1;
         // start second loop
         do
         {
              count2 = count2 + buffersize;
              byte = (rand() % (255*buffersize));
              whatdo = "write";
              file2 = "temp.bin";
              // write random binary
              dummyfile = binaryreadwrite(whatdo, file2, count2, byte, buffersize);

              // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< NOTE CAN ADD RESEEDED RANDOM NUMBER GENERATOR WHERE WITH SEED FILE
//              c1myfile1 >> seed; 
//              srand((unsigned int) seed);

          // end second loop for random file size
         } while(count2 < filesize2);

// =========================================================================================================================
    // subtract destination file to random file output counter.bin file
         file1 = "counter.bin";
         myfile1.open(file1.c_str(), ios::out  | ios::binary);
         if (!myfile1)
         {
              myfile1.close();
              cout << "error in line 245" << " " << file1 << "\n";
              cin >> pause;
              exit(1);
         }
         myfile1.close();
         myfile1.clear();
         myfile1.flush();
         numberbase = (buffersize * 255) + 1;
         carry = 0;
         count2 = buffersize * -1;
         // start third loop
         do
         {
              // increment file variable
              count2 = count2 + buffersize;

              // set byte1 to zero
              byte1 = 0;

              // read byte1 if less than filesize
              whatdo = "read";

              if (count2 < filesize1 - 1)
              { 
                   byte1 = binaryreadwrite(whatdo, destinationfile, count2, byte, buffersize);
              }

              // // set byte2 to 0
              byte2 = 0;

              // read byte2 if less than filesize
              if (count2 < filesize1 - 1) // Dont have to use minus one here because it is upto filesize1 - 1 already.
              {
                   byte2 = binaryreadwrite(whatdo, file2, count2, byte, buffersize);
              }

              // byte3 = byte1 - byte2 - carry;
              byte3 = byte1 - byte2 - carry;

              // carry = 0;
              carry = 0;

              // if byte < 0 subtract from the base
              if (byte3  < 0)
              {
                   byte3 = byte3 + numberbase;
                   carry = 1;
              }

              // Check for error
              if (byte3 > (numberbase - 1))
              {
                   cout << "Houston we have a problem\n";
                   cout << "byte3 greater than the base - 1\n";
                   cin >> pause;
                   exit(0);
              }

              if (byte3 < 0)
              {
                   cout << "Houston we have a problem\n";
                   cout << "byte3 less than 0\n";
                   cin >> pause;
                   exit(0);
              }

              // write random binary
              whatdo = "write";
              dummyfile = binaryreadwrite(whatdo, file1, count2, byte3, buffersize);


         // end third loop
         } while(count2 < filesize1 -1); // We can use filesize2 or filesize3 here as our stop. I chose filesize2 so it would not copy into output file.
                                      // from the destination file.
         // if carry has value write it
//         if (carry > 0)
//         {
//              // write random binary
//              whatdo = "write";
//              dummyfile = binaryreadwrite(whatdo, file1, count2, carry, buffersize);
//              // write to addition file              
//              carry = 0;
//         }
// =========================================================================================================================

    // get destination
    destinationstrongchecksum = getstrongchecksum(file1, howmanyweightedsums, buffersize);

    // break loop if diff3 == 0
    if (abs(targetstrongchecksum - destinationstrongchecksum) == 0)
    {
         if (targetstrongchecksum == destinationstrongchecksum)
         {
              // copy new counter.bin to counterbak.tin
              dummyfile= rename( "counter.bin" , file3.c_str() );
              cout << "File Reconstructed" << "\n";
              cout << "PROGRAM ENDED!!!!!!" << "\n";
              // close seed file
              c1myfile1.close();
              c1myfile1.clear();
              c1myfile1.flush();
              // remove temp.bin
              system("rm temp.bin"); // if it exist
              // remove counterbak.bin
              system("rm counterbak.bin");
              exit(0);
         }
    }

    // Run the pendulum algorithm  
    // if abs(destination - target) < diff3 then backup counter 
    if (abs(targetstrongchecksum - destinationstrongchecksum) < diff3)
    {

         // get new diff3  
         // if abs(destination - target) < diff3 then diff3 = abs(destination - target)
         diff3 = abs(destinationstrongchecksum - targetstrongchecksum);

         if (result == 1)
         {
              // remove destination file
              dummyfile= rename( destinationfile.c_str(), "deleme.bin" );
           
              system("rm deleme.bin");
          
              // rename old counterbak.bin destinationfile if there is one
              dummyfile= rename( "counterbak.bin" , destinationfile.c_str() );
         }
         
           // copy new counter.bin to counterbak.tin
         system("cp counter.bin counterbak.bin");
    
         result = 1;
 
    }

    // check lock file
    dummyfile = checklockfile(lockfile);

    // display output (for testing only)
    // display output (for testing only)
    cout << "Diff3 " << diff3 << " Destination sum " << destinationstrongchecksum << " Target sum "<< targetstrongchecksum << "\n";

//  dummyfile = viewfile1(file1, buffersize, filesize1);

    goto Startprogram;         

}
