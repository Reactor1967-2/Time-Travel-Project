// This generates a random binary file
// Copyright (C) 2016 http://time-travel.institute
// ============================================================================================
 // declare includes
    #include <cstdlib>
    #include <iostream>
    #include <stdlib.h>
    #include <fstream>
    #include <sstream>
    #include <string> 
    #include <cmath>
    #include <ctime>
    #include <cstdio>
    #include <iostream>
    #include "timecheckhacking.h"
// ============================================================================================
    // Declare namespace
    using namespace std;
// ============================================================================================     
// declare globals 
// ============================================================================================
// declare subs
// ======================================================================================================================
int binaryreadwrite(string whatdo, string file1, long long byteposition, int byte, int buffersize)
{

    unsigned char buffer(buffersize);
    char pause;
    int byte1 = byte;
    long long count1 = byteposition;
    long long begin1;
//     int buffersize = 1;
       
    // open file
    fstream myfile1(file1.c_str(), ios::out  | ios::in | ios::binary);
    if (!myfile1)
    {
         myfile1.close();
         cout << "error in line 79" << " " << file1 << "\n";
         cin >> pause;
         exit(1);
    }
    if (whatdo == "read")
    {
// cout << byte1 << " We are reading bytes " << "\n"; // debug code
         myfile1.seekg(count1);
         myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
         begin1 = myfile1.tellg();
         byte1 = (int)buffer;
         myfile1.close();
         myfile1.clear();
         myfile1.flush();
         return(byte1);
    }
    if (whatdo == "write")
    {
// cout << byte1 << " We are writing bytes " << "\n"; // debug code
         buffer = (unsigned char)byte1;
         myfile1.seekp(count1);
         myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
         begin1 = myfile1.tellp();
         myfile1.close();
         myfile1.clear();
         myfile1.flush();
         return(0);
    } 
     

    cout << "Error in binary read and write" << "\n";
    cin >> pause;
    exit(1);
}
// =============================================================================================
// declare main
int main (int argc, char *argv[])
{ 
         // declare variables
         int dummyfile;
         string whatdo;
         int byte;
         int buffersize;
         long long count2;
         string pause;
         fstream myfile1;
         string file2;
         long long seed;
         string seedfile = "random.txt";
         fstream c1myfile1;
         long long filesize2;

         // read command line input
         filesize2 = strtoull(argv[1],NULL,10);
         buffersize = atoi( argv[2]); // How many bytes we are reading at a time.

         c1myfile1.open(seedfile.c_str(), ios::in);
         if (!c1myfile1)
         {
              cout << "There is no file list." << "\n";
              c1myfile1.close();
              c1myfile1.clear();
              c1myfile1.flush();
              exit(0);           
         }




// =======================================================================================================================
    // Generate random file
    if (!c1myfile1.eof())
    {
         c1myfile1 >> seed; 
         srand((unsigned int) seed);
    }
    if (c1myfile1.eof())
    {
         c1myfile1.close();
         c1myfile1.clear();
         c1myfile1.flush();
         cout << "Please load another random seed file" << "\n";
         cin >> pause;
         c1myfile1.open(seedfile.c_str(), ios::in);
         if (!c1myfile1)
         {
              cout << "There is no file list." << "\n";
              c1myfile1.close();
              c1myfile1.clear();
              c1myfile1.flush();
              exit(0);           
         }
         c1myfile1 >> seed; 
         srand((unsigned int) seed);
    }
// =======================================================================================================================
                
         system("rm temp.bin"); // removing the previous file
         file2 = "temp.bin";
         // create temp bin
         myfile1.open(file2.c_str(), ios::out  | ios::binary);
         if (!myfile1)
         {
              myfile1.close();
              cout << "error in line 38" << " " << file2 << "\n";
              cin >> pause;
              exit(1);
         }
         myfile1.close();
         myfile1.clear();
         myfile1.flush();
         // Get random binary          
         count2 = buffersize * -1;
         // start second loop
         do
         {
              count2 = count2 + buffersize;
              byte = (rand() % (255*buffersize));
              whatdo = "write";
              file2 = "temp.bin";
              // write random binary
              dummyfile = binaryreadwrite(whatdo, file2, count2, byte, buffersize);

              // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< NOTE CAN ADD RESEEDED RANDOM NUMBER GENERATOR WHERE WITH SEED FILE
//              c1myfile1 >> seed; 
//              srand((unsigned int) seed);

          // end second loop for random file size
         } while(count2 < filesize2 - 1);
         c1myfile1.close();
         c1myfile1.clear();
         c1myfile1.flush();


// =========================================================================================================================
         exit(0);
}
