// THIS GETS THE STRONG CHECK-SUM OF A COMPUTER FILE.
// COPYRIGHT(C) 2016 http://time-travel.institute
 // declare includes
     #include <cstdlib>
     #include <iostream>
     #include <stdlib.h>
     #include <fstream>
     #include <sstream>
     #include <string> 
     #include <cmath>
     #include <ctime>
     #include <cstdio>
     #include <iostream>
// ============================================================================================
    // Declare namespace
    using namespace std;

int main()
{
    // declare variables
    // open file2 for weights
    fstream c1myfile3("weights.txt", ios::in);
    string file1; 
//    fstream myfile1;
    long double x1;
    string x2;
    int byte1 = 0;
    long double schecksum = 0;
    long long begin1;
    long long count1;
    long long count2;
    long long size1;
    long long size2;
    long long filesize1;
    long long end1 = 0;
    string pause;
    long long howmanyweightedsums;
    int buffersize;
    unsigned char buffer(buffersize);
    
    cout << "Please have your weights.txt file ready." << "\n";
    cout << "Please enter the name of your file." << "\n";
    cin >> file1;
    cout << "How many weighted sums do you want?" << "\n";
    cin >> howmanyweightedsums;
    cout << "What is your buffer size." << "\n";
    cin >> buffersize;

    // open file1 computer file1
    fstream myfile1(file1.c_str(), ios::in | ios::binary);
    if (!myfile1)
    {
         myfile1.close();
         cout << "Failed to read file one.\n";
         cin >> pause;
         exit(1);
    }

    // get filesize1
    begin1 = myfile1.tellg();
    if (!myfile1)
    {
         myfile1.close();
         cout << "Failed to read file one.\n";
         cin >> pause;
         exit(1);
    }
    myfile1.seekg (0, ios::end);
    end1 = myfile1.tellg();
    filesize1 = (end1-begin1);

    // Two loops that get the strong check-sum
    count1 = 0;
    schecksum = 0;
    // start loop 1
    do
    {
         // read file1
         byte1 = 0;
         // read file1
         myfile1.seekg(count1);
         myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
         begin1 = myfile1.tellg();
         // byte1 = read from file 1
         byte1 = (int)buffer;
         count2 = 0;
         // start loop 2
         do
         {
              // count2++;
              count2++;
              // read weight file. 
              c1myfile3.precision(36);
              c1myfile3 >> x1;
              // schecksum = schecksum + (byte1 * x1);
              schecksum = schecksum + (byte1 * x1);
              // end loop 2 for how many weighted sums
         } while(count2 < howmanyweightedsums);
         // count1 = count1 + buffersize;
         count1 = count1 + buffersize;
         // end loop 1 for count1 < filesize1 - 1
    } while (count1 <  filesize1 - 1);
    // close file1 for program
    myfile1.close();
    myfile1.clear();
    myfile1.flush();     
    // close file2 for weights
    c1myfile3.close();
    c1myfile3.clear();
    c1myfile3.flush();
    cout.precision(36);
    cout << schecksum << "\n";
    exit(0);
}

