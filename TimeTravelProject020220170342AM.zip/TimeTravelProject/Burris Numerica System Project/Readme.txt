STILL UNDER CONSTRUCTION

There will be a program here that codes a computer file a BNS number and decodes the BNS number back to a computer file.
This is for time travel file attachments in temporal messages and for backing up computer files.
