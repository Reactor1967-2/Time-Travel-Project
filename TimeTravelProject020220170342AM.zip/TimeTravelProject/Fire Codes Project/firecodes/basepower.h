#ifndef basepower_h
#define basepower_h

     #include <cstdlib>
     #include <iostream>
     #include <stdlib.h>
     #include <fstream>
     #include <sstream>
     #include <string> 
     #include <cmath>
     #include <ctime>
     #include <cstdio>
     #include <iostream>

// ======================================================================================================================
    // Declare namespace
    using namespace std;
// ======================================================================================================================
// Header key goes here
// ======================================================================================================================
int createbpchecksum(string file1, long long numberbase, int buffersize)
{ 

    // declare variables
    long long begin1;
    long long end1;
    unsigned char buffer;
    char pause;
    int byte1 = 0;
    long long count1 = -1;
    long long filesize1 = 0;
    long long pbnum1 = 0;
    long long pbnum2 = 0;
    long long pbnum3 = 0;
    long long carry = 0;
    int test = 0;
    int test2 = 0;
    int test3 = 0;
    
    // create power file
    fstream c1myfile1("power.txt", ios::out);
    c1myfile1 << 1 << "\n";
    c1myfile1.close();
    c1myfile1.clear();
    c1myfile1.flush();

    // create check sum file
    fstream c1myfile3("pbchecksum.txt", ios::out);
    c1myfile3.close();
    c1myfile3.clear();
    c1myfile3.flush();

    // open binary file
    // open file1
    fstream myfile1(file1.c_str(), ios:: in | ios:: binary);
    if (!myfile1)
    {
         cout << "Error in line 1029.\n";
         cin >> pause;
         myfile1.close();
         myfile1.clear();
         myfile1.flush();
         exit(1); // terminate with error
    }

    // get file size of binary file
     begin1 = myfile1.tellg();
     if (!myfile1)
     {
          myfile1.close();
	  myfile1.clear();
	  myfile1.flush();
          cout << "Failed to read file two.\n";
          cin >> pause;
          exit(1);
     }

     myfile1.seekg (0, ios::end);
     end1 = myfile1.tellg();
     filesize1 = (end1-begin1);

    // set count1
    count1 = -1;
    // start do loop
    do
    {
         //increment count
         count1++;
         // read byte from binary file
         // read file 1
         myfile1.seekg(count1);
         myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
         begin1 = myfile1.tellg();
         byte1 = (int)buffer;

         // delete addition file
//         system("rm addition.txt");

//         // open addition file
         fstream c1myfile2("addition.txt", ios::out);

         // open power file
         c1myfile1.open("power.txt", ios::in);

         // set carry to 0
         carry = 0;

         // multiple byte times base power file <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<,
         do
         {    

              pbnum1 = 0;
              // Read power file
//              c1myfile1 >> pbnum1;
              if (!c1myfile1.eof( ))
              {
                   c1myfile1 >> pbnum1;
              }

              pbnum2 = 0;
              // multiply number * byte
              if (!c1myfile1.eof( ))
              {
                   pbnum2 = (pbnum1 * byte1) + carry;
              }

              if (!c1myfile1.eof( ))
              {
                   carry = 0;
              }

              if (!c1myfile1.eof( ))
              {
                   // convert to base and set carry
                   if (pbnum2 >= numberbase)
                   {
                        pbnum3 = 0;

                        // convert to numberbase
                        // carry = int(pbnum2 / numberbase);
                        // pbnum3 = pbnum2 - (int(pbnum2/numberbase) * numberbase);
                        carry = pbnum2/numberbase;
                        pbnum3 = pbnum2 - (carry * numberbase);
                   }    

              }

              if (!c1myfile1.eof( ))
              {

                   if (pbnum2 < numberbase)
                   {
                        pbnum3 = 0;
                        pbnum3 = pbnum2;
                   }
              }
              
              if (!c1myfile1.eof( ))
              {
                   // Error out if carry greater
                   if (carry > numberbase)
                   {
                        cout << "Carry greater than number base line 154." << "\n";
                        cin >> pause;
                        exit(0);
                   }
              }

              if (!c1myfile1.eof( ))
              {
                   if (pbnum3 > numberbase)
                   {
                        cout << "Carry greater than number base. line 274" << "\n";
                        cin >> pause;
                        exit(0);
                   }
              }


              // write to addition file              
//              c1myfile2 << pbnum3 << "\n";
              if (!c1myfile1.eof( ))
              {
                   if (pbnum3 > 0)
                   {
                        c1myfile2 << pbnum3 << "\n";
                   }

              }

              if (c1myfile1.eof( ))
              {
                   if (carry > 0)
                   {
                        c1myfile2 << carry << "\n";
                        carry = 0;
                   }
              }


         } while(!c1myfile1.eof( )); 


         // close power file 
        c1myfile1.close();
        c1myfile1.clear();
        c1myfile1.flush();

         // close addition file
         c1myfile2.close();
         c1myfile2.clear();
         c1myfile2.flush();

         // add addition file to check sum file <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

         // Reopen additon file
         c1myfile2.open("addition.txt", ios::in); 

         // open check-sum file
         c1myfile3.open("pbchecksum.txt", ios::in); 

         // create temp file to hold result
         // open temp file for multiplication (This file will be renamed).
         fstream c1myfile4("temp.txt", ios::out);

         // set carry to 0
         carry = 0;
         do
         {


              test2 = 0;
              test3 = 0;
              if (!c1myfile2.eof( ))
              {
                   test2 = 1;
              }

              if (!c1myfile3.eof( ))
              {
                   test3 = 1;
              } 



              // set pbnum to 0
              pbnum1 = 0;

              // read addition file
              if (test2 == 1)
              {
                   c1myfile2 >> pbnum1;
              }

              pbnum2 = 0;

              // check-sum file              
              if (test3 == 1)
              {
                   c1myfile3 >> pbnum2;
              }


              // clear pbnum3
              pbnum3 = 0;
              
              // do base addition
              if (test2 + test3 > 0)
              {
                   pbnum3 = pbnum1 + pbnum2 + carry;
              }

              // set carry to 0
              if (test2 + test3 > 0)
              {
                   carry = 0;
              }

              if (test2 + test3 > 0)
              {
                   // convert to base and set carry
                   if (pbnum3 >= numberbase)
                   {
                
                        // convert to numberbase
                        carry = pbnum3/numberbase;
                        pbnum3 = pbnum3 - (carry * numberbase);        

                   }
              }
              

              if (test2 + test3 > 0)
              {
                   // Error out if carry greater
                   if (carry >= numberbase)
                   {
                        cout << "Carry greater than number base. line 267" << "\n";
                        cin >> pause;
                        exit(0);
                   }

                   if (pbnum3 >= numberbase)
                   {
                        cout << "Carry greater than number base. line 274" << "\n";
                        cin >> pause;
                        exit(0);
                   }
              }

              // write to addition file              
              if (test2 + test3 > 0)
              {
                   if (pbnum3 > 0)
                   {
                        c1myfile4 << pbnum3 << "\n"; // This is a temporay fix. It might need fixed later.
                   }
              }

              if (test2 + test3 == 0)
              {
                   if (carry > 0)
                   {
                        c1myfile4 << carry << "\n";
                        carry = 0;
                   } 
              } 

         } while(test2 + test3 > 0); 


         // close temp file
        c1myfile4.close();
        c1myfile4.clear();
        c1myfile4.flush();

         // close check-sumfile file
        c1myfile3.close();
        c1myfile3.clear();
        c1myfile3.flush();

        // close addition file
        c1myfile2.close();
        c1myfile2.clear();
        c1myfile2.flush();

        // delete addition file
        system("rm addition.txt");

        // delete pbchecksum.txt
        system("rm pbchecksum.txt");

        // rename temp.txt pbchecksum.txt
        system("mv temp.txt pbchecksum.txt");  

        // multiply power file by 256 <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< 
        if (count1 == filesize1 - 1) // Getting out if done because won't need the power file again.
        {
             break;
        }
 
        // open power file
        fstream c1myfile1("power.txt", ios::in);

        // create temp file to hold result
        // open temp file for multiplication (This file will be renamed).
        c1myfile4.open("temp.txt", ios::out); 

        // set carry to 0
        carry = 0;

        // multiple power file by 256
        do
        {    
             pbnum1 = 0;
             // Read power file
             if (!c1myfile1.eof( ))
             {
                  c1myfile1 >> pbnum1;
             }

             pbnum2 = 0;
             // multiply number * byte
             pbnum2 = (pbnum1 * 256) + carry;

             if (!c1myfile1.eof( ))
             {
                  carry = 0;
             }

             // convert to base and set carry
             if (pbnum2 >= numberbase)
             {
                   pbnum3 = 0;

                // convert to numberbase
//                carry = int(pbnum2 / numberbase);
//                pbnum3 = pbnum2 - (int(pbnum2/numberbase) * numberbase);
                  carry = pbnum2 / numberbase;
                  pbnum3 = pbnum2 - (carry * numberbase);
             }

             if (pbnum2 < numberbase)
             {
                  pbnum3 = 0;
                  pbnum3 = pbnum2;
             }            
              
             // Error out if carry greater
             if (carry >= numberbase)
             {
                  cout << "Carry greater than number base." << "\n";
                  cin >> pause;
                  exit(0);
             }

              if (pbnum3 >= numberbase)
              {
                   cout << "Carry greater than number base. line 413" << "\n";
                   cin >> pause;
                   exit(0);
              }


             // write to temp file              
//             c1myfile4 << pbnum3 << "\n";
             if (!c1myfile1.eof( ))
             {
                   if (pbnum3 > 0)
                   {
                        c1myfile4 << pbnum3 << "\n";
                   }
             }

             if (c1myfile1.eof( ))
             {
                  if (carry > 0)
                  {
                       c1myfile4 << carry << "\n";
                       carry = 0;
                  }
             }


        } while(!c1myfile1.eof( )); 

        // close temp file
       c1myfile4.close();
       c1myfile4.clear();
       c1myfile4.flush();

        // close power file
       c1myfile1.close();
       c1myfile1.clear();
       c1myfile1.flush();

        // delete power.txt
        system("rm power.txt");

        // rename temp.txt power.txt
        system("mv temp.txt power.txt");

    // repeat to end of binary file
   } while (count1 < filesize1); 

   // Make sure binary file closed
   myfile1.close();
   myfile1.clear();
   myfile1.flush();

   // exit sub
   return(0);
}
// ======================================================================================================================
 int decodepbchecksum(string file1, long long filesize1, long long numberbase, int buffersize)
 {
    // declare variables
    long long begin1;
    long long end1;
    unsigned char buffer;
    char pause;
    int byte1;
    long long count1;
    long long count2;
    long long count3 = filesize1;
    long long pbnum1;
    long long pbnum2;
    long long pbnum3;
    long long tempnum1;
    long long tempnum2;
    long long carry;
    int test;
    int test2; // for testing and or conditions

    // open power file
    fstream c1myfile1("power.txt", ios::in);
    c1myfile1.close();
    c1myfile1.clear();
    c1myfile1.flush();

    // declare addition file
    fstream c1myfile2;

    // open check sum file
    fstream c1myfile3("pbchecksum.txt", ios::in);
    c1myfile3.close();
    c1myfile3.clear();
    c1myfile3.flush();

    // declare temp file
    fstream c1myfile4;

    // create binary file
    fstream myfile1(file1.c_str(), ios:: out | ios:: binary);
    if (!myfile1)
    {
         cout << "Error in line 1029.\n";
         cin >> pause;
         myfile1.close();
         myfile1.clear();
         myfile1.flush();
         exit(1); // terminate with error
    }

    // set count1
    count1 = -1;

    // set byte to 255
    byte1 = 255;

// byte1 = 10; // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< FOR TESTING ONLY

    // start do loop 
    do
    {

         // open base power file
         fstream c1myfile1("power.txt", ios::in);    

         // multiply byte times base power file   
         // write to addition file
         // create temp file to hold result
         // open temp file for multiplication (This file will be renamed).
         c1myfile4.open("temp.txt", ios::out); 

         // set carry to 0
         carry = 0;

// ===================================================================================================================================

         // multiple power file by byte1
         do
         {    
              pbnum1 = 0;
              // Read power file
//              c1myfile1 >> pbnum1;              
              if (!c1myfile1.eof( ))
              {
                   c1myfile1 >> pbnum1;
              }

              // Initialize test2
              test2 = 1;
              if (pbnum1 == 0)
              {
                   test2 = 0;
              }
 
              pbnum2 = 0;
              // multiply number * byte
              pbnum2 = (pbnum1 * byte1) + carry;

              // set carry to 0
              if (!c1myfile1.eof( ))
              {
                   carry = 0;
              }


              // convert to base and set carry
              if (pbnum2 >= numberbase)
              {
                 pbnum3 = 0;

                 // convert to numberbase
                 carry = int(pbnum2 / numberbase);
                 pbnum3 = pbnum2 - (int(pbnum2/numberbase) * numberbase);

              }

              if (pbnum2 < numberbase)
              {
                   pbnum3 = 0;
                   pbnum3 = pbnum2;
              }
             
              
              // Error out if carry greater
              if (carry > numberbase)
              {
                   cout << "Carry greater than number base." << "\n";
                   cin >> pause;
                   exit(0);
              }

              // write to temp file              
//              c1myfile4 << pbnum3 << "\n";
              if (test2 > 0)
              {
                   c1myfile4 << pbnum3 << "\n";
              }

//              if (test == 0)
//              {
//                   if (carry > 0)
//                   {
//                        c1myfile4 << carry << "\n";
//                        carry = 0;
//                   }
//              }

         } while(test2 > 0); 

         if (carry > 0)
         {
              // write to addition file              
              c1myfile4 << carry << "\n";
              carry = 0;
         }

         // close temp file
         c1myfile4.close();
         c1myfile4.clear();
         c1myfile4.flush();

         // close power file
         c1myfile1.close();
         c1myfile1.clear();
         c1myfile1.flush();

         system("mv temp.txt addition.txt"); 

// ========================================================================================================================

         // compare addition file to check-sum file
         // open addition file
         c1myfile2.open("addition.txt", ios::in);

         // open check sum file
         c1myfile3.open("pbchecksum.txt", ios::in);

         // set count1 and count2 to 0
         count1 = 0;
         count2 = 0;         
         // set pbnum1 to 0
         pbnum1 = 0;
         // set pbnum2 to 0
         pbnum2 = 0;

         // start do loop
         do
         {
              tempnum1 = 0;
              // read addition
              if (!c1myfile2.eof( ))
              {
                   c1myfile2 >> tempnum1;
                   if (tempnum1 > 0)
                   { 
                        count1++;
                   }
              }

              tempnum2 = 0;
              // read check sum
              if (!c1myfile3.eof( ))
              {
                   c1myfile3 >> tempnum2;
                   if (tempnum2 > 0)
                   {
                        count2++;
                   }
              }
              
              if (tempnum1 != tempnum2)
              {
                   pbnum1 = tempnum1;
                   pbnum2 = tempnum2;

              }

              // set test2 to 0
              test2 = 0;

              if (!c1myfile2.eof( ))
              {
                   test2 = 1;
              }

              if (!c1myfile3.eof( ))
              {
                   test2 = 2;
              }

         // end loop at end of file for addition and check sum file
         } while(test2 > 0); 

         // close addition and check-sum file
         // close temp file
         c1myfile2.close();
         c1myfile2.clear();
         c1myfile2.flush();

         // close power file
         c1myfile3.close();
         c1myfile3.clear();
         c1myfile3.flush();


         // initilize test
         test = 0;
         // if addition file point greater than check sum test = 1
         if (count1 > count2)
         {
              test = 1;
         } 
         // if check sum file point greater then addition test = 2
         if (count1 < count2)
         {
              test = 2;
         } 
         // if addition and checksum equal and addition number greater test = 1
         if (count1 == count2)
         {
                   if (pbnum1 > pbnum2)
                   {
                        test = 1;
                   }
         } 
         // if addition and checksum equal and checksum number greater test = 2
         if (count1 == count2)
         {
                   if (pbnum1 < pbnum2)
                   {
                        test = 2;
                   }
         }  
         // if addition and checksum file pointer and number equal test = 0
         if (count1 == count2)
         {
                   if (pbnum1 == pbnum2)
                   {
                        test = 0;
                   }
         }

         if (test == 2)
         {
              if (count3 == 1)
              {
                   byte1 = pbnum2;
              }
         }  

 
         // if addition file = or less than check-sum file write byte to binary file and decrement file pointer reset byte
         if (test == 2)
         {
               
               buffer = (unsigned char)byte1;
               myfile1.seekp(count3 - 1);
               myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
               begin1 = myfile1.tellp();
         }

         if (test == 0)
         {
               
               buffer = (unsigned char)byte1;
               myfile1.seekp(count3 - 1);
               myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
               begin1 = myfile1.tellp();
         }

         if (test == 2)
         {
              if (count3 == 1)
              {
                   goto getout;
              }
         }  



//if (test == 2 || test  == 0)
//{ 
//    cout << test << "\n";
//    cout << count1 << " " << count2 << " " << count3 << "\n";
//    cout << pbnum1 << " " << pbnum2 << " " << pbnum3 << "\n";
//    cout << byte1 << "\n";
//    myfile1.close();
//    myfile1.clear();
//    myfile1.flush();
//    cin >> pause;
//}

// ==========================================================================================================================================
        // if addition file = or less than check-sum file subtract addition file from check-sum file
         if (test == 2) 
         {

              // open addition file
              c1myfile2.open("addition.txt", ios::in);

              // open check sum file
              c1myfile3.open("pbchecksum.txt", ios::in);

              // open temp file
              c1myfile4.open("temp.txt", ios::out); 

// pbnum3 = 832479823;
// c1myfile4 << pbnum3 << "\n";

              // set carry to 0
              carry = 0;

              // start do loop
              do
              {
                   // set pbnum1 to 0
                   pbnum1 = 0;
                   // read addition
                   if (!c1myfile2.eof( ))
                   {
                        c1myfile2 >> pbnum1;
                   }

// cout << "1 " << pbnum1 << "\n";
// cin >> pause;
                   // set pbnum2 to 0
                   pbnum2 = 0;
                   // read check sum
                   if (!c1myfile3.eof( ))
                   {
                        c1myfile3 >> pbnum2;
                   }

// cout << "2 " << pbnum2 << "\n";
// cin >> pause;

                   // byte3 = byte1 - byte2 - carry;
                   pbnum3 = pbnum2 - pbnum1 - carry;

// cout << "3 " << pbnum3 << "\n";
// cin >> pause;

                   // initiliaze carry
                   if (!c1myfile2.eof( ))
                   {
                        carry = 0;
                   }
                   if (!c1myfile3.eof( ))
                   {
                        carry = 0;;
                   }

// cout << "4 " << carry << "\n";
// cin >> pause;

                   // if byte < 0 subtract from the base
                   if (pbnum3  < 0)
                   {
                        pbnum3 = pbnum3 + numberbase;
                        carry = 1;
                   }

// cout << "5 " << pbnum3 << " " << carry << "\n";
// cin >> pause;

                   // Check for error
                   if (pbnum3 > (numberbase - 1))
                   {
                        cout << "Houston we have a problem\n";
                        cout << "pbnum3 greater than the base - 1\n";
                        cin >> pause;
                        exit(0);
                   }

                   // set test2 to 0. Initilize test 2
                   test2 = 0;

                   if (!c1myfile2.eof( ))
                   {
                        test2 = 1;
                   }

                   if (!c1myfile3.eof( ))
                   {
                        test2 = 2;
                   }

// cout << "6 " << pbnum3 << " " << test2 << "\n";
// cin >> pause;


                   // write remainder to temp file
                   if (test2 > 0)
                   {
                        c1myfile4 << pbnum3 << "\n";
                   }
            
                   if (test2 == 0)
                   {
                        if (carry > 0)
                        {  
                             c1myfile4 << carry << "\n";
                             carry = 0;
                        }
                   }

              // End do loop for end of file
              } while(test2 > 0); 

              // if carry has value write it
//              if (carry > 0)
//              {
//                   // write to addition file              
//                   c1myfile4 << carry << "\n";
//                   carry = 0;
//              }

              // close files
              // close addition file
              c1myfile2.close();
              c1myfile2.clear();
              c1myfile2.flush();

              // close check-sum file
              c1myfile3.close();
              c1myfile3.clear();
              c1myfile3.flush();

              // close temp file
              c1myfile4.close();
              c1myfile4.clear();
              c1myfile4.flush();

// cout << "Check files fixing to goto subtract " << test << "\n";
// cin >> pause; 
              
              // delete pbchecksum.txt
              system("rm pbchecksum.txt");

              // move temp file to check-sum file
              system("mv temp.txt pbchecksum.txt");
         }  

// ==========================================================================================================================================  
         // if addition file = or less than check-sum file subtract addition file from check-sum file
         if (test == 0)
         {

              // open addition file
              c1myfile2.open("addition.txt", ios::in);

              // open check sum file
              c1myfile3.open("pbchecksum.txt", ios::in);

              // open temp file
              c1myfile4.open("temp.txt", ios::out); 

// pbnum3 = 832479823;
// c1myfile4 << pbnum3 << "\n";

              // set carry to 0
              carry = 0;

              // start do loop
              do
              {
                   // set pbnum1 to 0
                   pbnum1 = 0;
                   // read addition
                   if (!c1myfile2.eof( ))
                   {
                        c1myfile2 >> pbnum1;
                   }

// cout << "1 " << pbnum1 << "\n";
// cin >> pause;
                   // set pbnum2 to 0
                   pbnum2 = 0;
                   // read check sum
                   if (!c1myfile3.eof( ))
                   {
                        c1myfile3 >> pbnum2;
                   }

// cout << "2 " << pbnum2 << "\n";
// cin >> pause;

                   // byte3 = byte1 - byte2 - carry;
                   pbnum3 = pbnum2 - pbnum1 - carry;

// cout << "3 " << pbnum3 << "\n";
// cin >> pause;

                   // initiliaze carry
                   if (!c1myfile2.eof( ))
                   {
                        carry = 0;
                   }
                   if (!c1myfile3.eof( ))
                   {
                        carry = 0;;
                   }

// cout << "4 " << carry << "\n";
// cin >> pause;

                   // if byte < 0 subtract from the base
                   if (pbnum3  < 0)
                   {
                        pbnum3 = pbnum3 + numberbase;
                        carry = 1;
                   }

// cout << "5 " << pbnum3 << " " << carry << "\n";
// cin >> pause;

                   // Check for error
                   if (pbnum3 > (numberbase - 1))
                   {
                        cout << "Houston we have a problem\n";
                        cout << "pbnum3 greater than the base - 1\n";
                        cin >> pause;
                        exit(0);
                   }

                   // set test2 to 0. Initilize test 2
                   test2 = 0;

                   if (!c1myfile2.eof( ))
                   {
                        test2 = 1;
                   }

                   if (!c1myfile3.eof( ))
                   {
                        test2 = 2;
                   }

// cout << "6 " << pbnum3 << " " << test2 << "\n";
// cin >> pause;


                   // write remainder to temp file
                   if (test2 > 0)
                   {
                        c1myfile4 << pbnum3 << "\n";
                   }
            
                   if (test2 == 0)
                   {
                        if (carry > 0)
                        {  
                             c1myfile4 << carry << "\n";
                             carry = 0;
                        }
                   }

              // End do loop for end of file
              } while(test2 > 0); 

              // if carry has value write it
//              if (carry > 0)
//              {
//                   // write to addition file              
//                   c1myfile4 << carry << "\n";
//                   carry = 0;
//              }

              // close files
              // close addition file
              c1myfile2.close();
              c1myfile2.clear();
              c1myfile2.flush();

              // close check-sum file
              c1myfile3.close();
              c1myfile3.clear();
              c1myfile3.flush();

              // close temp file
              c1myfile4.close();
              c1myfile4.clear();
              c1myfile4.flush();

// cout << "Check files fixing to goto subtract " << test << "\n";
// cin >> pause; 
              
              // delete pbchecksum.txt
              system("rm pbchecksum.txt");

              // move temp file to check-sum file
              system("mv temp.txt pbchecksum.txt");

         }  
//=====================================================================================================================
         // if addition file = or less than check-sum file set byte back to 255
         if (test == 0)
         {
              byte1 = 255;
              count3--;
         }
         if (test == 2)
         {
              byte1 = 255;
              count3--;
         }  
         if (count3 == 0)
         {
//              goto getout;
         }  

// ====================================================================================================================

         // Initilize count1
         count1 = 1;
         // rebuild power file if addition file is equal to or less than check-sum file
         if (test == 2) 
         {
              // delete power file
              system("rm power.txt");

              // open power file
              c1myfile1.open("power.txt", ios::out);

              // set power file to 256
              c1myfile1 << 1 << "\n";

              // close power file
              c1myfile1.close();
              c1myfile1.clear();
              c1myfile1.flush();

              if (count3 == 0)
              {
                   goto Line1208; // Since making changes to debuging watch this. ????
              }

              do
              {
                   // open power file
                   fstream c1myfile1("power.txt", ios::in);

                   // create temp file to hold result
                   // open temp file for multiplication (This file will be renamed).
                   c1myfile4.open("temp.txt", ios::out); 

                   // set carry to 0
                   carry = 0;
                   // multiple power file by 256
                   do
                   {    
                        // set pbnum1 to 0
                        pbnum1 = 0;
                        // Read power file                        
                        if (!c1myfile1.eof( ))
                        {
                             c1myfile1 >> pbnum1;
                        }

                        test2 = 1;
                        if (pbnum1 == 0)
                        {
                             test2 = 0;
                        }

                        // set pbnum2 to 0
                        pbnum2 = 0;

                        // multiply number * byte
                        pbnum2 = (pbnum1 * 256) + carry;
                        
                        if (!c1myfile1.eof( ))
                        {
                             carry = 0;
                        }


                        // convert to base and set carry
                        if (pbnum2 >= numberbase)
                        {
                             pbnum3 = 0;
                             // convert to numberbase
                             carry = int(pbnum2 / numberbase);
                             pbnum3 = pbnum2 - (int(pbnum2/numberbase) * numberbase);
                        }

                        if (pbnum2 < numberbase)
                        {
                             pbnum3 = 0;
                             pbnum3 = pbnum2;
                        }

                        // Error out if carry greater
                        if (carry > numberbase)
                        {
                             cout << "Carry greater than number base." << "\n";
                             cin >> pause;
                             exit(0);
                        }

                        // write to temp file              
                        if (!c1myfile1.eof( ))
                        {
                             c1myfile4 << pbnum3 << "\n";
                        }

                        if (c1myfile1.eof( ))
                        {
                             if (carry > 0)
                             {
                                  c1myfile4 << carry << "\n";
                                  carry = 0;

                             }
                        }


                   } while(test2 > 0); 

//                   if (carry > 0)
//                   {
                        // write to addition file              
//                        c1myfile4 << carry << "\n";
//                        carry = 0;
//                   }

                   // close temp file
                   c1myfile4.close();
                   c1myfile4.clear();
                   c1myfile4.flush();

                   // close power file
                   c1myfile1.close();
                   c1myfile1.clear();
                   c1myfile1.flush();

                   // delete power.txt
                   system("rm power.txt");

                   // rename temp.txt power.txt
                   system("mv temp.txt power.txt");

                   // repeat to end of binary file
                   count1++; 
              } while (count1 < count3);

         }  // End if statement
Line1208:
// ===================================================================================================================
         // Initilize count1
         count1 = 1;
         // rebuild power file if addition file is equal to or less than check-sum file
         if (test == 0) 
         {
              // delete power file
              system("rm power.txt");

              // open power file
              c1myfile1.open("power.txt", ios::out);

              // set power file to 256
              c1myfile1 << 1 << "\n";

              // close power file
              c1myfile1.close();
              c1myfile1.clear();
              c1myfile1.flush();

              if (count3 == 0)
              {
                   goto Line1344; // Watch and see if still need this. ????????
              }

              do
              {
                   // open power file
                   fstream c1myfile1("power.txt", ios::in);

                   // create temp file to hold result
                   // open temp file for multiplication (This file will be renamed).
                   c1myfile4.open("temp.txt", ios::out); 

                   // set carry to 0
                   carry = 0;
                   // multiple power file by 256
                   do
                   {    
                        // set pbnum1 to 0
                        pbnum1 = 0;
                        // Read power file                        
                        if (!c1myfile1.eof( ))
                        {
                             c1myfile1 >> pbnum1;
                        }

                        test2 = 1;
                        if (pbnum1 == 0)
                        {
                             test2 = 0;
                        }

                        // set pbnum2 to 0
                        pbnum2 = 0;

                        // multiply number * byte
                        pbnum2 = (pbnum1 * 256) + carry;
                        
                        if (!c1myfile1.eof( ))
                        {
                             carry = 0;
                        }


                        // convert to base and set carry
                        if (pbnum2 >= numberbase)
                        {
                             pbnum3 = 0;
                             // convert to numberbase
                             carry = int(pbnum2 / numberbase);
                             pbnum3 = pbnum2 - (int(pbnum2/numberbase) * numberbase);
                        }

                        if (pbnum2 < numberbase)
                        {
                             pbnum3 = 0;
                             pbnum3 = pbnum2;
                        }

                        // Error out if carry greater
                        if (carry > numberbase)
                        {
                             cout << "Carry greater than number base." << "\n";
                             cin >> pause;
                             exit(0);
                        }

                        // write to temp file              
                        if (!c1myfile1.eof( ))
                        {
                             c1myfile4 << pbnum3 << "\n";
                        }

                        if (c1myfile1.eof( ))
                        {
                             if (carry > 0)
                             {
                                  c1myfile4 << carry << "\n";
                                  carry = 0;

                             }
                        }


                   } while(test2 > 0); 

//                   if (carry > 0)
//                   {
                        // write to addition file              
//                        c1myfile4 << carry << "\n";
//                        carry = 0;
//                   }

                   // close temp file
                   c1myfile4.close();
                   c1myfile4.clear();
                   c1myfile4.flush();

                   // close power file
                   c1myfile1.close();
                   c1myfile1.clear();
                   c1myfile1.flush();

                   // delete power.txt
                   system("rm power.txt");

                   // rename temp.txt power.txt
                   system("mv temp.txt power.txt");

                   // repeat to end of binary file
                   count1++; 
              } while (count1 < count3);

         }  // End if statement
Line1344:
// ===================================================================================================================
         // if addition file > check sum file then decrement byte
         if (test == 1)
         {
              byte1--;
         }  

         // if byte < 0 stop program throw error
         if (byte1 < 0)
         {
              cout << "Failed to reconstruct file" << "\n";
              cin >> pause;
              exit(1);  
         }

         // if check-sum file zero break loop
         if (count3 == -1)
         {
              break;
         } 
//         system("rm addition.txt");
    // repeat loop
    } while(count3 > -1);
getout:
    // Make sure binary file closed
    myfile1.close();
    myfile1.clear();
    myfile1.flush();
    system("rm addition.txt");
    system("rm pbchecksum.txt");
    system("rm power.txt");

    // exit sub
     return(0);
 }
// ======================================================================================================================
int secondopinion(string file1, long long numberbase, int buffersize)
{

    // Declare variables
    long long filesize1;
    long long count1;
    long long begin1;
    long long end1;
    long long checksum;
    long long addition;
    long long remainder;
    long long power;
    unsigned char buffer;
    int byte1;
    string pause;

    // open binary file
    fstream myfile1(file1.c_str(), ios:: in | ios:: binary);
    if (!myfile1)
    {
         cout << "Error in line 1029.\n";
         cin >> pause;
         myfile1.close();
         myfile1.clear();
         myfile1.flush();
         exit(1); // terminate with error
    }

    // get file size of binary file
     begin1 = myfile1.tellg();
     if (!myfile1)
     {
          myfile1.close();
	  myfile1.clear();
	  myfile1.flush();
          cout << "Failed to read file two.\n";
          cin >> pause;
          exit(1);
     }

     myfile1.seekg (0, ios::end);
     end1 = myfile1.tellg();
     filesize1 = (end1-begin1);

     // set count to -1
    count1 = -1;
    power = 1;
     // start first loop
    do
    {
         // increment file position     
         count1++;

         // read byte
         myfile1.seekg(count1);
         myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
         begin1 = myfile1.tellg();
         byte1 = (int)buffer;

        // multiply byte * (base^count)
         addition = byte1 * power;

     // add byte to check-sum
         checksum = checksum + addition;

     // user output
     cout << count1 << " " << byte1 << " " << addition << " " << checksum << " " << power << "\n";
 
    // increase power
    if (count1 < filesize1 - 1)
    {
         power = power * 256;
    }

     // repeat loop
    } while(count1 < filesize1 - 1);
    cout.precision(36);
    cout << "Check-sum in base 10 " << checksum << "\n";
    cout.precision(36);
    cout << "Power in base 10 " << power << "\n";
    cout << " " << "\n";
    cout << "Check-sum in base 99999999" << "\n";
    // start do loop
    do
    {
         remainder = checksum/numberbase;
         checksum = checksum - (remainder * numberbase);
         cout.precision(36);
         cout << checksum  << "\n";
         checksum = remainder;
    } while(checksum > 0);
    
    cout << "\n";
    
    cout << "power in base 99999999" << "\n";
    // start do loop
    do
    {
     
    // convert base
         remainder = power/numberbase;
         power = power - (remainder * numberbase);
         cout.precision(36);
         cout << power  << "\n";
         power = remainder;
     // print to user
     // repeat till remaineder less than the number base
    } while(power > 0);

    
}

#endif 
