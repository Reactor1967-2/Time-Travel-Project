// COPYRIGHT(C) 2017 http://time-travel.institute
// You have to make a reject list using the file command in Linux for this to work.
// Use this in a directory made up of only files that can be deleted!!!!!!
// ===========================================================================================
// declare includes
#include <cstdlib>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <string>
#include <cmath>
#include <ctime>
#include <cstdio>
#include <iostream>
#include <stdio.h>
// ===========================================================================================
// declare name space
using namespace std;
// declare subs
//============================================================================================
int main (int argc, char *argv[])
{
    // declare variables
    string pause;
    string filelist; // input of file list
    string outputfile; // input of output file
    string rejectlist; // input of reject list
    // Get file format list
    system("file * > list.txt");
    fstream c1myfile1; // file list
    fstream c1myfile2; // base script
    fstream c1myfile3; // output file
    fstream c1myfile4; // reject list
    int test;

    // open file format list
    c1myfile1.open("list.txt", ios::in);
    if (!c1myfile1)
    {
         cout << "Something went wrong" << "\n";
         exit(0);
    }
    do
    {
         if (!c1myfile1.eof())
         {
              // read file list
              c1myfile1 >> filelist;
              // open base script
              c1myfile2.open("bash.txt", ios::out);
              if (!c1myfile2)
              {
                   cout << "Something went wrong with base script" << "\n";
                   cin >> pause;
                   exit(0);
              }
              // write command
              c1myfile2 << "#!/bin/bash" << "\n";
              c1myfile2 << "file -b " << filelist << " > output.txt" << "\n";
              // close base script
              c1myfile2.close();
              c1myfile2.clear();
              c1myfile2.flush();
              // chmod base script
              system("chmod 777 bash.txt");
              // execute bash script with system command
              system("./bash.txt"); 
              // open output file output.txt
              c1myfile3.open("output.txt", ios::in);
              if (!c1myfile3)
              {
                   cout << "Something went wrong with output.txt" << "\n";
                   cin >> pause;
                   exit(0);
              }
              // read output file
              c1myfile3 >> outputfile;
              // close output file
              c1myfile3.close();
              c1myfile3.clear();
              c1myfile3.flush();
              // open file format reject list
              c1myfile2.open("reject.txt", ios::in);
              if (!c1myfile2)
              {
                   cout << "Something went wrong with reject list" << "\n";
                   cin >> pause;
                   exit(0);
              }
              // start do loop
              do
              {
                   // read reject list
                   c1myfile2 >> rejectlist;
                   // set test to 0
                   test = 0;
                   // perform test
                   if (rejectlist == outputfile)
                   {
                        test = 1;
                   }
                   // test = 1 file format = format on reject list
                   if (test == 1)
                   {
                        // if test = 1 delete file
                        remove(filelist.c_str()); 
                        // if test = 1 break do loop
                        break;
                   // end if test == 1
                   }
             // end do loop at eof of reject list
              } while(!c1myfile2.eof());
             // close reject list
              c1myfile2.close();
              c1myfile2.clear();
              c1myfile2.flush();
         } // end if eof c1myfile1.eof() 
    } while(!c1myfile1.eof());
    // close file list.txt
    c1myfile1.close();
    c1myfile1.clear();
    c1myfile1.flush();
    exit(0);    
}
