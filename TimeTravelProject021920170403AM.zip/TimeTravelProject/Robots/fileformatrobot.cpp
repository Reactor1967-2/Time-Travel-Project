// ===========================================================================================
// declare includes
#include <cstdlib>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <string>
#include <cmath>
#include <ctime>
#include <cstdio>
#include <iostream>
#include <stdio.h>
// ===========================================================================================
// declare name space
using namespace std;
// declare subs
//============================================================================================
int main (int argc, char *argv[])
{
    // declare variables
    string dummy1;
    string dummy2;
    string pause;
    // Get file format list
    system("file * > list.txt");
    fstream c1myfile1;
//    fstream c1myfile2;


    // open file format list
    c1myfile1.open("list.txt", ios::in);
    if (!c1myfile1)
    {
         cout << "Something went wrong" << "\n";
         exit(0);
    }

    do
    {
         if (!c1myfile1.eof())
         {
              getline (c1myfile1,dummy1, ':');
              getline (c1myfile1,dummy2);
              size_t found = dummy2.find("data");
              if (found < 100)
              { 
                   if (dummy2.size() < 20)
                   {
                        if( remove( dummy1.c_str() ) != 0 )
                        perror( "Error deleting file" );
                        else
                        puts( "File successfully deleted" );
                   }
              }
         }
    } while(!c1myfile1.eof());

    // close list.txt
    c1myfile1.close();
    c1myfile1.clear();
    c1myfile1.flush();
    exit(0);
    
}
