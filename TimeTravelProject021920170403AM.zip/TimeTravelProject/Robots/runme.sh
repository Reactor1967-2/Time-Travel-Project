#!/bin/bash

g++ airobot.cpp -o airobot
g++ fileformatrobot.cpp -o fileformatrobot
g++ fileformatrobot2.cpp -o fileformatrobot2
