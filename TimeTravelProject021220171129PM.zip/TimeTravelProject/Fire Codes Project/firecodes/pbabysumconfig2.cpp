// this is a dependcy for fire codes
// COPYRIGHT(C) 2016 http://time-travel.institute
// g++ pbabysumconfig2.cpp -0 pbabysumconfig2
#include <cstdlib>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <string> 
#include <cmath>
#include <ctime>
#include <cstdio>
#include <iostream>
// #include <stdio.h>
#include </home/reactor1967/mersennetwister.h> // This is a dependancy.

using namespace std;


// Start main
int main (int argc, char *argv[])
{

     // declare variables
     string pause;
     long long count1 = 0;
     long long count2 = 0;
     long long count3 = 0;
     int buffersize = 1;
     MTRand mtrand1a( 5654940 );
     long double babysum = 0;  
     unsigned char buffer;
     long double adultsum = 0;
     long long begin1;
     long double x1 = 0;
     ofstream c1myfile;
     int byte1 = 0;
     int byte2 = 0;
     int byte3 = 0;
     int byte4 = 0;
     long double destinationbabysum;
     long long weaksum = 0;
     long long filesize2 = 0;
     string file1;
     long long filesize1;
     long long howmanyweightedsums;
     string file2;
     long long password2;

// ======================================================================= get arguments
// int babysumconfig2(string file1, long long filesize1, long long howmanyweightedsums, long long password2) <<<<<<<<<<<<<<<<<<< arguments in order to run this.

    // passing command line arguments to program 
    file1 = argv[1];

// passing command line arguments to program 
    filesize1 = strtoull(argv[2],NULL,10);

    // passing command line arguments to program
    howmanyweightedsums = strtoull(argv[3],NULL,10);

    // PASSWORD FOR CALCULATING WEIGHTED SUMS
    password2 = strtoull(argv[4],NULL,10);

   // set file2
   file2 = file1 + ".config";   

// ======================================================================= end get arguments


     // open file1 of computer file to reconstruct
     fstream myfile1(file1.c_str(), ios:: in | ios:: binary);
     if (!myfile1)
     {
          cout << "Error in line 314 view file.\n";
          cin >> pause;
          myfile1.close();
          myfile1.clear();
          myfile1.flush();
          exit(1); // terminate with error
     }

     // open file2 config file for append     
     c1myfile.open(file2.c_str(),ios::app); 
     if (!c1myfile)
     {
          cout << "Unable to open file line 77\n";
          cin >> pause;
          // close configure file
          c1myfile.close();
          c1myfile.clear();
          c1myfile.flush();
          exit(1); // terminate with error
     }

     // count1 = 0;
     count1 = -1;
 
     // start main loop 
     do
     {   
          // babysum = 0;
          babysum = 0;
          // set seed for random number generator
          // get seed
          mtrand1a.seed(password2);

          // Set bytes and carry to zero
          byte1 = 0; byte2 = 0; byte3 = 0; byte4 = 0;

          // set destinationbabysum to 0
          destinationbabysum = 0;
  
          // set weaksum to 0
          weaksum = 0;

          // set weaksum to 0
          filesize2 = 0;

          // read byte1
          // count1++;
          count1++; // for file position
          myfile1.seekg(count1);
          myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellg();
          byte1 = (int)buffer;
          filesize2++;
          weaksum = weaksum + byte1;
          if (count1 == filesize1 - 1) // for when we have a partial counter
          {
               goto Jump1;
          }


          // read byte2
          // count1++;
          count1++; // for file position
          myfile1.seekg(count1);
          myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellg();
          byte2 = (int)buffer;
          filesize2++;
          weaksum = weaksum + byte2;
          if (count1 == filesize1 - 1) // for when we have a partial counter
          {
               goto Jump1;
          }

          // read byte3
          // count1++;
          count1++; // for file position
          myfile1.seekg(count1);
          myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellg();
          byte3 = (int)buffer;
          filesize2++;
          weaksum = weaksum + byte3;
          if (count1 == filesize1 - 1) // for when we have a partial counter
          {
               goto Jump1;
          }

          // read byte4
          // count1++;
          count1++; // for file position
          myfile1.seekg(count1);
          myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellg();
          byte4 = (int)buffer;
          filesize2++;
          weaksum = weaksum + byte4;
          if (count1 == filesize1 - 1) // for when we have a partial counter
          {
               goto Jump1;
          }

          

          // Set random number seed.
          mtrand1a.seed(password2);

Jump1:
          // I did not use filesize 2 here because any byte times 0 is a 0.
          // compute baby sum for 4 bytes then exit
          count2 = 0;
          do // computing Strong check sum for byte 1 for howmanychecksums
          {
               count2++;
	       x1 = mtrand1a.randExc(.9999999);
               destinationbabysum = destinationbabysum + (byte1 * x1);
          } while(count2 < howmanyweightedsums);

          count2 = 0;
          do // computing Strong check sum for byte 1 for howmanychecksums
          {
               count2++;
	       x1 = mtrand1a.randExc(.9999999);
               destinationbabysum = destinationbabysum + (byte2 * x1);
          } while(count2 < howmanyweightedsums);

          count2 = 0;
          do // computing Strong check sum for byte 1 for howmanychecksums
          {
               count2++;
	       x1 = mtrand1a.randExc(.9999999);
               destinationbabysum = destinationbabysum + (byte3 * x1);
          } while(count2 < howmanyweightedsums);

          count2 = 0;
          do // computing Strong check sum for byte 1 for howmanychecksums
          {
               count2++;
               x1 = mtrand1a.randExc(.9999999);
               destinationbabysum = destinationbabysum + (byte4 * x1);
          } while(count2 < howmanyweightedsums);
               
          // append baby strong check sum to config file
          c1myfile.precision(36);
          c1myfile << " Strong checksum " << destinationbabysum << " Weak checksum " << weaksum << " file size " << filesize2 << "\n";

          // repeat main loop while babycounters > 1
     } while(count1 < filesize1 - 1);

     // close main file
     myfile1.close();
     myfile1.clear();
     myfile1.flush();

     // close configure file
     c1myfile.close();
     c1myfile.clear();
     c1myfile.flush();
     remove (file1.c_str());
     exit(0);
} // end main


