// This creates a destination file for the weak check-sum counter
// It takes a buffer size, max file size, and a counter speed then creates the file
// Copyright (C) 2017 http://time-travel.institute 
// To run program
// ./weakcheck-sumfilecreator buffersize counterspeed maxfilesize configfile
// ============================================================================================
 // declare includes
    #include <cstdlib>
    #include <iostream>
    #include <stdlib.h>
    #include <fstream>
    #include <sstream>
    #include <string> 
    #include <cmath>
    #include <ctime>
    #include <cstdio>
    #include <iostream>
    #include "weakchecksum.h"
// ============================================================================================
    // Declare namespace
    using namespace std;
// ============================================================================================     
// declare globals 
//    long double targetstrongchecksum;
//    long long filesize1;
//    long long howmanyweightedsums;
//    int buffersize;
//    long long weakchecksum;

// ============================================================================================
// declare subs
// ============================================================================================
int createchecksum(string file1, long long cksum, long long filesize1, int buffersize, int base)
{
     long long count1 = 0;
     long long count2 = 0;
     long long checksum = cksum;
     unsigned char buffer(buffersize);
     long long begin1 = 0;
     string pause;

// open file
// open file1
     fstream myfile1(file1.c_str(), ios::out  | ios::binary);
     if (!myfile1)
     {
          myfile1.close();
          cout << "Failed to read file one.\n";
          cin >> pause;
          exit(1);
     }

     // write to file while subtracting from checksum use loops

     int byte1 = base - 1;
     count1 = 0;
     do
     {
          if (checksum - byte1 > 0)
          {
               checksum = checksum - byte1;
               goto ln667;
          }

          if (checksum - byte1 <= 0)
          {
              byte1 = checksum;
              checksum = 0;

          }
ln667:
          buffer = (unsigned char)byte1;
          myfile1.seekp(count1);
          myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellp();

          if (checksum == 0)
          {
               byte1 = 0;
          }

          count1 = count1 + buffersize;

     } while(checksum > 0);
     myfile1.close();
     myfile1.clear();
     myfile1.flush();
     return(0);
}
// ============================================================================================
int createdestinationfile(string file1, int buffersize, int counterspeed)
{
    long long numberbase;
    long long pbnum2;
    long long pbnum3; 
    long long count1;
    long long carry;
    string pause;
    int dummyfile;
    string whatdo;

    fstream myfile1(file1.c_str(), ios::out  | ios::binary);
    if (!myfile1)
    {
         myfile1.close();
         cout << "error in line 245" << " " << file1 << "\n";
         cin >> pause;
         exit(1);
    }
    myfile1.close();
    myfile1.clear();
    myfile1.flush();

    numberbase = (buffersize * 255) + 1;
    pbnum2 = (numberbase - 1) * counterspeed;
    count1 = buffersize * -1;
    do
    {         
         count1 = count1 + buffersize;
         pbnum3 = (pbnum2 - (int(pbnum2/numberbase)*numberbase));
         pbnum2 = int(pbnum2/numberbase);
         //write pbnum3 to binary file
         whatdo = "write";
         dummyfile = binaryreadwrite(whatdo, file1, count1, pbnum3, buffersize);

         if(pbnum2 < numberbase)
         {
              // increment file pointer
              pbnum3 = pbnum2;
              // write pbnum3 to binary file
              whatdo = "write";
              dummyfile = binaryreadwrite(whatdo, file1, count1, pbnum3, buffersize);
              return(0);
         }

    } while(pbnum2 > numberbase);
    return(0);

}
// ============================================================================================
int loadconfig(string file1)
{ // I may not need this but leaving it in any way.
//    string dummy;
   

// Load configure file
//    fstream c1myfile(file1.c_str(), ios::in);
//    c1myfile >>  dummy >> dummy >> dummy >> file1;
    // set precision
//    c1myfile.precision(36);
    // strong check sum
//    c1myfile >>  dummy >> dummy >> dummy >> targetstrongchecksum;
    // write file size
//    c1myfile >>  dummy >> dummy >> dummy >> filesize1;
    // write how many weights
//    c1myfile >>  dummy >> dummy >> dummy >> dummy >> howmanyweightedsums;
    // write buffersize
//    c1myfile >>  dummy >> dummy >> buffersize;
    // write weak check-sum 
//    c1myfile >>  dummy << dummy >> weakchecksum;
    // close configure file
//    c1myfile.close();
//    c1myfile.clear();
//    c1myfile.flush();
//    return(0);
}
// ============================================================================================
string add(long long count3, int buffersize, string destinationfile, string differencefile, string extension)
{
         
        long long filesize2;
        long long filesize3;
        long long filesize4;
        long long count2;
        long long carry;
        int byte;
        int byte1;
        int byte2;
        int byte3;
        long long numberbase = (buffersize * 255) + 1;
        string pause;
        string whatdo;
        string file1;
        int dummyfile;

        // get filesie 2
        filesize2 = filesize(differencefile);

        // get filesize 3
        filesize3 = filesize(destinationfile);

        if (filesize2 > filesize3)
        {
              filesize4 = filesize2;
        }

        if (filesize3 > filesize2)       
        {
              filesize4 = filesize3;
        }  
 
        // get file name  from ss
         stringstream ss;
         file1 = "";
         ss << count3;
         ss >> file1;
         file1 = file1 + extension;

         fstream myfile1(file1.c_str(), ios::out  | ios::binary);
         if (!myfile1)
         {
              myfile1.close();
              cout << "error in line 245" << " " << file1 << "\n";
              cin >> pause;
              exit(1);
         }
         myfile1.close();
         myfile1.clear();
         myfile1.flush();

         carry = 0;
         count2 = buffersize * -1;
         // start third loop
         do
         {
              // increment file variable
              count2 = count2 + buffersize;

              // set byte1 to zero
              byte1 = 0;

              // read byte1 if less than filesize
              whatdo = "read";

              if (count2 < filesize3 - 1)
              { 
                   byte1 = binaryreadwrite(whatdo, destinationfile, count2, byte, buffersize);
              }

              // // set byte2 to 0
              byte2 = 0;

              // read byte2 if less than filesize
              if (count2 < filesize2 - 1) 
              {
                   byte2 = binaryreadwrite(whatdo, differencefile, count2, byte, buffersize);
              }

              // byte3 = byte1 - byte2 - carry;
              byte3 = byte1 + byte2 + carry;

              // carry = 0;
              carry = 0;

              // if byte < 0 subtract from the base
              if (byte3  > numberbase - 1)
              {
                   byte3 = byte3 - numberbase;
                   carry = 1;
              }

              // Check for error
              if (byte3 > (numberbase - 1))
              {
                   cout << "Houston we have a problem\n";
                   cout << "byte3 greater than the base - 1\n";
                   cin >> pause;
                   exit(0);
              }

              if (byte3 < 0)
              {
                   cout << "Houston we have a problem\n";
                   cout << "byte3 less than 0\n";
                   cin >> pause;
                   exit(0);
              }

             // write random binary
              whatdo = "write";
              dummyfile = binaryreadwrite(whatdo, file1, count2, byte3, buffersize);


         // end third loop
         } while(count2 < filesize4 - 1); 
         return(file1);

}
// =============================================================================================
// declare main
int main (int argc, char *argv[])
{ 
    // declare variables
    string file1 = "checksum.bin";
    string file2 = "speed.bin";
    string file3;     
    int buffersize;
    long long weakchecksum;
    long long counterspeed;
    long long howmanyfiles;
    long long count3;
    int dummyfile;
    long long numberbase;
    int test1;
    int test2;
    long long filesize1;
    string pause;
    string extension;

    // get command line arguments
    extension = argv[1];
    buffersize = atoi( argv[2]); // How many bytes we are reading at a time. 
    weakchecksum = strtoull(argv[3],NULL,10); // This is how many files we are building to day.
    counterspeed = strtoull(argv[4],NULL,10); // How many weak check-sums to skip at a time. This is the counter speed
    howmanyfiles = strtoull(argv[5],NULL,10); // How many target files to generate
    test1 = atoi(argv[6]); // if 0 user supplies destination file. If 1 program creates destination file.
    test2 = atoi(argv[7]); // if 0 user supplies check-sum file. If 1 program creates check-sum file.
    numberbase = (buffersize * 255) + 1;

//cout << extension << "\n";
//cout << buffersize << "\n";
//cout << weakchecksum << "\n";
//cout << counterspeed << "\n";
//cout << howmanyfiles << "\n";
//cout << test1 << "\n";
//cout << test2 << "\n";
//cout << numberbase << "\n";

    // Write the smallest file possible with the weak check-sum
    if (test2 == 1)
    {
         dummyfile = createchecksum(file1, weakchecksum, filesize1, buffersize, numberbase);
    }

    if (test1 == 1)
    { 
         dummyfile = createdestinationfile(file2, buffersize, counterspeed); // This converts ((numberbase - 1) * counterspeed) to base 256 binary file
    }

    count3 = 0; // holds target file names
    do
    {
         // increment count3
         count3++;

         // add the (base - 1) * counterspeed to the file which is destination file + difference file.
         file3 = add(count3, buffersize, file1, file2, extension);
         // make difference file target file for next tartget
//         rename(file3.c_str(), "checksum.bin");
         file1 = file3; 
    } while(count3 < howmanyfiles);
}
