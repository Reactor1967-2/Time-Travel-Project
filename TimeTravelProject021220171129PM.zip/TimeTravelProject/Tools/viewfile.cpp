// THIS WILL VIEW THE BINARY IN A COMPUTER FILE AS 1 BYTE IN BASE 10
// COPYRIGHT(C) 2016 http://time-travel.institute
     #include <cstdlib>
     #include <iostream>
     #include <stdlib.h>
     #include <fstream>
     #include <sstream>
     #include <string> 
     #include <cmath>
     #include <ctime>
     #include <cstdio>
     #include <iostream>
// ============================================================================================
    // Declare namespace
    using namespace std;
// ============================================================================================  
int main()
{
// declare variables
         int count = -1;
	 int byte1 = 0;
         long long begin1 = 0;
	 string pause;
         string file1;
         long long  filesize1;
         int buffersize;
         unsigned char buffer(buffersize);
	
         cout << "Please enter the name of your file." << "\n";
         cin >> file1;

         cout << "please enter the size of the file in bytes." << "\n";
         cin >> filesize1;

         cout << "please enter the buffer size." << "\n";
         cin >> buffersize;

// open file 1
     fstream myfile1(file1.c_str(), ios:: in | ios:: binary);
     if (!myfile1)
     {
          cout << "Error in line 314 view file.\n";
          cin >> pause;
          myfile1.close();
          myfile1.clear();
          myfile1.flush();
	  exit(1); // terminate with error
     }
// read file view output   
     do
     {
          count++;

         // read file 1
          myfile1.seekg(count);
          myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellg();
          byte1 = (int)buffer;
	  cout << " count " << count << " " << " byte " << byte1 << "\n";

      } while (count < filesize1 - 1);


// close file1
// close file2
      myfile1.close();
      myfile1.clear();
      myfile1.flush();

      exit(0);
}

// ============================================================================================================

