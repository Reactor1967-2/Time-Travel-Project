// This program generates a weight file for use with calculating strong check-sums
// Copyright (C) 2016 http://time-travel.institute
// NOTE TO PROGRAMMER - LATER SET THIS UP TO RUN WITH COMMAND LINE PARAMETERS.
// ============================================================================================
 // declare includes
     #include <cstdlib>
     #include <iostream>
     #include <stdlib.h>
     #include <fstream>
     #include <sstream>
     #include <string> 
     #include <cmath>
     #include <ctime>
     #include <cstdio>
     #include <iostream>
// ============================================================================================
    // Declare namespace
    using namespace std;
// ============================================================================================     
    // declare globals
// ============================================================================================     
// declare subs
// This is where all the work is done to make the program run.
// ============================================================================================
// declare main
    int main (int argc, char *argv[])
    { 
         // declare variables
         char pause;
//         srand((unsigned int) 5654940);
         srand(time(0));
         time_t seconds;
         long long count1 = 0;
         long long howmanynumbers;
         long long k;
// ============================================================================================
         // Run program
         howmanynumbers = strtoull(argv[1],NULL,10);
// open weight file
         fstream c1myfile2("random.txt", ios::out);
// start main loop
         do
         { 
              // increment count
              count1++;
// generate random weights
              time(&seconds);
              k = (rand() % 999999999);
              k = k + seconds; 
              c1myfile2 << k << "\n";
// repeat for how many weights
         } while(count1 < howmanynumbers);
        // close weaksums.txt
         c1myfile2.close();
         c1myfile2.clear();
         c1myfile2.flush();
// EXIT PROGRAM
         exit(0); 
    }     

