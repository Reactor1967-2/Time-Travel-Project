buildbasepower2 is a upgrade to buildbasepower

This directory is the varies tools that can be used to compile and run time travel project. Some programs overlap in
functionality so you will find the same header files and code through out time travel project.

Some of the code here still needs some work but everything here should compile
