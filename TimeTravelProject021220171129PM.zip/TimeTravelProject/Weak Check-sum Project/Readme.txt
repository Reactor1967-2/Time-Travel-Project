Use the weak check-sum file generator to generate a file at a specific file size with a specific weak check-sum.
Then use the weak check-sum counter to create time travel media files from the same weak check-sum.
Use the robot to delete the bad files and leave the good files
