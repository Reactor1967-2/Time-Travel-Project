//-----------------------------------------------------------   Program Plan   ------------------------------------------------------------------------    
      // Declare variables
      
     // open neural net master file and load variables

     // ask user if reading from file or keyboard. - Note this part here for the initial program that loads the ann with input.
     // ask user if output text or binary. We use this to choose if we print to screen or not all output is written to a output file.
     
     // This part on down is for both drone.cpp and runann.cpp

     // if x = 0
          // read from file loop
               // get input from file
               // write input to input nodes
          // end read from file loop
     // end if x = 0
     
     // if x = 1
          // read input loop
                // get input from user
               // write input to input nodes
          // end input loop
     // end if x = 1

     // start node loop
          
          // read node master file and load variables
          
          // IMPORTANTE NOTES ABOUT RUNNING IN PARALLEL.
          // Open node input file. First test it to see if it has input. Second test it to see if all inputs there.
          // If does not have input pause for a while then try again. This is for running in parallel. 
          // Also if running in parallel WILL HAVE TO TAKE OUT GETTING INPUT AND COPY THAT TO RUNDRONE.CPP. This part on down is for both drone and processing input.

          // Note - Arrays start from 0 to how many inputs there are. But we start at lowest previous node to highest with variable.
          // Note - So using the previousnode variable, and count, and inputs variable we numerically count and keep with with the previous node, its output, and weight.
          // set size of array and keep maxarray variable. MAKE SURE THIS WORKS WITH INPUT NODES.
          // dim array for inputs search it by previous node as search key
          // dim array for weights search it by prevous node as search key
          // dim array for diff. This is the difference between the current input and the data base input. Used to select weights from data base.
          // dim rmscount. This is how many inputs with different weights we have.
          // dim rmssum. This is the sum of the weights.
          
          // open input node file
          // start input loop
               // read input file
               // first variable load min prev node
               // load input array
               // last variable load max for previous variable
               // Set diff array to 99999999999999 for all positions in array.
               // Set weight array to 0 for all positions in array
               // end input loop
          // close input node file.          

          // open data base file
               // read previous node, input, weight
               // if read input same as previous read inputs but different weights it root means squares the weights and update weight array              
               // update input diff array while reading inputs use if statement
               // update weight array as needed based on diff 
          // end open data base file loop 

          // We will use another program call thresholds ann to update the thresholds file.
          // if using thresholds <<<<<<<<<<<<<<<<< FINISH THIS LATER AFTER PROGRAM IS WORKING and we have thresholdsann written.
               // compare weighted sum to threshold file. 
               // if in range do nothing.
               // if out of range set weighted sum to 0
          // end if using thresholds

          // Start write output loop from arrays
               // compute weighted sum from input and weight arrays    
          // end write output loop
          
          // open output file
          // Write output to output file.
                                
          // clear arrays
          // flush arrays
          // delete arrays
          
          // begin if node type not output
               // write output to inputs
                    // read output master file
                    // write output to other nodes input
               // end write loop
         // end if node type not output
              
     // end node loop

     // Read output nodes
          // print output on screen IF TEXT IF BINARY WRITE IT TO BINARY FILE.
     // end read loop
     
     
// PROGRAMERS NOTE - THE MASTER FILE HAS HOW MANY INPUTS AND OUTPUTS. NEVER WILL A ZERO BE USED IN IT UNLESS THERE IS NO OUTPUT OR INPUT AT ALL.
//                   THE MASTER INPUT FILE HAS HOW MANY INPUTS. ONLY ZERO WILL BE USED IN INPUT NODE IF IT IS USER INPUT. 0 MEANS USER INPUT.
//                   THE MASTER OUTPUT FILE HAS HOW MANY OUTPUTS. ONLY ZERO WILL BE USED IN OUTPUT INSTEAD OF ANOTHER NODE IF OUTPUT IS USER OUTPUT.
//                   0 IN MASTER OUTPUT MEANS THE OUTPUT IS FOR THE USER.
//                   THERE WAS SOME PROGRAMMING CONFUSION WITH THE 0 WHICH CAUSED ERRORS IS WHY THIS NOTE IS HERE.
//                   THIS PROGRAM READS THESE FILES SO IT CAN WRITE TO OTHER FILES. 0 PREVENTS OTHER FILES FROM GETTING WROTE TOO SO 
//                   THE PROGRAMER HAS TO BE ABLE TO WRITE CODE TO CLEAR THIS ISSUE UP.     

// ----------------------------------------------------------------------------------------
//                                  Computer Program itself.

#include <cstdlib>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <string>
#include <cmath>
#include <d:\Projects\AI project\aiproject\mersenne\mersennetwister.h> 
#include <stdio.h>


using namespace std;

int main (int argc, char *argv[])

{
//                       Program

// Declare variables

     long double layers = 0; // counts layers as they are created
     long double maxlayers = 0; // holds max number of layers for neural net
     long double nodes = 0; // counts nodes in each layer
     long double countnodes = 0; // Used with ss to name files.
     long double inputs = 0; // number of input nodes This is a constant dont mess with it.
     long double maxnodes = 0; // how many nodes per layer
     long double endingnode = 0; // ending node in output / input files.
     long double startingnode = 0; // starting node in output / input files.
     long double readinput = 0; // A variable to read input to nodes from files. Not a constant use it.
     long double readoutput = 0; // A variable to read output to nodes from files. Not a constant use it
     long double nodeinputs = 0; // How many inputs a node has
     long double nodeoutputs = 0; // How many outputs a node has
     long double node = 0; // Used to read log files to tell what information comes or goes to what nodes. Not a constant use it.
     long double distributedsum = 0; // Hold output divided by input.
     long double weight = 0; // Holds weights of inputs for computing weighted sum.
     long double weightedsum = 0; // Holds weighted sum of inputs from node nput file.
     long double inputweightedsum = 0;
     long double diff = 0; // Used to compare difference between weighted sum inputs
     long double diff2 = 0;

     long long totalnodes = 0; // How many nodes in the net
     long long outputs = 0; // number of output nodes This is a constant dont mess with it.
     long long count = 0; // generic count can be used anywhere that visa or mastercard is accepted. (Joke)
     long long begin = 0; // Used to get size of file
     long long end = 0; // Used to get size of file
     long long size = 0;
     long long minprev = 0; // Holds the smallest previous node from the node input file.
     long long maxprev = 0; // holds the largest previous node from the node input file.
     long long countnodes1 = 0; // used specifically in one area of program.
     long long countnodes2 = 0; // used specifically in one area of program.
     long long previousnode = 0;

     string networktype = ""; // Holds the type of neural network we are working with. // Make this change in train and create ann too.
     string nodetype = ""; // Holds input, worker, or output nodetype
     string mext = ".masterfile"; // extension to denote master file.
     string miext = ".inputmasterfile";
     string moext = ".outputmasterfile";
     string iext = ".input"; // extension to denote input file.
     string oext = ".output"; // extension to denote output file.
     string wext = ".weight"; // extension to denote weight file
     string dext = ".database"; // extension to denote data base file.
     string text = ".threshold"; // extension to denote threshold file.
     string formatoutput = "";
     string file0 = "";
     string file1 = "";
     string file2 = "";
     string file3 = "";
     string file4 = "";
     string file5 = "";
     string file6 = "";
     string file7 = "";
     string file8 = "";
     string file9 = "";
     string file10 = "";
     string file11 = "";
     string file12 = "";
     
     fstream myfile0;
     fstream myfile1;
     fstream myfile2;
     fstream myfile3;
     fstream myfile4;
     fstream myfile5;
     fstream myfile6;
     fstream myfile7;
     fstream myfile8;
     fstream myfile9;
     fstream myfile10;
     fstream myfile11;
     fstream myfile12;
               
     int x = 0; // dummy variable
     std::stringstream ss;    
     
     // open neural net master file and load variables

     file0 = "neuralnet.masterfile";
     myfile0.open(file0.c_str(), ios:: in);
     if (!myfile0)
     {
          myfile0.close();
          cout << "Failed to read file in line 185\n";
          cin >> x;
          exit(1);
     } 
     
     myfile0 >> networktype >>  inputs >> outputs >> totalnodes >> nodes >> maxlayers; 
     myfile0.close();
     myfile0.flush();
     myfile0.clear();
     
     // ask user if reading from file or keyboard.
     cout << "Welcome to artifical intelligence.\n";
     cout << "\n";
     cout << "Get input from file enter 0.\n";
     cout << "\n";
     cout << "Get input from keyboard enter 1.\n";
     cin >> x;
     cout << "Is the output binary or text? (b) (t).\n";
     cin >> formatoutput; // We need to know how to format the output from this net.     
     

// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Tested here

     // if x = 0
     if (x == 0)
     {
          // read from file loop
          file1 = "run.ann";
          myfile1.open(file1.c_str(), ios:: in);
          if (!myfile1)
          {
               myfile1.close();
               cout << "Failed to read file in line 214\n";
               cin >> x;
               exit(1);
          } 
          count = 0;
          inputweightedsum = 0;
          do
          {
               count++;           
        // get input from file
               myfile1 >> readinput;
               inputweightedsum = inputweightedsum + (readinput * (count * .1));
        // write input to input nodes

        // assign name input node
               ss.clear();
               file2 = "";
               ss << count;
               ss >> file2;
               file2 = file2 + iext;
          
          // open input node input file
               myfile2.open(file2.c_str(), ios:: out);
               if (!myfile2)
               {
                    myfile2.close();
                    cout << "Failed to read file in line 239\n";
                    cin >> x;
                    exit(1);
               }           
          
          // write input to input file
               myfile2.precision(37);
               myfile2 << 0 << " " << readinput << "\n";
               
          // close input node file
               myfile2.close();
               myfile2.flush();          
               myfile2.clear();
               
          // repeat for number of inputs
          // end read from file loop
                
           } while (count < inputs);         
     // end if x = 0
     }     

// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< tested up to here. 
 
     // if x = 1
     if (x == 1)
     {
          // read input loop
          count = 0;
          inputweightedsum = 0;
          do
          {
               count++;
               // get input from user
               cout << "Please enter for input number " << count << "\n";
               cin >> readinput;
               inputweightedsum = inputweightedsum + (readinput * (count * .1));
               
               // write input to input nodes
        // assign name input node
               ss.clear();
               file2 = "";
               ss << count;
               ss >> file2;
               file2 = file2 + iext;
          
          // open input node input file
               myfile2.open(file2.c_str(), ios:: out);
               if (!myfile2)
               {
                    myfile2.close();
                    cout << "Failed to read file in line 285\n";
                    cin >> x;
                    exit(1);
               }           
          
          // write input to input file
               myfile2.precision(37);
               myfile2 << 0 << " " << readinput << "\n";
               
          // close input node file
               myfile2.close();
               myfile2.flush();          
               myfile2.clear();

          
          // end input loop
          } while (count < inputs);
     
     // end if x = 1
     }

// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Tested to here.

// This part on down is for both drone.cpp and runann.cpp.

     // start node loop
     countnodes = 0;
     do
     {
          countnodes++;
          
                               
          // read node master file and load variables
          // assign name to node being worked on
          ss.clear();
          file2 = "";
          ss << countnodes;
          ss >> file2;
          file2 = file2 + mext;

          // Load master 1 file and read how many inputs and outputs and assign those to variables
          myfile2.open(file2.c_str(), ios:: in); 
          if (!myfile2)
          {
               myfile2.close();
               cout << "Failed to read file in line 326\n";
               cin >> x;
               exit(1);
          }           

          // read node master file.
          myfile2 >> nodetype >> nodeinputs >> nodeoutputs;
          
          // close node master file.
          myfile2.close();
          myfile2.flush();          
          myfile2.clear();

        // IMPORTANTE NOTES ABOUT RUNNING IN PARALLEL.
        // Open node input file. First test it to see if it has input. Second test it to see if all inputs there.
        // If does not have input pause for a while then try again. This is for running in parallel. 
        // Also if running in parallel WILL HAVE TO TAKE OUT GETTING INPUT AND COPY THAT TO RUNDRONE.CPP. This part on down is for both drone and processing input.
        
tryagain1:

          ss.clear();
          file4 = "";
          ss << countnodes;
          ss >> file4;
          file4 = file4 + iext;

          // open node input file
          myfile4.open(file4.c_str(), ios::in);
          if (!myfile4)
          {
               myfile4.close();
               cout << "Failed to read file in line 361\n";
               cin >> x;
               exit(1);
          }           
         
 // Get size of input file  
          begin = myfile4.tellg();
          myfile4.seekg(0, ios::end);
          end = myfile4.tellg();
          size = end-begin;
         
          myfile4.close();
          myfile4.flush();
          myfile4.clear();

          if (size == 0)
          {

               cout << "We are at node number " << countnodes << "\n";
               cout << "Shit the size of the file was fucking zero man." << "\n";
               cout << "Oh no, not all the inputs are here. Repeating\n";
               count = 0;
               do
               {
                    count++;
               } while (count < 1000000000);
               goto tryagain1;
          }           

// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< tested to here.

          ss.clear();
          file4 = "";
          ss << countnodes;
          ss >> file4;
          file4 = file4 + iext;

          // open node input file
          myfile4.open(file4.c_str(), ios::in);
          if (!myfile4)
          {
               myfile4.close();
               cout << "Failed to read file in line 413\n";
               cin >> x;
               exit(1);
          }           

          // Note - Arrays start from 0 to how many inputs there are. But we start at lowest previous node to highest with variable.
          // Note - So using the previousnode variable, and count, and inputs variable we numerically count and keep with with the previous node, its output, and weight.
          // set size of array and keep maxarray variable. MAKE SURE THIS WORKS WITH INPUT NODES.
          // dim array for inputs search it by previous node as search key

          size = (long long) nodeinputs;
          long double inputarray[size]; 
          // dim array for weights search it by prevous node as search key
          long double weightarray[size];
          // dim array for diff. This is the difference between the current input and the data base input. Used to select weights from data base.
          long double diffarray[size]; // for difference in inputs
          long double diffarray2[size]; // for difference in weighted sum of inputs
          long double weightedsumofinputs[size];
          // start input loop
          weightedsum = 0;         
          count = -1;
          do
          {

               count++;

               // read input file.
               myfile4 >> previousnode >> readinput;

               if (!myfile4)
               {

                    cout << "We are at node number " << countnodes << "\n";
                    cout << "Shit we ran out of information.\n";
                    cout << "Oh no, not all the inputs are here. Repeating\n";
                    myfile4.close();
                    myfile4.flush();
                    myfile4.clear();
//                    delete [] inputarray;
//                    delete [] weightarray;
//                    delete [] diffarray;
//                    delete [] weightedsumofinputs;

                    count = 0; // this stuff needs deleted later.
                    do
                    {
                         count++;
                    } while (count < 1000000000);
                    count = -1;
                    goto tryagain1;
                                      
               }           
               
               // first variable load min prev node
               if (count == 0)
               {
                    minprev = previousnode;
                               
               }          

               // load input array
               inputarray[count] = readinput;

               // last variable load max for previous variable
               maxprev = minprev + count;
               
               // Set diff array to 999999999 for all positions in array.
               diffarray[count] = 999999999;
               diffarray2[count] = 999999999;
               
               // Set weight array to 0 for all positions in array
               weightarray[count] = 0;
               
               // set weighted sum of inputs array to 0 for all positions in array
               weightedsumofinputs[count] = inputweightedsum;                
               
          // end input loop
          } while(count < nodeinputs - 1);
          
          // close input node file.          
          myfile4.close();
          myfile4.flush();
          myfile4.clear();

//        load weighted sum of inputs to array for difference comparersion <<<<<<<<<<  NOTE PUT THIS IN PROGRAM PLAN UP ABOVE.


// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Tested to here.

          // open data base file 
          ss.clear();
          file6 = "";
          ss << countnodes;
          ss >> file6;
          file6 = file6 + dext;
          
          // open output node input file
          myfile6.open(file6.c_str(), ios:: in);
          if (!myfile6)
          {
               myfile6.close();
               cout << "Failed to read file in line 469\n";
               cin >> x;
               exit(1);
          }          
          
          // begin loop open data base file 
          do
          {
               // read previous node, input, weight
               myfile6 >> previousnode >> readinput >> weight >> weightedsum; 
               
               // update input diff array while reading inputs use if statement
               // update weight array as needed based on diff
               // if read input same weight sum it weights and update weight array !!!!!!!!!!!!!!

               count = -1;
               do
               {
                    count++;
                    if (count + minprev == previousnode)
                    {
                                               
                         if (previousnode >= minprev)
                         {
                    
                              if (previousnode <= maxprev) 
                              {
                                   diff = abs(readinput - inputarray[count]);
                                   diff2 = abs(weightedsum - weightedsumofinputs[count]);

                                   if (diff == diffarray[count])
                                   {
                                        if (diff2 < diffarray2[count])
                                        {
                                             weightarray[count] = weight;
                                        }                                                                    
                                   }
                                   
                                   if (diff < diffarray[count])
                                   {
                                        diffarray[count] = diff;
                                        diffarray2[count] = diff2;
                                        weightarray[count] = weight;
                                   }         
                                   
                              }
                    
                         }
                    
                    }                                  
               
               } while (count < nodeinputs - 1); 
               
          // end loop open data base file loop 
          } while (!myfile6.eof());
           
          // close data base file
           myfile6.close();
           myfile6.flush();
           myfile6.clear();

          // if using thresholds <<<<<<<<<<<<<<<<< FINISH THIS LATER AFTER PROGRAM IS WORKING.
               // compare weighted sum to threshold file. 
               // if in range do nothing.
               // if out of range set weighted sum to 0
          // end if using thresholds
          
           // write weight to weight file when computing weighted sum.
           ss.clear();
           file5 = "";
           ss << countnodes;
           ss >> file5;
           file5 = file5 + wext;
          
           // open weight file
           myfile5.open(file5.c_str(), ios:: out | ios:: app);
           if (!myfile5)
           {
                myfile5.close();
                cout << "Failed to read file in line 366\n";
                cin >> x;
                exit(1);
           }           
          
          // Start write output loop from arrays computing weighted sum. <<<<<<<<<<<<<<<<<<<<<<<<<<<<<< OPEN WEIGHT FILE AND RECORD PREVNODE AND WEIGHT
          count = -1;
          weightedsum = 0;
          do
          {
               count++;

               // compute weighted sum from input and weight arrays 
               weightedsum = weightedsum + (inputarray[count] * weightarray[count]);  

               myfile5.precision(37);  
               myfile5 << minprev + count << " " << weightarray[count] << "\n";          

          // end write output loop
          } while (count < nodeinputs - 1);

          // close weight node file
          myfile5.close();  
          myfile5.flush(); 
          myfile5.clear();                           
          
          
          // assign name output node
          ss.clear();
          file2 = "";
          ss << countnodes;
          ss >> file2;
          file2 = file2 + oext;
          
          // open output node input file
          myfile2.open(file2.c_str(), ios:: out);
          if (!myfile2)
          {
               myfile2.close();
               cout << "Failed to read file in line 550\n";
               cin >> x;
               exit(1);
          }           
          
          // write output to output file
          myfile2.precision(37);
          myfile2 << weightedsum << "\n"; // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<  THIS IS WHERE WE WRITE OUR OUTPUT FOLKS.

          
          // close output node file
          myfile2.close();
          myfile2.flush();          
          myfile2.clear();          

//          delete arrays
//          delete [] inputarray;
//          delete [] weightarray;
//          delete [] diffarray;
//          delete [] weightedsumofinputs;
                     
          ss.clear(); // This is the master output file for current node. we are opeing it to read in data
          file9 = "";
          ss << countnodes;
          ss >> file9;
          file9 = file9 + moext;             
 
          myfile9.open(file9.c_str(), ios:: in);
          if (!myfile9)
          {
               myfile9.close();
               cout << "Failed to read file in line 581\n";
               cin >> x;
               exit(1);
          }

          countnodes1 = 0;
          do // The nodes numerical output is copied to the other nodes inputs.
          {                   
               countnodes1++;
                    // Put read statement here
               myfile9 >> node;
                        
               if (node != 0) // We use 0 to say we dont have anything when it comes to ndoes.
               {
                    ss.clear(); // This is the input files for the next nodes. We need a doo loop here
                    file10 = "";
                    ss << node; // Change this to be the files that we write the output to the inputs
                    ss >> file10;
                    file10 = file10 + iext;             

                    myfile10.open(file10.c_str(), ios:: out | ios:: app);
                    if (!myfile10)
                    {
                         myfile10.close();
                         cout << "Failed to read file in line 663\n";
                         cin >> x;
                         exit(1);
                    }

                    myfile10.precision(37);         
                    myfile10 << countnodes << " " << weightedsum << "\n";
                    myfile10.close();
                    myfile10.flush();
                    myfile10.clear();

               }

          } while (countnodes1 < nodeoutputs); // PROBLEM SPOT ATTEMPTING CORRECTION HERE <<<<<<<<< Lloyd what it here has been fucking up.
          myfile9.close();
          myfile9.flush();
          myfile9.clear();                   

     // end node loop
     } while(countnodes < totalnodes);

// NOTE - ALSO HAVE THIS SECTION WRITE BINARY OUTPUT TO BINARY OUTPUT FILE. WE WRITE TO SCREEN IF THE OUTUT IS TEXT ONLY.
// IN BINARY MODE WE SUPRESS OUTPUT TO SCREEN BUT IF IT IS A TEXT FILE YOU CAN OPEN IT AND READ IT.
// IF TEXT RENAME .BIN TO .TXT OR WHAT EVER FILE FORMAT YOU ARE USING. 

    // READ OUTPUT FROM OUTPUT NODES AND PRINT TO SCREEN if text and out to file if binary.
    if (formatoutput == "b")
    {
         ss.clear();
         file12 = "";
         file12 = "netoutput.bin";
          
         // open output node input file
         myfile12.open(file12.c_str(), ios:: out | ios::binary);
         if (!myfile12)
         {
              myfile12.close();
              cout << "Failed to read file in line 712\n";
              cin >> x;
              exit(1);
         }           

    }                          
     
    if (formatoutput == "t")
    {
         ss.clear();
         file12 = "";
         file12 = "netoutput.txt";
          
         // open output node input file
         myfile12.open(file12.c_str(), ios:: out);
         if (!myfile12)
         {
              myfile12.close();
              cout << "Failed to read file in line 730\n";
              cin >> x;
              exit(1);
         }           

    }                          

    count = totalnodes - outputs;
    do
    {
          
         count++;
         // assign name output node
         ss.clear();
         file2 = "";
         ss << count;
         ss >> file2;
         file2 = file2 + oext;
         
         // open output node input file
         myfile2.open(file2.c_str(), ios:: in);
         if (!myfile2)
         {
              myfile2.close();
              cout << "Failed to read file in line 733\n";
              cin >> x;
              exit(1);
         }           
          
         // read output file
         myfile2 >> readoutput;
          
         // print output to screen
         if (formatoutput == "t")
         {
              cout << readoutput << " ";
         }
   
         // close output node file
         myfile2.close();
         myfile2.flush();          
         myfile2.clear();

         if (formatoutput == "t")
         {
              myfile12 << readoutput << " ";
         }
         
         if (formatoutput == "b")
         {

              // Rounding and formatting for binary output
              if (readoutput - int(readoutput) >= .5)
              {
                   readoutput++;
              }
              readoutput = int(readoutput);
              
              if (readoutput > 255)
              {
                   readoutput = 255;
              }               

              if (readoutput < 0)
              {
                   readoutput = 0;
              }
              
              // Saving binary output to file.
              myfile12 << readoutput;
         }                 

    // repeat for number of outputs
    } while (count < totalnodes);
    cout << "\n";         
     
    myfile12.close();
    myfile12.flush();          
    myfile12.clear();
    
    cout << "Program completed.\n";
    cin >> x;
    

// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< CLEAR ALL LOG FILES.
// clear all log / output / input files.
     count = 0;
     do
     {

          count++;  
          ss.clear();
          file2 = "";
          ss << count;
          ss >> file2;
          file2 = file2 + iext;

          // open input files and clean it out.
          myfile2.open(file2.c_str(), ios:: out);
          if (!myfile2)
          {
               myfile2.close();
               cout << "Failed to read file in line 760\n";
               cin >> x;
               exit(1);
          } 
          myfile2.close();
          myfile2.flush();
          myfile2.clear();
          
          ss.clear();
          file2 = "";
          ss << count;
          ss >> file2;
          file2 = file2 + oext;
          
          // open output files and clean it out.
          myfile2.open(file2.c_str(), ios:: out);
          if (!myfile2)
          {
               myfile2.close();
               cout << "Failed to read file in line 779\n";
               cin >> x;
               exit(1);
          } 
          myfile2.close();
          myfile2.flush();
          myfile2.clear();
          
          ss.clear();
          file2 = "";
          ss << count;
          ss >> file2;
          file2 = file2 + wext;
          
          // open weight files and clean it out.
          myfile2.open(file2.c_str(), ios:: out);
          if (!myfile2)
          {
               myfile2.close();
               cout << "Failed to read file in line 798\n";
               cin >> x;
               exit(1);
          } 
          myfile2.close();
          myfile2.flush();
          myfile2.clear();
        
     } while(count < totalnodes);

}                                     
