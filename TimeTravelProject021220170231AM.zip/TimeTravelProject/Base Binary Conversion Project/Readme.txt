This project converts a binary file to a text file in a number base
and converts a text file in a number base back to a binary file.
The code does compile but as of yet it needs more work.
