WARNING WEIGHTED SUMS MUST USE A WEIGHT FILE AND NUMBER GENERATORS MUST USE A RANDOM.TXT FILE. THERE ARE PROGRAMS HERE TO BUILD THOSE FILES.
BASE POWER CHECK-SUMS MUST HAVE A POWER.TXT FILE AND A CHECKSUM .CHK FILE TO DECODE. THERE IS PROGRAMS HERE TO BUILD THE POWER.TXT FILE

This computer code project is free to anyone who wants it. If you change anything please give time travel project credit for the orginal work.

Right now this project is not user friendly and has been changing faster than I can update the readme.txt file.

THIS PROJECT IS IN THE BETA STAGE AND IS READY TO USE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

COPYRIGHT(C) 2017 http://time-travel.institute

THIS PROJECT IS OPEN SOURCE!!!! ENJOY WORLD

TIME TRAVEL PROJECT UP AND RUNNING!!!!

This works on the physics principle that Einstein said all space-time exist at the same time. 
SO ALL COMPUTER FILES IN SPACE-TIME EXIST AT THE SAME TIME TOO. THEY JUST HAVE TO BE CONSTRUCTED!!!!
SINCE THIS PROJECT MAPS ALL COMPUTER FILES IN SPACE-TIME TO A NUMBER KNOWN AS A CHECK-SUM THE COUNTERS HERE
CAN TAKE THOSE CHECK-SUMS AND DECODE THEM TO COMPUTER FILES THUS MAKING IT POSSIBLE TO DOWNLOAD AND RECONSTRUCT
ANY COMPUTER FILE ANY WHERE IN SPACE-TIME!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

This project uses statistics to calculate strong check-sums of computer media files that exist in the past, present, future, and alternate time-lines. Then 
using their check-sums construct the computer files with a process known as check-sum hacking. The final product is called "Time Hacking".
So, this project uses a process called check-sum hacking to construct computer files from their check-sums then uses a process for calculating unknown check-
sums of time travel computer media files. Thus resulting in the final process called time-hacking.
With time hacking it is possible to construct a computer file no matter where or when it existed without ever connecting to the internet or a phone line.

I was doing this as a private project for myself but I got on the internet and ran my mouth off and now my home network gets hacked on a daily bases by the 
C.I.A. and N.S.A and has been getting hacked by the C.I.A. and N.S.A. for several years now.
So, since I was getting hacked for this I decided to make it a public project and give it to the world. 
I can't see this being in the hands of any one individual everyone should have it.
I can't upload my private code but I started writing the public their own version of this project. I had to encrypt and hide my private code and I can't go 
back and get it for fear of having it taking away from me. I spent 8 years writing my private code so I decided that should stay with me. It is a matter of pride for me denying the N.S.A. and the C.I.A. my orginal computer code.

So, you can use this project to backup your own files or recover files you lost without a backup if you know the check-sum range your files were in.

This is best used as a temporal email system using what is called the A/B time travel algorithm.
If (A) in the past and (B) in the future both know the check-sum range of their messages to each other through space-time then (A) in the past and (B) in the future can construct all their messages to each other between that check-sum range and read them. Thus, breaking causality. AND IT IS POSSIBLE TO USE FILE ATTACHMENTS SO A IN THE PAST AND B IN THE FUTURE CAN SHARE FILES!!!!

How to use.

I have three projects setup to run for looking for time travel computer media. 

1. The base power counter project. Directions are in the directory. This is still too slow to use for larger files but it can be run in parallel by cutting the files in sections then working the project and at the end rejoinging the sections. It still needs some work but should be ok to try to use. The base power check-sums maps all computer files in space-time to a base power check-sum and decodes it to a computer file.

2. The binary generator project. Directions are in the directory. This is still needs some testing but will generate pure binary files and test them for time travel computer media and delete the bad files. I recommend starting here. If you do find any errors feel free to edit the code to your needs. As I can I will do any more more work on it that it may need. This project maps all computer files in space-time to strong check-sums and makes it possible to decode them to computer files

3. Not completed yet. The Target Strong check-sum project this project will decode a target strong check-sum to a computer file. This is to be cracked so it takes some work. But this will allow precision computer time travel.

As I get time I will get these files upgraded and working faster and better.

This will get a time-hacking project started. I got a ton of more stuff to do but now COMPUTER TIME TRAVEL IS HERE FOR THE PUBLIC!!!!!

I found a error in my binary reading buffer. The buffer was only working for 1 byte. I editied it so the buffer can be sized up. The buffer and the sizes of the files need to be compatable to use. If you use my code if possible you should read it and edit it to your needs. If not compile it by g++ nameoffile.cpp -o nameoffile

I am giving the world computer time travel. YOUR WELCOME PUBLIC. YOUR WELCOME WORLD!!!!!!

This is a tool set for time-hacking and check-sum hacking.

For time hacking. This is the basic method.
Get a sample of known files you are looking for.
Get a configuration file of those files
Load configuration file into random number generator. Make sure the generator is programmed to give your check-sums in the ranges and values you need.
Use random number generator to construct check-sums or files. 
also use the timescanners to construct files or check-sums.
If using the timescanners use a destination file and add or subtract from it to move it up or down a regression line and the time scanners will 
construct files around the destination file at the point it is at in the regression line.
Use the any needed counters to re-construct the check-sums out of space-time.
TRAIN THE ROBOT TO VERIFY GOOD FILES AND VERIFY BAD FILES
Use the file format robot to verify good file formats and delete bad file formats.
Use robot to verify the files. This best and easiest method is the nearest neighbor method per the sample of known files.

I recommend using Random.org for numbers or /dev/random.

I had to remove my binaries because of the C.I.A. and N.S.A. hacking me at home. They try to infect my binaries so my files get deleted at sourceforge. So now I can only upload text files nothing else. Still scan these files before you use them.

WARNING THE C.I.A. AND THE N.S.A. DONT WANT YOU TO HAVE THIS COMPUTER CODE BECAUSE IT ALLOWS FOR A METHOD OF TIME TRAVEL!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
THIS COMPUTER CODE SHOULD NEVER BE USED FOR MALICIOUS ACTIVITY!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
THIS PROJECTS MAIN PURPOSE IS FILE RECOVERY ONLY!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

Again I am working on making this better. I can't promise you won't find any errors.
I can't promise you won't have to edit my variables to your own parameters.
To compile it is g++ nameoffile.cpp -o nameoffile
When compiling look at what header files it needs or anything else it needs. In the Tools directory are the header files and other things.
If compiling on windows make sure the system("command1 parameters") are for windows not linux
HAPPY TIME-HACKING.

Last it is possible to use graphing programs such as GNUPLOT to see a regression line and where computer files are around that regression line.

So, everyone enjoy.

Thanks,
Reactor1967

