#!/bin/bash

g++ timescanner.cpp -o timescanner

