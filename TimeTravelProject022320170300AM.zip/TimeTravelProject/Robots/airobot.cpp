// This program gets strong check-sums of files and writes them to a list  with a 0 or 1 for output for training
// When ran it test other files and uses the neigherst neighbor method to find a good file or a bad file.
// This program just have a weights file
// COPYRIGHT(C) 2016 http://time-travel.institute
#include <cstdlib>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <string>
#include <cmath>
#include <ctime>
#include <cstdio>
#include <iostream>

using namespace std;
// declare subs
// ======================================================================================================================
// open list of files. Get strong check sum for files and write them to strongchecksum.txt with file names
    int getstrongsumsfilelist2(long long howmanyweightedsums, int buffersize)
    {
         // declare variables
         fstream c1myfile1("list.txt", ios::in);
         fstream c1myfile2("strongsums.txt", ios::out);
         // open file2 for weights
         fstream c1myfile3("weights.txt", ios::in);
         string file1; 
         fstream myfile1;
         long double x1;
         string x2;
         int byte1 = 0;
         long double schecksum = 0;
         long long begin1;
         long long count1;
         long long count2;
         unsigned char buffer(buffersize);
         long long size1;
         long long size2;
         long long filesize1;
         long long end1 = 0;
         string pause;
//         stringstream ss;
         
         // open main loop
         do
         {
              // read list
              c1myfile1 >> file1;
              if (c1myfile1.eof())
              {
                   break;
              }   
// get strong check sum

              // open file1 computer file1
              fstream myfile1(file1.c_str(), ios::in | ios::binary);
              if (!myfile1)
              {
                   myfile1.close();
                   cout << "Failed to read file one.\n";
                   cin >> pause;
                   exit(1);
              }

              // get filesize1
              begin1 = myfile1.tellg();
              if (!myfile1)
              {
                   myfile1.close();
                   cout << "Failed to read file one.\n";
                   cin >> pause;
                   exit(1);
              }
              myfile1.seekg (0, ios::end);
              end1 = myfile1.tellg();
              filesize1 = (end1-begin1);

              // Two loops that get the strong check-sum
              count1 = 0;
              schecksum = 0;
              // start loop 1
              do
              {
                   // read file1
                   byte1 = 0;
                   // read file1
                   myfile1.seekg(count1);
                   myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
                   begin1 = myfile1.tellg();
                   // byte1 = read from file 1
                   byte1 = (int)buffer;

                   count2 = 0;
                   // start loop 2
                   do
                   {
                        // count2++;
                        count2++;
                        // read weight file. 
                        c1myfile3.precision(36);
                        c1myfile3 >> x1;
                        // schecksum = schecksum + (byte1 * x1);
                        schecksum = schecksum + (byte1 * x1);
                   // end loop 2 for how many weighted sums
                   } while(count2 < howmanyweightedsums);
                   // count1 = count1 + buffersize;
                   count1 = count1 + buffersize;
              // end loop 1 for count1 < filesize1 - 1
              } while (count1 <  filesize1 - 1);
              // close file1 for program
              myfile1.close();
              myfile1.clear();
              myfile1.flush();     
              // write weak check-sum to file
              c1myfile2.precision(36);
              c1myfile2 << file1 << " " << schecksum << "\n";
        // repeat main loop to end of file
         } while(!c1myfile1.eof());
        // close list.txt
         c1myfile1.close();
         c1myfile1.clear();
         c1myfile1.flush();
        // close strongsums.txt
         c1myfile2.close();
         c1myfile2.clear();
         c1myfile2.flush();
        // close file2 for weights
         c1myfile3.close();
         c1myfile3.clear();
         c1myfile3.flush();
    }
// ======================================================================================================================
// ===========================================================================================
    int getstrongsumsfilelist1(long long howmanyweightedsums, int buffersize, int test)
    {
         // declare variables
         fstream c1myfile1("list.txt", ios::in);
         fstream c1myfile2("database.txt", ios::out | ios::app);
         // open file2 for weights
         fstream c1myfile3("weights.txt", ios::in);
         string file1; 
         fstream myfile1;
         long double x1;
         string x2;
         int byte1 = 0;
         long double schecksum = 0;
         long long begin1;
         long long count1;
         long long count2;
         unsigned char buffer(buffersize);
         long long size1;
         long long size2;
         long long filesize1;
         long long end1 = 0;
         string pause;
//         stringstream ss;
         
         // open main loop
         do
         {
              // read list
              c1myfile1 >> file1;
              if (c1myfile1.eof())
              {
                   break;
              }   
// get strong check sum

              // open file1 computer file1
              fstream myfile1(file1.c_str(), ios::in | ios::binary);
              if (!myfile1)
              {
                   myfile1.close();
                   cout << "Failed to read file one.\n";
                   cin >> pause;
                   exit(1);
              }

              // get filesize1
              begin1 = myfile1.tellg();
              if (!myfile1)
              {
                   myfile1.close();
                   cout << "Failed to read file one.\n";
                   cin >> pause;
                   exit(1);
              }
              myfile1.seekg (0, ios::end);
              end1 = myfile1.tellg();
              filesize1 = (end1-begin1);

              // Two loops that get the strong check-sum
              count1 = 0;
              schecksum = 0;
              // start loop 1
              do
              {
                   // read file1
                   byte1 = 0;
                   // read file1
                   myfile1.seekg(count1);
                   myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
                   begin1 = myfile1.tellg();
                   // byte1 = read from file 1
                   byte1 = (int)buffer;

                   count2 = 0;
                   // start loop 2
                   do
                   {
                        // count2++;
                        count2++;
                        // read weight file. 
                        c1myfile3.precision(36);
                        c1myfile3 >> x1;
                        // schecksum = schecksum + (byte1 * x1);
                        schecksum = schecksum + (byte1 * x1);
                   // end loop 2 for how many weighted sums
                   } while(count2 < howmanyweightedsums);
                   // count1 = count1 + buffersize;
                   count1 = count1 + buffersize;
              // end loop 1 for count1 < filesize1 - 1
              } while (count1 <  filesize1 - 1);
              // close file1 for program
              myfile1.close();
              myfile1.clear();
              myfile1.flush();     
              // write weak check-sum to file
              c1myfile2.precision(36);
              c1myfile2 << file1 << " " << schecksum << " " << test << "\n";
        // repeat main loop to end of file
         } while(!c1myfile1.eof());
        // close list.txt
         c1myfile1.close();
         c1myfile1.clear();
         c1myfile1.flush();
        // close strongsums.txt
         c1myfile2.close();
         c1myfile2.clear();
         c1myfile2.flush();
        // close file2 for weights
         c1myfile3.close();
         c1myfile3.clear();
         c1myfile3.flush();
    }
// ======================================================================================================================

//============================================================================================

int main (int argc, char *argv[])
{

     char choice;
     int test;
     int test2;
     string pause;
     string file1;
     int dummyfile;
     int buffersize = 1;
     long long howmanyweightedsums;
     long double num1;
     long double num2;
     long double answer = 999999999999999999;
     cout << "Select your choice." << "\n";
     string file;
     string file3;

     cout << "\n";

     cout << "1. Train a new data base." << "\n";

     cout << "\n";

     cout << "2. Find good files and delete bad ones." << "\n";

     cout << "\n";

     cin >> choice;

    if (choice=='1')
    {
         cout << "Make a list.txt for the files" << "\n";
         cin >> pause;
         cout << "Enter 1 for good files enter 0 for bad files" << "\n";
         cin >> test;
         cout << "How many weighted sums are we using for the strong check-sums" << "\n";
         cin >> howmanyweightedsums;
         dummyfile = getstrongsumsfilelist1(howmanyweightedsums, buffersize, test);
         cout << "Data base generated. Put this file up and keep it you will need it." << "\n";
         exit(0);
    }

    if (choice == '2')
    {
         cout << "Make a list.txt for the time travel files to check" << "\n";
         cin >> pause;
         cout << "How many weighted sums are we using for the strong check-sums" << "\n";
         cin >> howmanyweightedsums;
         dummyfile = getstrongsumsfilelist2(howmanyweightedsums, buffersize);
         cout << "List of files to check generated" << "\n";
         cout << "Make sure your data base is is in the same directory" << "\n";
         cout << "Checking files. Deleting bad files. Keeping good files" << "\n";
         fstream c1myfile1;

         // open strongsums.txt
         fstream c1myfile2("strongsums.txt", ios::in);
         if (!c1myfile2)
         {
              cout << "Unable to open file line 302 \n";
              system("pause");
              exit(1); // terminate with error
         }

         // start first loop
         do
         {
              num1 = 0;
              // read strongsums.txt
              if (!c1myfile2.eof())
              {
                   c1myfile2 >> file3 >> num1;
              }
 
              // open data base
              c1myfile1.open("database.txt", ios::in);
              if (!c1myfile1)
              {
                   cout << "Unable to open file line 302 \n";
                   cin >> pause;
                   exit(1); // terminate with error
              }

              // read the data base and find closest match
              answer = 999999999999999999;
              // start second loop
              do
              {
                   num2 = 999999999999999999;
                   if (!c1myfile1.eof())
                   {
                        // find closest match
                        c1myfile1 >> file1 >> num2 >> test;
                   }
                   if (abs(num1 - num2) <= answer)
                   {
                        answer = abs(num1 - num2);
                        test2 = test;
                        file3 = file1;
                   }
              // end second loop
              } while(!c1myfile1.eof());
              // close data base
             c1myfile1.close();
             c1myfile1.clear();
             c1myfile1.flush();

              // if closest match 0 delete file
              if (test2 == 0)
              {
                   if( remove( file3.c_str() ) != 0 )
                   perror( "Error deleting file" );
                   else
                   puts( "File successfully deleted" );

              }
         // repeat loop till end of file

         } while(!c1myfile2.eof());
         system("rm strongsums.txt");
         c1myfile2.close();
         c1myfile2.clear();
         c1myfile2.flush();
         // Tell user files checked. Bad files deleted
         cout << "Files checked. Bad files were deleted" << "\n";
         // end program
         exit(0);     

    }


}

