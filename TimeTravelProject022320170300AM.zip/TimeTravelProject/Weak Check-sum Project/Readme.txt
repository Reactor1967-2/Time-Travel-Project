Note: I am still working on getting this up to speed for now.

Use the weak check-sum file generator to generate a file at a specific file size with a specific weak check-sum.

Then use the weak check-sum counter to create time travel media files from the same weak check-sum.

Use the robot to delete the bad files and leave the good files

This works similiar to the other counters here. A destination file is being moved up and down to create target files.

The weak check-sum counter moves a destination file up or down to create tartget files of the same weak check-sum.

This counter tries to keep all its targets at the same check-sum. Some of
the files won't be the same check-sum. Those can be ignored.


For using random numbers:

To create random files it is best to use true random numbers. Create a random.bin file with this command in Linux:
cat /dev/random > random.bin

Next to split the files into specific file sizes use the split command:
split -b sizeoffilesneeded nameofrandom.bin prefexofdifffiles

You can rename one of the difference files as your destination file.

if you want to use the binary file generator you can. That is up to you. You can use the base conversion code program to convert random.bin to a seed file.

Happy "Time-Hacking"

Reactor1967
