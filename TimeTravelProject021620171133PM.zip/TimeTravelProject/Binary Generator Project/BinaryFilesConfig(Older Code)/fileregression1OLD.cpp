// This file takes a directory of like computer files and plots a regression line
// of their for their weak,strong check sums.
// ALL YOU DO WITH THIS IS PUT IT IN A DIRECTORY OF LIKE FILES AND RUN THE PROGRAM. IT GENERATES A CONFIGURE FILE.
// THE CONFIG FILE WILL GO INTO THE NEXT PROGRAM THAT GENERATES A LIST OF UNKNOWN STRONG CHECK SUMS WHICH GET USED TO 
// GENERATE CONFIG FILES FOR FIRE CODES TO RECONSTRUCT!!!!!!!!!!!!!!! THEN WE WILL BE TIME TRAVELING WITH A COMPUTER!!!!!
// Here I am using weak check sums but you can use anything. It can be sum of differences of bytes or what ever.
// But for now here I am using weak check sums because I need two variables to predict my strong check sums.
// Copyright (C) 2016 http://time-travel.institute
// ============================================================================================
 // declare includes
     #include <cstdlib>
     #include <iostream>
     #include <stdlib.h>
     #include <fstream>
     #include <sstream>
     #include <string> 
     #include <cmath>
     #include <ctime>
     #include <cstdio>
     #include <iostream>
// ============================================================================================
    // Declare namespace
    using namespace std;
// ============================================================================================     
    // declare globals
// ============================================================================================     
// declare subs
// This is where all the work is done to make the program run.
// run command to make list of files
    int makelist()
    {
         char pause;
         system("ls test* > list.txt");
//         cin >> pause;
//         cout << "Check list.txt" << "\n";
//         exit(0);
         return(0);
    }
// open list of file. Get weak check sum for files and write then to weaksum.txt with file names
    int getweaksums(int buffersize)
    {
         // declare variables
         fstream c1myfile1("list.txt", ios::in);
         fstream c1myfile2("weaksums.txt", ios::out);
         string file1; 
         fstream myfile1;
         int x;
         long long checksum = 0;
         long long begin1;
         long long count1;
         long long count2;
         unsigned char buffer(buffersize);
         long long size1;
         long long size2;
         long long filesize;
         string pause;
         // open main loop
         do
         {
              // read list
              c1myfile1 >> file1;
//              cout << file1 << "\n";
              if (c1myfile1.eof())
              {
                   break;
              }

              // get weak check-sum of file
// ================================================================================================              
// Start getting weak check sum
              // open file1
              myfile1.open(file1.c_str(), ios:: in | ios:: binary);
              if (!myfile1)
              {
                   cout << "122608-12:02 am Unable to open file.\n";
                   cin >> pause;
                   exit(1); // terminate with error
              }
              // get file size
              myfile1.seekg(0, ios::beg);
              size1 = myfile1.tellg();
              myfile1.seekg(0, ios::end);
              size2 = myfile1.tellg();
              filesize = size2 - size1;
              // set checksum to 0
              checksum = 0;
              // set count1 to 0
              count1 = -1;
              // start first loop
              do
              {
                   // count1 = count1 + buffersize2
                   count1 = count1 + buffersize;
                   // read byte
                   begin1 = myfile1.tellg();
                   myfile1.seekg(count1);
                   if (!myfile1)
                   {
                        myfile1.close();
                        cout << "error in line 51.\n";
                        cin >> pause;
                        exit(1);
                   }
                   myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
                   x = (int)buffer;
                   // calculate weak check sum
                   checksum = checksum + x;
              // end first loop while (count1 < ((filesize - 1) + buffersize2))
              } while (count1 <  filesize - 1);
              // close files
              myfile1.close();
              myfile1.clear();
              myfile1.flush();
// END GETTING WEAK CHECK STRONG
// ================================================================================================
              if (c1myfile1.eof())
              {
                   break;
              }
              // write weak check-sum to file
              c1myfile2 << checksum << "\n";
        // repeat main loop to end of file
         } while(!c1myfile1.eof());
        // close list.txt
         c1myfile1.close();
         c1myfile1.clear();
         c1myfile1.flush();
        // close weaksums.txt
         c1myfile2.close();
         c1myfile2.clear();
         c1myfile2.flush();
        // return(0);
        return(0);
    } 
// open list of files. Get strong check sum for files and write them to strongchecksum.txt with file names
    int getstrongsums(long long howmanyweightedsums, int buffersize)
    {
         // declare variables
         fstream c1myfile1("list.txt", ios::in);
         fstream c1myfile2("strongsums.txt", ios::out);
         // open file2 for weights
         fstream c1myfile3("weights.txt", ios::in);
         string file1; 
         fstream myfile1;
         long double x1;
         string x2;
         int byte1 = 0;
         long double schecksum = 0;
         long long begin1;
         long long count1;
         long long count2;
         unsigned char buffer(buffersize);
         long long size1;
         long long size2;
         long long filesize1;
         long long end1 = 0;
         string pause;
//         stringstream ss;
         
         // open main loop
         do
         {
              // read list
              c1myfile1 >> file1;
              if (c1myfile1.eof())
              {
                   break;
              }   
// ================================================================================================              
// get strong check sum

              // open file1 computer file1
              fstream myfile1(file1.c_str(), ios::in | ios::binary);
              if (!myfile1)
              {
                   myfile1.close();
                   cout << "Failed to read file one.\n";
                   cin >> pause;
                   exit(1);
              }

              // get filesize1
              begin1 = myfile1.tellg();
              if (!myfile1)
              {
                   myfile1.close();
                   cout << "Failed to read file one.\n";
                   cin >> pause;
                   exit(1);
              }
              myfile1.seekg (0, ios::end);
              end1 = myfile1.tellg();
              filesize1 = (end1-begin1);

              // Two loops that get the strong check-sum
              count1 = 0;
              schecksum = 0;
              // start loop 1
              do
              {
                   // read file1
                   byte1 = 0;
                   // read file1
                   myfile1.seekg(count1);
                   myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
                   begin1 = myfile1.tellg();
                   // byte1 = read from file 1
                   byte1 = (int)buffer;

                   count2 = 0;
                   // start loop 2
                   do
                   {
                        // count2++;
                        count2++;
                        // read weight file. 
                        c1myfile3.precision(36);
                        c1myfile3 >> x1;
                        // schecksum = schecksum + (byte1 * x1);
                        schecksum = schecksum + (byte1 * x1);
                   // end loop 2 for how many weighted sums
                   } while(count2 < howmanyweightedsums);
                   // count1 = count1 + buffersize;
                   count1 = count1 + buffersize;
              // end loop 1 for count1 < filesize1 - 1
              } while (count1 <  filesize1 - 1);
              // close file1 for program
              myfile1.close();
              myfile1.clear();
              myfile1.flush();     
// ================================================================================================
              // write weak check-sum to file
              c1myfile2.precision(36);
              c1myfile2 << schecksum << "\n";
        // repeat main loop to end of file
         } while(!c1myfile1.eof());
        // close list.txt
         c1myfile1.close();
         c1myfile1.clear();
         c1myfile1.flush();
        // close strongsums.txt
         c1myfile2.close();
         c1myfile2.clear();
         c1myfile2.flush();
        // close file2 for weights
         c1myfile3.close();
         c1myfile3.clear();
         c1myfile3.flush();
    }
// open list and count how many samples
    long long countsamples()
    {
         // declare variables
         long long count1 = 0;
         long long count2 = 0;  
         long long x1 = 0;
         long double x2= 0;
         string pause;
         // open weak sums list
         fstream c1myfile1("weaksums.txt", ios::in);         
         // open strong sums list
         fstream c1myfile2("strongsums.txt", ios::in);
         // set count1 to 0
         count1 = 0;
         // start loop1
         do
         { 
              // read weak sum
              c1myfile1 >> x1;
              // if end of file break
              if (c1myfile1.eof())
              {
                   break;
              }
              // increment count1
              count1++;
         // end loop 1
         } while(!c1myfile1.eof());
         // set count2 to 0
         count2 = 0;
         // start loop1
         do
         { 
              // read weak sum
              c1myfile2 >> x2;
              // if end of file break
              if (c1myfile2.eof())
              {
                   break;
              }
              // increment count1
              count2++;
         // end loop 1
         } while(!c1myfile2.eof());
        // close list.txt
         c1myfile1.close();
         c1myfile1.clear();
         c1myfile1.flush();
        // close strongsums.txt
         c1myfile2.close();
         c1myfile2.clear();
         c1myfile2.flush();
         if (count1 != count2)
         {
              cout << "count1 " << count1 << " Not equal to " << "count2 " << count2 << "\n";
              cin >> pause;
         }   
         // return(count2);
         return(count2); 
    }
// ex =  Sum of X Get sum of strong check-sums
    long double getexstrongsums()
    {
         long double x2= 0;
         long double count2 = 0;         
         // open strong sums list
         fstream c1myfile2("strongsums.txt", ios::in);
         count2 = 0;
         // start loop1
         do
         { 
              // read weak sum
              c1myfile2 >> x2;
              count2 = count2 + x2;
              // if end of file break
              if (c1myfile2.eof())
              {
                   break;
              }
              // increment count1
         // end loop 1
         } while(!c1myfile2.eof());
        // close strongsums.txt
         c1myfile2.close();
         c1myfile2.clear();
         c1myfile2.flush();
         return(count2);
    }
// ey =  Sum of Y Get sum of weak check-sums
    long long geteyweaksums()
    {
         long long x2= 0;
         long long count2 = 0;         
         // open strong sums list
         fstream c1myfile2("weaksums.txt", ios::in);
         count2 = 0;
         // start loop1
         do
         { 
              // read weak sum
              c1myfile2 >> x2;
              count2 = count2 + x2;
              // if end of file break
              if (c1myfile2.eof())
              {
                   break;
              }
              // increment count1
         // end loop 1
         } while(!c1myfile2.eof());
        // close strongsums.txt
         c1myfile2.close();
         c1myfile2.clear();
         c1myfile2.flush();
         return(count2);

    }
// ex^2 = Sum of x^2 Get sum of squares of strong check-sums
    long double getexsquare2sumofsquaresstrongsums()
    {
         long double x2= 0;
         long double count2 = 0;         
         // open strong sums list
         fstream c1myfile2("strongsums.txt", ios::in);
         count2 = 0;
         // start loop1
         do
         { 
              // read weak sum
              c1myfile2 >> x2;
              x2 = pow(x2, 2);
              count2 = count2 + x2;
              // if end of file break
              if (c1myfile2.eof())
              {
                   break;
              }
              // increment count1
         // end loop 1
         } while(!c1myfile2.eof());
        // close strongsums.txt
         c1myfile2.close();
         c1myfile2.clear();
         c1myfile2.flush();
         return(count2);

    }
// ey^2 = Sum of y^2 Get sum of squares of weak check-sums
    long long geteysquare2sumofsquaresweaksums()
    {
         long long x2= 0;
         long long count2 = 0;         
         // open strong sums list
         fstream c1myfile2("weaksums.txt", ios::in);
         count2 = 0;
         // start loop1
         do
         { 
              // read weak sum
              c1myfile2 >> x2;
              x2 = pow(x2, 2);
              count2 = count2 + x2;
              // if end of file break
              if (c1myfile2.eof())
              {
                   break;
              }
              // increment count1
         // end loop 1
         } while(!c1myfile2.eof());
        // close strongsums.txt
         c1myfile2.close();
         c1myfile2.clear();
         c1myfile2.flush();
         return(count2);
    }
// exy = Sum of X times Y Sum of Strong check-sums times weak check sums
    long double getexysumofstrongsumstimesweaksums(long double ex, long long ey)
    {
         long double count2 = 0;
         count2 = 0;
         count2 = ex * ey;
         return(count2);
    }
// Get X average of strong check-sum
    long double getxaverageofstrongsums(long double ex,long long samples)
    {
         long double count2 = 0;
         count2 = ex/samples;
         return(count2); 
    }
// Get y average of weak check-sums
    long long getyaverageofweaksums(long long ey, long long samples)
    {
         long long count2 = 0;
         count2 = ey/samples;
         return(count2);
    }
//     (n times (exy))-((ex) times (ey))
// b = --------------------------------     =  CALCULATE B
//      (n times (ex^2)) - ((ex)^2)
    long double getB(long long samples, long double ex, long long ey, long double exsquared, long long eysquared, long double exy)
    {
         long double b = 0;
         b = ((samples * exy) - (ex * ey)) / ((samples * exsquared) - exsquared);
         return(b);  
    }
// a = y - (b times x) = WRITE EQUATION TO CONFIGURE FILE
    int writeequationconfigfile(long long y, long double b, long double x)
    {
         fstream c1myfile2("regressionconfig.txt", ios::out);
         c1myfile2 << " a = y - (b times x)" << "\n";         
         c1myfile2.precision(36);
         c1myfile2 << " a = " << y << " - " << " ( " << b << " times " << x << " ) " << "\n";
        // close strongsums.txt
         c1myfile2.close();
         c1myfile2.clear();
         c1myfile2.flush();
         return(0);
    }
// ============================================================================================
// declare main
    int main (int argc, char *argv[])
    { 
         // declare variables
         int dummyfile;
         int buffersize = 1;
         long long howmanyweightedsums = 100;
         long long samples = 0;
         long double ex = 0;
         long long ey = 0;
         long double exsquared = 0;
         long long eysquared = 0;
         long double exy = 0;
         long double x = 0;
         long long y = 0;
         long double b = 0;
         string pause;
// ============================================================================================
// test subs here

// ============================================================================================
         // Run program
// run command to make list of files
         dummyfile = makelist(); // list will be called list.txt (make sure there are no other folders in this direction.
// open list of file. Get weak check sum for files and write then to weaksum.txt with file names
         dummyfile = getweaksums(buffersize);
// open list of files. Get strong check sum for files and write them to strongchecksum.txt with file names
         dummyfile = getstrongsums(howmanyweightedsums, buffersize); 
// open list and count how many samples
         samples = countsamples();
// ex =  Sum of X Get sum of strong check-sums 
         ex = getexstrongsums();
// ey =  Sum of Y Get sum of weak check-sums 
         ey = geteyweaksums();
// ex^2 = Sum of x^2 Get sum of squares of strong check-sums
         exsquared = getexsquare2sumofsquaresstrongsums(); 
// ey^2 = Sum of y^2 Get sum of squares of weak check-sums 
         eysquared = geteysquare2sumofsquaresweaksums();
// exy = Sum of X times Y Sum of Strong check-sums times sum of weak check sums 
         exy = getexysumofstrongsumstimesweaksums(ex,ey);
// Get X average of strong check-sum 
         x = getxaverageofstrongsums(ex,samples);
// Get y average of weak check-sums 
         y = getyaverageofweaksums(ey,samples);

//     (n times (exy))-((ex) times (ey))
// b = --------------------------------     =  CALCULATE B // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<< We are here writing program
//      (n times (ex^2)) - ((ex)^2)
         b = getB(samples, ex, ey, exsquared, eysquared, exy);

// a = y - (b times x) = WRITE EQUATION TO CONFIGURE FILE
         dummyfile = writeequationconfigfile(y, b, x);

// delete left over files
         system("rm list.txt");
         system("rm strongsums.txt");
         system("rm weaksums.txt");

// EXIT PROGRAM
         exit(0); 
    }     
// ============================================================================================         
// Example of how my software will use regression lines.
// =================================== Starting sample
// Example of Graphing a regression line by hand.
// When done write files with the x and y files and see if they get the same answers as this example.
// x  1| 3|10| 16| 26| 36
// -------------------------
// y 42|50|75|100|150|200

// Goal - Get equation y = a + bx where  a = y intercept and b = slop 

// 1. Count how many samples you have.
// 2. Get sum of X
// 3. Get sum of y

// Symbol Chart
// ---------------------------
// n = How many Samples I have = 6
// ex =  Sum of X
// ey =  Sum of Y
// ex^2 = Sum of x^2
// ey^2 = Sum of y^2
// exy = Sum of X times Y
// e = sum
// -
// y = average of y = 102.8333......
// -
// x = average of x = 15.3.....

//                                     divided
// average = sum of samples / how many samples

//     (n times (exy))-((ex) times (ey))
// b = --------------------------------     =  4.51
//      (n times (ex^2)) - ((ex)^2)
//     -            -
// a = y - (b times x) = 33.83

// Now plug values into regression line. THIS IS WHERE WE GET STRONG CHECK SUMS FOR TIME TRAVEL MEDIA FILES.

//   y = a + (b times x) 

//   y = 33.83 + (4.51 times x)
//   x = 12

//   so y = 33.83 + (4.51 times 12) = 87.95
//================================================= Ending sample   
