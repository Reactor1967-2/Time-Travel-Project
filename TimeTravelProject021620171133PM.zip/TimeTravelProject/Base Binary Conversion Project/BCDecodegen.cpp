// COPYRIGHT(C) 2017 http://time-travel.institute
// THIS IS A SEEDED RANDOM NUMBER GENERATOR TO GENERATE FILES IN A BASE TO DECODE COUNTER.
// YOU CAN GET A SEED FILE FROM RANDOM.ORG
// ============================================================================================
 // declare includes
     #include <cstdlib>
     #include <iostream>
     #include <stdlib.h>
     #include <fstream>
     #include <sstream>
     #include <string> 
     #include <cmath>
     #include <ctime>
     #include <cstdio>
     #include <iostream>
// ============================================================================================
    // Declare namespace
    using namespace std;
// ============================================================================================  
// ---------------------------------
// code example - KEEP THIS HERE.
//    count2 = 0;
//    do
//    {
//         std::stringstream ss;
//         count2++;
//         ss << count2;
//         ss >> file1;
//         file2 = file2 + ".bin";
//         cout << file2 << "\n";
//    } while(count2 < 10);
// ---------------------------------
//    // passing command line arguments to program 
//    file1 = argv[1];
//
// passing command line arguments to program 
//    filesize1 = strtoull(argv[2],NULL,10);
//
//    // passing command line arguments to program
//    howmanyweightedsums = strtoull(argv[3],NULL,10);
//
//    // PASSWORD FOR CALCULATING WEIGHTED SUMS
//    password2 = strtoull(argv[4],NULL,10);
// -----------------------------------------------------------   
// declare main
int main (int argc, char *argv[])
{ // Begin main

    // declare variables    
    long long numericalbase = 99999999; // this is your numerical base. THIS SHOULD BE = (256^BUFFERSIZE) + 1 YOU HAVE TO ENTER IT!!!!!
    long long numberbase = numericalbase - 1;
    long long howmanychecksums; // This is how many files to generate. Put that in the command line arguments
    long long howmanynumbersperseed; // This is how many numbers per random seed number
    long long seed;
    long long count1;
    long long count2;
    long long count3;
    long long check1;
    long long check2;
    string file1; // Put the name of your seed file here
    string file2; // Put the name of your output file here
    string file3; // Put name of check-sum 1 file here
    string file4; // Put name of check-sum 2 file here
    string pause;
    fstream c1myfile1; // Seed file
    fstream c1myfile2; // check1
    fstream c1myfile3; // check2
    fstream c1myfile4; //outchk
    long long num;

    time_t seconds;
    srand((unsigned int) 5654940); // This seed number can be changed to what ever you want.        
    long long a = 3;
    long long c = 2361;
    long long m = 999999;
    long long k = 0;
    long long r = 0;

//    cout << "Enter the name of your seed file" << "\n";
//    cin >> file1;

      file1 = argv[1];

    // get name of file3 this is 1.chk

      file3 = argv[2];

    // get name of file4 this is 2.chk
      file4 = argv[3];

    // how many checksums
      howmanychecksums = strtoull(argv[4],NULL,10);
    
// how many numbers per seed  
      howmanynumbersperseed= strtoull(argv[5],NULL,10);

//      howmanychecksums = 10
    // set count1 to 0 how many check-sums per seed
    count1 = 0;
    // set count2 to 0 file count for generating check sum files so this is how many check sums per seed
    count2 = 0;
    // This is the name of the check-sums written out to be decoded
    count3 = 0;
    // Start first loop for how many check-sums
    do
    {
         // increment count2
         count2++;

         // open seed file
         c1myfile1.open(file1.c_str(), ios::in);
         if (!c1myfile1)
         {
              cout << "There is no file list." << "\n";
              c1myfile1.close();
              c1myfile1.clear();
              c1myfile1.flush();
              exit(0);           
         }

         // Start loop2 for reading the seed file
         do
         {
              // read seed file
              c1myfile1 >> seed;
              srand((unsigned int) seed);
              count1 = 0;
              // Start loop3 for how many check-sums per seed
              do
              {
                   // increment count1
                   count1++;

                   // get new check-sum file name from ss
                   std::stringstream ss;
                   count3++;
                   ss << count3;
                   ss >> file2;
                   file2 = file2 + ".outchk";

                   // open check1
                   c1myfile2.open(file3.c_str(), ios::in);
                   if (!c1myfile2)
                   {
                        cout << "There is no chk file." << "\n";
                        c1myfile2.close();
                        c1myfile2.clear();
                        c1myfile2.flush();
                        exit(0);           
                   }

                   // open check2
                   c1myfile3.open(file4.c_str(), ios::in);
                   if (!c1myfile3)
                   {
                        cout << "There is no chk file." << "\n";
                        c1myfile3.close();
                        c1myfile3.clear();
                        c1myfile3.flush();
                        exit(0);           
                   }

                   // open check-sum file for ss
                   c1myfile4.open(file2.c_str(), ios::out);
                   if (!c1myfile4)
                   {
                        cout << "There is no outchk file." << "\n";
                        c1myfile4.close();
                        c1myfile4.clear();
                        c1myfile4.flush();
                        exit(0);           
                   }

                   // Start loop4 for generating check-sums using rand
                   do
                   {  
                        // generate rand
                        time(&seconds);
                        k = (rand() % numberbase); // We can randomize timer here if we want. Thats up to the user.
                        k = k + seconds;
                        num = (a * k + c) % numberbase;

                        // read check 1
                        c1myfile2 >> check1;

                        // read check 2
                        c1myfile3 >> check2;

                        // if rand > check1 and rand < check 2 write it // Just as long as it is between num1 and num2
                        if (num >= check1)
                        {
                             if (num <= check2)
                             {
                                  c1myfile4 << num << "\n"; 
                             } 
                        }

                        // if rand > check2 and rand < check 1 write it // Just as long as it is between num1 and num2
                        if (num >= check2)
                        {
                             if (num <= check1)
                             {
                                  c1myfile4 << num << "\n"; 
                             } 
                        }

                   // End loop 4 for generating checksums close at eof
                   } while(!c1myfile2.eof()); // Make sure both check sums files THE SAME SIZE!!!!!!!!!!!!!!!!!!!!!!

                   // close check 1
                   c1myfile2.close();
                   c1myfile2.clear();
                   c1myfile2.flush();

                   // close check 2
                   c1myfile3.close();
                   c1myfile3.clear();
                   c1myfile3.flush();

                   // close check-sum file for ss
                   c1myfile4.close();
                   c1myfile4.clear();
                   c1myfile4.flush();
                   // Extra get out statement because my others don't work.
                   if (count1 == howmanychecksums)
                   {
                        exit(0);
                   } 
              // end loop 3 for how many check-sums per seed
              } while(count1 < howmanychecksums);
         // End loop 2 for reading seed file close at end of file
         } while(!c1myfile1.eof());
         // IF NUMBER OF CHECK-SUMS NOT REACHED INFORM USER TO GENERATE NEW SEED FILE.
         if (count2 < howmanychecksums)
         {  
              // PAUSE PROGRAM WHILE WAITING FOR NEW SEED FILE
              cout << "PLEASE REPLACE SEED FILE!!!!!!!!!!!!" << "\n";
              cin >> pause;
         }
    // end loop one for how many check-sums
    } while(count2 < howmanychecksums);
    // exit prograom
    exit(0);
} // End main
