// COPYRIGHT(C) 2017 http://time-travel.institute
// This is the cpp file use the base power counter header file.
// Base Power Counter 
// Load configure file
// Create configure file
// Encodes base power check-sum
// Decodes base power check-sum
// ============================================================================================
 // declare includes
    #include <cstdlib>
    #include <iostream>
    #include <stdlib.h>
    #include <fstream>
    #include <sstream>
    #include <string> 
    #include <cmath>
    #include <ctime>
    #include <cstdio>
    #include <iostream>
    #include "basepower.h"

// ============================================================================================
    // Declare namespace
    using namespace std;
// ============================================================================================     
// declare subs
// ============================================================================================
// declare main
    int main (int argc, char *argv[])
    {
 
         // declare variables
         string file1;
         string file2;
         long long numberbase = 99999999;
         int dummyfile;
         int buffersize = 1;
         long long filesize1 = 0;
         string pause;
         long long end1;
         long long begin1;

         cout << "Please enter the name of the file." << "\n";
         cin >> file2;

         cout << "What is the filesize of the decode" << "\n";
         cin >> filesize1;

         cout << "Beginning Decode" << "\n";
         dummyfile = decodepbchecksum(file2, filesize1, numberbase, buffersize);
         cout << "FILE RECONSTRUCTED FROM ITS BASE POWER CHECK-SUM IN BASE 99999999!!!!" << "\n";
         cin >> pause;
         exit(0);
         
    }
