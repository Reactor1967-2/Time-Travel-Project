Can use runann.exe with input from a keyboard or from a file.

Use run.ann as a text file to runann.exe. If not running from keyboard but running from file instead. This file will contain the inputs

Use training.ann as a text file for trainann.exe. On each line the will contain first the inputs then secondly the outputs.

run.ann example:
input

training.ann example:
input output
input output
input output
... and so forth


first run createann.exe to create a artifical neural net.
secondly run trainann.exe with training.ann text file to train this net.
thirdly run runann.exe

On runann.exe can use file for input or enter from keyboard.
Can have file for output or have output print on screen.
Can have text or binary output.
