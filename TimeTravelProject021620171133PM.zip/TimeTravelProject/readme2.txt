There are two ways to use time travel project.
1. Use the random number generators to generate binary files and check-sums. If generating check-sums they must be decoded.
2. A more precise way to use this is to create a destination file check-sum or use a known file or check-sum as a destination file. Then use the
   time scanners to find the target files or check-sums around the destination file. From time to time use the add or subtract programs
   to move the destination file or check-sum up or down then use the time scanners again.
