#!/bin/bash

g++ airobot.cpp -o airobot
g++ fileformatrobot.cpp -o fileformatrobot
g++ fileformatrobot3.cpp -o fileformatrobot3
