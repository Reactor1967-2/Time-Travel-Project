WARNING AFTER MAKING A CONFIG FILE WITH 1 OR 3 REMOVE YOUR FILE FROM THE DIRECTORY
BECAUSE IT CAN BE DESTROYED IN THE RECONSTRUCTION PROCESS!!!



Fire codes converts a computer file to check sums and reconstructs the file from check sums.

Fire codes appears to be running now but more testing is being done.

To compile fire codes g++ firecodes.cpp - o firecodes
                      g++ pbabysumconfig2.cpp -o pbabysumconfig2
                      g++ prollbabycounters.cpp -o prollbabycounters

1 or 3 has to be run first before 2 or 4.

options 1 and 2 run in linear mode
if you use 1 to create a config file use 2 to reconstruct that config file

options 3 and 4 run a project in parallel.
3 creates a script to create config files
4 creates a script to decode the config files


