// COPYRIGHT(C) 2016 http://time-travel.institute
// THIS CONTAINS PAST CODE FOR MY COMPUTER TIME TRAVEL. SOME OF IT IS OUT OF DATE. SOME OF IT IS NOT.
#ifndef timecheckhacking_h
#define timecheckhacking_h

     #include <cstdlib>
     #include <iostream>
     #include <stdlib.h>
     #include <fstream>
     #include <sstream>
     #include <string> 
     #include <cmath>
     #include <ctime>
     #include <cstdio>
     #include <iostream>
// ======================================================================================================================
    // Declare namespace
    using namespace std;
// ======================================================================================================================
// time check hacking how to use key.
// long double strongsum
// int dummyfile
// long long count2
// long long randfileposition
// long double count1
// ======================================================================================================================
// HOW TO USE KEY.

// int int loadconfig(string file1)

// long long getweakchecksum(int buffersize, string file1) // Gets the weak check-sum of a file.

// strongsum = long double getstrongchecksum(string file1, long long howmanyweightedsums, int buffersize); // gets a strong check sum of a file

// int checklockfile(string lockfile); // checks for lock file. If not there end program.

// randfileposition = setspeedrandom1(randfileposition, file3, file2, buffersize); // Sets random speed for the counter but randfileposition is manually controlled.

// dummyfile = int createsizefile(string file1, long long filesize1, int buffersize); // creates blank file with specific size

// dummyfile = int rollcounter(string file1, string file2, int buffersize, long long filesize1); // adds speed.bin and the counter file

// dummyfile = int createemptyfile(string file1); // creates empty file

// dummyfile = int createrandomcounter1(string file1, long long filesize1, int buffersize) // This is done randomly so this can be run in parallel use. Do not use random.bin here. Use computer for numbers. 

// dummyfile = int createchecksum(string file1, long long cksum, long long filesize1, int buffersize, int base); // makes a file a specific weak check sum

// dummyfile = int carrytest(string file1, int buffersize, int base, long long filesize2); // test for a carry in a customized counter

// dummyfile = int addcarry(string file1, int buffersize, int base, long long filesize1); // for writting customized weaksum rolling counter

// dummyfile = int swap(string file1, int buffersize, int base, long long filesize1, long long filesize2); swaps two sections in a file. Good for when your running your own customized weaksum rolling counter.
// swaps two sections in a binary file. The filesize2 must be the size of the section
// to swap. File size 1 must be the size of the entire file that is being operated on.
// filesize 2 must be the exact number of bytes in the section.

// dummyfile = int compare3(string file1, string file5, filesize1); // checks to see if completely different

// dummyfile = int compare2(string file1, string file5, filesize1); // checks to see if completely same

// dummyfile = int compare1(string file1, string file2, int buffersize, int base, long long s1f1, long long s2f2, long long e1f1, long long e2f2 )

// dummyfile = int multiply1(string file1, string file2, int buffersize, int base, int num); // multiplys a file by a number output in second file

// dummyfile = int subtract1(string file1, string file2, string file3, long long filesize1, long long filesize2, int buffersize, int base, long long bpos1, long long bpos2, long long epos1, long long epos2) // subtracts two files

// dummyfile = add1(file1, file2, buffersize); // Adds two files output tempfile3.bin

// dummyfile = int add2(string file1, string file2, string file3, long long filesize1, long long filesize2, int buffersize, int base, long long bpos1, long long bpos2, long long epos1, long long epos2); // adds two files together. Get to choose where to start and where to end.

// dummyfile = int binaryreadwrite(string whatdo, string file1, long long byteposition, int byte, int buffersize); // used for reading and writing binary files

// dummyfile = int  generateweights(); // Generates weights.txt for using in strong check sums

// dummyfile = int generaterandomnumbers(long long filesize1); // Generates random.bin of given file size.

// dummyfile = makelist1(); // creates a list.txt file (this may need editied)   

// dummyfile = int getweaksumsfilelist(int buffersize); // open list.txt of files. Get their weak check sums write then to weaksum.txt with file names

// dummyfile = int getstrongsumsfilelist(long long howmanyweightedsums, int buffersize); // open list of files. Get strong check sum for files and write them to strongchecksum.txt with file names

// dummyfile = int writeequationconfigfile(long double y, long double b, long long x); // a = y - (b times x) = WRITE EQUATION TO CONFIGURE FILE

// dummyfile = int viewfile1(string file1, int buffersize); // View a binary file in base 10 from 0 to 255 with buffersize 1

// count2 = long long countsamples(); // open list and count how many samples

// count2 = long long getex(); // Sum of X Get sum. (Get sum of weaksums from weaksums.txt)

// count2 = long long getexsquare2sumofsquares();// ex^2 = Sum of x^2 Get sum of squares from weaksums.txt.

// count2 = long long getxaverageofx(long long ex,long long samples); // get average of weak sums

// count2 = long long filesize(string file1); // gets the file size of a file in bytes

// count1 = getey(); // ey =  Sum of Y Get sum. from strongsums.txt

// count1 =  long double geteysquare2sumofsquares(); // ey^2 = Sum of y^2 Get sum of squares from strongsums.txt.

// count1 =  long double getexysumofxtimesy(long long ex, long double ey); // exy = Sum of X times Y.

// count1 =  long double getyaverageofy(long double ey, long long samples); // get average of strong check sums

//     (n times (exy))-((ex) times (ey))
// b = --------------------------------     =  CALCULATE B
//      (n times (ex^2)) - ((ex)^2)
// count1 =  long double getB(long long samples, long long ex, long double ey, long long exsquared, long double eysquared, long double exy);

// to do:
// Put in root mean squares and standard deviations
// Put in decrypt functions
// Put in breaking strong check sum down into baby strong check sums and writing that to file.
// Put fire codes in here
// put in writing config files

// END KEY AND BEGIN FUNCTIONS HERE:
// WARNING - THIS IS VERY VERY VERY LONG.
// ======================================================================================================================
int loadconfig(string file1)
{ // Note make these variables global in your program
    string dummy;
    string file2;
    long double targetstrongchecksum;
    long long filesize1;
    long long howmanyweightedsums;
    int buffersize;
    long long weakchecksum;

// Load configure file
    fstream c1myfile(file1.c_str(), ios::in);
    c1myfile >>  dummy >> dummy >> dummy >> file2;
    // set precision
    c1myfile.precision(36);
    // strong check sum
    c1myfile >>  dummy >> dummy >> dummy >> targetstrongchecksum;
    // write file size
    c1myfile >>  dummy >> dummy >> dummy >> filesize1;
    // write how many weights
    c1myfile >>  dummy >> dummy >> dummy >> dummy >> howmanyweightedsums;
    // write buffersize
    c1myfile >>  dummy >> dummy >> buffersize;
    // write weak check-sum 
    c1myfile >>  dummy >> dummy >> weakchecksum;
    // close configure file
    c1myfile.close();
    c1myfile.clear();
    c1myfile.flush();
    return(0);
}
// ======================================================================================================================
int compare3(string file1, string file5, long long filesize1, int buffersize) // checks to see if completely different
{
     // declare variables
     int test = 1;
     int byte1 = 0;
     int byte2 = 0;
     int count1 = -1;
     long long begin1;
     long long begin2;
     string pause;
     unsigned char buffer(buffersize);
     long long countbytes = 0;               

     // open file1
     fstream myfile1(file1.c_str(), ios:: in | ios:: binary);
     if (!myfile1)
     {
          cout << "Error in line 1029.\n";
          cin >> pause;
          myfile1.close();
          myfile1.clear();
          myfile1.flush();
          exit(1); // terminate with error
      }

     // open file2
     fstream myfile2(file5.c_str(), ios::in | ios::binary);
     if (!myfile2)
     {
          myfile2.close();
          myfile2.clear();
          myfile2.flush();
          cout << "Failed to read file two in roll counter.\n";
          cin >> pause;
          exit(1);
     }


     // start do loop
     do
     {

         count1++;

         // read file 1
         myfile1.seekg(count1);
         myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
         begin1 = myfile1.tellg();
         byte1 = (int)buffer;
    
         // read file 2
         myfile2.seekg(count1);
         myfile2.read( reinterpret_cast<char*>( &buffer ),buffersize);
         begin2 = myfile2.tellg();
         byte2 = (int)buffer;

         // byte1 != byte2 then test = 1
         if (byte1 != byte2)
         {
             countbytes++;                        
         }

    // repeat loop
    } while(count1 < filesize1 - 1);
    
    if (countbytes >= filesize1 - 1)
    {
         test = 0;
    }
    // return test
    return(test);
}

// ======================================================================================================================
int compare2(string file1, string file5, long long filesize1, int buffersize) // checks to see if same
{
     // declare variables
     int test = 1;
     int byte1 = 0;
     int byte2 = 0;
     int count1 = -1;
     long long begin1;
     long long begin2;
     string pause;
     unsigned char buffer(buffersize);
     long long countbytes = 0;
     
     // open file1
     fstream myfile1(file1.c_str(), ios:: in | ios:: binary);
     if (!myfile1)
     {
          cout << "Error in line 1029.\n";
          cin >> pause;
          myfile1.close();
          myfile1.clear();
          myfile1.flush();
          exit(1); // terminate with error
      }

     // open file2
     fstream myfile2(file5.c_str(), ios::in | ios::binary);
     if (!myfile2)
     {
          myfile2.close();
          myfile2.clear();
          myfile2.flush();
          cout << "Failed to read file two in roll counter.\n";
          cin >> pause;
          exit(1);
     }


     // start do loop
     do
     {

         count1++;

         // read file 1
         myfile1.seekg(count1);
         myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
         begin1 = myfile1.tellg();
         byte1 = (int)buffer;
    
         // read file 2
         myfile2.seekg(count1);
         myfile2.read( reinterpret_cast<char*>( &buffer ),buffersize);
         begin2 = myfile2.tellg();
         byte2 = (int)buffer;

         // byte1 != byte2 then test = 1
         if (byte1 == byte2)
         {
              countbytes++;               
         }

    // repeat loop
    } while(count1 < filesize1 - 1);
    
    if (countbytes >= filesize1 - 1)
    {
         test = 0;
    }
    // return test
    return(test);
}
// ======================================================================================================================
int checklockfile(string lockfile)
{
    // check lock file
    fstream c1myfile6(lockfile.c_str(), ios::in);
    if (!c1myfile6)
    {
          c1myfile6.close();
          c1myfile6.clear();
          c1myfile6.flush();
          exit(0);
    } 
    c1myfile6.close();
    c1myfile6.clear();
    c1myfile6.flush();

     return(0);
}
// ======================================================================================================================
int createsizefile(string file1, long long filesize1, int buffersize)
{

     string pause;
     long long count1 = -1;
     unsigned char buffer;
     long long begin1;
     int byte1 = 0;

    // open file1
     fstream myfile1(file1.c_str(), ios::out | ios::binary);
     if (!myfile1)
     {
          myfile1.close();
          cout << "Failed to read file one.\n";
          cin >> pause;
          exit(1);
     }

     count1 = -1;
     do
     {
          count1++;     
          buffer = (unsigned char)byte1;
          myfile1.seekp(count1);
          myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellp();

     } while(count1 < filesize1 - 1);

     myfile1.close();
     myfile1.clear();
     myfile1.flush();


}
// ======================================================================================================================
int rollcounter2(string file1, string file2, string file5, int buffersize, long long filesize1)// miss parts of expC and conC that are equal.
{
     // declare variables
     int carry;
     long long count1 = -1;
     long long count2 = -1;
     unsigned char buffer(buffersize);
     long long begin1 = 0;
     long long begin2 = 0;
     long long begin3 = 0;
     long long end1 = 0;
     long long end2 = 0;
     long long end3 = 0;
     long long filesize2 = 0;
     int byte1 = 0;
     int byte2 = 0;
     int byte3 = 0;
     int byte4 = 0;
     string pause;

     // open file1 in/out this is the experimental counter
     fstream myfile1(file1.c_str(), ios:: in | ios:: out | ios:: binary);
     if (!myfile1)
     {
          cout << "Error in line 1029.\n";
          cin >> pause;
          myfile1.close();
          myfile1.clear();
          myfile1.flush();
          exit(1); // terminate with error
      }

     // open file2 in this is the speed
     fstream myfile2(file2.c_str(), ios::in | ios::binary);
     if (!myfile2)
     {
          myfile2.close();
          myfile2.clear();
          myfile2.flush();
          cout << "Failed to read file two in roll counter.\n";
          cin >> pause;
          exit(1);
     }

     // open file3 in this is the control counter
     fstream myfile3(file5.c_str(), ios::in | ios::binary);
     if (!myfile3)
     {
          myfile3.close();
          myfile3.clear();
          myfile3.flush();
          cout << "Failed to read file three line 219 in roll counter2.\n";
          cin >> pause;
          exit(1);
     }

     // Get filesize 2
     begin2 = myfile2.tellg();
     if (!myfile2)
     {
          myfile2.close();
	  myfile2.clear();
	  myfile2.flush();
          cout << "Failed to read file two.\n";
          cin >> pause;
          exit(1);
     }

     myfile2.seekg (0, ios::end);
     end2 = myfile2.tellg();
     filesize2 = (end2-begin2);

     // set carry to 0
     carry = 0;

     // set count1 to -1
     count1 = -1;

     // start do loop
     do
     {
         // increment count1
         count1++;

         // set byte1, byte2, byte3, byte4 to zero
         byte1 = 0; byte2 = 0; byte3 = 0; byte4 = 0;

         // read file 1
          myfile1.seekg(count1);
          myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellg();
          byte1 = (int)buffer;

         // if (count1 < filesize2 - 1) then read file 2
          if (count1 < filesize2 - 1)
          {
               myfile2.seekg(count1);
               myfile2.read( reinterpret_cast<char*>( &buffer ),buffersize);
               begin2 = myfile2.tellg();
               byte2 = (int)buffer;
          }

          // read file 3
          myfile3.seekg(count1);
          myfile3.read( reinterpret_cast<char*>( &buffer ),buffersize);
          begin3 = myfile3.tellg();
          byte3 = (int)buffer;


         // add file 1 + file 2 + carry
         if (byte1 != byte3)
         {

              if (carry == 1)
              {
                   byte4 = byte2 + byte1 + carry;
                   carry = 0;
                   goto jump;
              } 

         }
         
         if (byte1 != byte3)
         {

              if (carry == 0)
              {
                   byte4 = byte2 + byte1;
              }

         }
jump:
         // if file1 + file2 + carry => base subtract the base and set carry to 1 else carry = 0
         if (byte4  >= 256)
         {
              byte4 = byte4 - 256;
              carry = 1;
         }

         // if file1 does equal file 3 then write product to file. This is the pendulum algorithm in action.
         if (byte1 != byte3)
         {
              buffer = (unsigned char)byte4;
              myfile1.seekp(count1);
              myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
              begin1 = myfile1.tellp();

         }  

     // end do loop
     } while (count1 < filesize1 - 1);

     // close files
     myfile1.close();
     myfile1.clear();
     myfile1.flush();
     myfile2.close();
     myfile2.clear();
     myfile2.flush();
     myfile3.close();
     myfile3.clear();
     myfile3.flush();

     // return 0
     return(carry);
         
}
// ======================================================================================================================
int rollcounter1(string file1, string file2, int buffersize, long long filesize1)
{

     // declare variables
     int carry = 0;
     long long count1 = -1;
     long long count2 = -1;
     unsigned char buffer(buffersize);
     long long begin1 = 0;
     long long begin2 = 0;
     long long end1 = 0;
     long long end2 = 0;
     long long filesize2 = 0;
     int byte1 = 0;
     int byte2 = 0;
     int byte3 = 0;
     string pause;

     // open file1
     fstream myfile1(file1.c_str(), ios:: in | ios:: out | ios:: binary);
     if (!myfile1)
     {
          cout << "Error in line 1029.\n";
          cin >> pause;
          myfile1.close();
          myfile1.clear();
          myfile1.flush();
          exit(1); // terminate with error
      }

     // open file2
     fstream myfile2(file2.c_str(), ios::in | ios::binary);
     if (!myfile2)
     {
          myfile2.close();
          myfile2.clear();
          myfile2.flush();
          cout << "Failed to read file two in roll counter.\n";
          cin >> pause;
          exit(1);
     }

     // Get filesize 2
     begin2 = myfile2.tellg();
     if (!myfile2)
     {
          myfile2.close();
	  myfile2.clear();
	  myfile2.flush();
          cout << "Failed to read file two.\n";
          cin >> pause;
          exit(1);
     }

     myfile2.seekg (0, ios::end);
     end2 = myfile2.tellg();
     filesize2 = (end2-begin2);

    // set carry to 0
     carry = 0;
     count1 = -1;
     do
     {

// addint file2 to file1
         count1++;

         byte1 = 0;
         byte2 = 0;
     
          // read file 1
          myfile1.seekg(count1);
          myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellg();
          byte1 = (int)buffer;

          // if (count1 < filesize2 - 1) then read file 2
          if (count1 < filesize2 - 1)
          {
               myfile2.seekg(count1);
               myfile2.read( reinterpret_cast<char*>( &buffer ),buffersize);
               begin2 = myfile2.tellg();
               byte2 = (int)buffer;
          }


          // add file 1 + file 2 + carry
          byte2 = byte2 + byte1 + carry;

          carry = 0;

          // if file1 + file2 + carry => base subtract the base and set carry to 1 else carry = 0
          if (byte2  >= 256)
          {
               byte2 = byte2 - 256;
               carry = 1;
          }

          // write product to counter file
          buffer = (unsigned char)byte2;
          myfile1.seekp(count1);
          myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellp();

     } while (count1 < filesize1 - 1);
     
     // close files
     myfile1.close();
     myfile1.clear();
     myfile1.flush();
     myfile2.close();
     myfile2.clear();
     myfile2.flush();

     return(carry);

}
// ======================================================================================================================
int createemptyfile(string file1)
{

     string pause;
    // open file1
     fstream myfile1(file1.c_str(), ios::out | ios::binary);
     if (!myfile1)
     {
          myfile1.close();
          cout << "Failed to read file one.\n";
          cin >> pause;
          exit(1);
     }


     myfile1.close();
     myfile1.clear();
     myfile1.flush();

}
// ======================================================================================================================
int createchecksum(string file1, long long cksum, long long filesize1, int buffersize, int base)
{
     long long count1 = 0;
     long long count2 = 0;
     long long checksum = cksum;
     unsigned char buffer(buffersize);
     long long begin1 = 0;
     string pause;

// open file
// open file1
     fstream myfile1(file1.c_str(), ios::out  | ios::binary);
     if (!myfile1)
     {
          myfile1.close();
          cout << "Failed to read file one.\n";
          cin >> pause;
          exit(1);
     }

     // write to file while subtracting from checksum use loops

     int byte1 = base - 1;
     count1 = 0;
     do
     {
          if (checksum - byte1 > 0)
          {
               checksum = checksum - byte1;
               goto ln667;
          }

          if (checksum - byte1 <= 0)
          {
              byte1 = checksum;
              checksum = 0;

          }
ln667:
          buffer = (unsigned char)byte1;
          myfile1.seekp(count1);
          myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellp();

          if (checksum == 0)
          {
               byte1 = 0;
          }

          count1 = count1 + buffersize;

     } while(checksum > 0);
     myfile1.close();
     myfile1.clear();
     myfile1.flush();
     return(0);
}
// ======================================================================================================================
int carrytest(string file1, int buffersize, int base, long long filesize2)
{ // Debugged

     string pause;
     long long count;
     unsigned char buffer;
     long long begin1;
     int byte1;

//     open file1
     fstream myfile1(file1.c_str(), ios::in | ios::binary);
     if (!myfile1)
     {
          myfile1.close();
          cout << "Failed to read file one in carrytest line 22.\n";
          cin >> pause;
          exit(1);
     }

	 count = (filesize2 * 2); // REMBER ALWAYS FILESIZE - 1

//	 read file1
     myfile1.seekg(count);
     myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
     begin1 = myfile1.tellg();
	 byte1 = (int)buffer;


//	 can we add 1 to it
//	 if so return 0
//	 if not return 1
     if (byte1 < (base - 1))
     {
         return(0);

     }
     else
     {
         return(1);
     }
}
// ======================================================================================================================
int addcarry(string file1, int buffersize, int base, long long filesize1)
{ // debugged
//	Don't know yet figure it out. I guess we are adding 1. Go with that for now.
//	(filesize2 * 2) - 2 I think add 1. Go back and read all the code
//	set count
    long long count;
    string pause;
    unsigned char buffer;
    long long begin1;
    int byte1;

	count = (filesize1 * 2);
//	open file 1
     fstream myfile1(file1.c_str(), ios::out | ios::in | ios::binary);
     if (!myfile1)
     {
          myfile1.close();
          cout << "Failed to read file one in addcarry line 27.\n";
          cin >> pause;
          exit(1);
     }

//	read byte at count
	 myfile1.seekg(count);
     myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
     begin1 = myfile1.tellg();
	 byte1 = (int)buffer;


//	add 1 byte at count
	byte1 = byte1 + 1;

//	write byte back at count
    buffer = (unsigned char)byte1;
    myfile1.seekp(count);
    myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
    begin1 = myfile1.tellp();

//	close file 1
    myfile1.close();
    myfile1.clear();
    myfile1.flush();

    return(0);
}
// ======================================================================================================================
int swap(string file1, int buffersize, int base, long long filesize1, long long filesize2)
{ // change files between sections
//     copy subtraction section to tempfile1
//     set names of files

     long long count1;
     long long count2;
     long long begin1;
     long long begin2;
     string pause;
     unsigned char buffer;
     int byte1;
     string file2;
     fstream myfile1;
     fstream myfile2;

	 file2 = "tempfile1.bin";
	 count2  = (filesize2 * 2) - 1;
     count1 = -1;
//	 set counts from where coping
//	      open file1
	 myfile1.open(file1.c_str(), ios::in | ios::binary);
     if (!myfile1)
     {
          myfile1.close();
          cout << "Failed to read file one in swap line 69.\n";
          cin >> pause;
          exit(1);
     }

//		  open file2
	 myfile2.open(file2.c_str(), ios::out | ios::binary);
     if (!myfile2)
     {
          myfile2.close();
          cout << "Failed to read file one in swap line 78.\n";
          cin >> pause;
          exit(1);
     }

//		  start loop
	 do
	 {

//             increment count
          count1++;

//		       read file1
          myfile1.seekg(count1);
          myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellg();
		  byte1 = (int)buffer;

//		  cout << " byte1 " << byte1 << "\n";
//          cout << " count1 " << count1 << "\n";
//          cout << " filesize1 " << filesize1 << "\n";
//          cin >> pause;

//			   write file2
		  buffer = (unsigned char)byte1;
          myfile2.seekp(count1);
          myfile2.write( reinterpret_cast<char*>( &buffer ),buffersize);
          begin2 = myfile2.tellp();

//		  end loop
     } while (count1 < count2);

//		  close files
	 myfile1.close();
     myfile2.close();
     myfile1.clear();
     myfile2.clear();
	 myfile1.flush();
	 myfile2.flush();

//   copy subtract to add
//	 set names of files
//   set counts where copying
	 file1 = "tempfile1.bin";
	 file2 = "counter.bin";
	 count2  = filesize2 - 1;
     count1 =  -1;

//	 open file1
	 myfile1.open(file1.c_str(), ios::in | ios::binary);
     if (!myfile1)
     {
          myfile1.close();
          cout << "Failed to read file one in swap line 69.\n";
          cin >> pause;
          exit(1);
     }

//	 open file2
     myfile2.open(file2.c_str(), ios::out | ios::in | ios::binary);
     if (!myfile2)
     {
          myfile2.close();
          cout << "Failed to read file two in copy to counter.bin " << "\n";
          cin >> pause;
          exit(0);
     }

//    start loop
	 do
	 {
//	     increment count
		  count1++;
		  count2++;

//               read file1
          myfile1.seekg(count1);
          myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellg();
          byte1 = (int)buffer;

// cout << " byte1 " << byte1 << "\n";
//cout << " count1 " << count1 << "\n";
//cout << " filesize1 " << filesize1 << "\n";
//cin >> pause;
//myfile1.close();
//myfile2.close();
//myfile1.clear();
//myfile2.clear();
//myfile1.flush();
//myfile2.flush();
//return(0);

//			   write file2
          buffer = (unsigned char)byte1;
          myfile2.seekp(count2);
          myfile2.write( reinterpret_cast<char*>( &buffer ),buffersize);
          begin2 = myfile2.tellp();

//	  end loop
	 } while (count1 < (filesize2 - 1));

//	close files
	 myfile1.close();
     myfile2.close();
     myfile1.clear();
     myfile2.clear();
	 myfile1.flush();
	 myfile2.flush();

//	 copy add to subtract section
//	 set names of files
//	 set counts where copying
	 file1 = "tempfile1.bin";
	 file2 = "counter.bin";
	 count1 = filesize2 - 1;
     count2 = -1;

//	 open file1
	 myfile1.open(file1.c_str(), ios::in | ios::binary);
     if (!myfile1)
     {
          myfile1.close();
          cout << "Failed to read file one in swap line 69.\n";
          cin >> pause;
          exit(1);
     }

//	 open file2
     myfile2.open(file2.c_str(), ios::out | ios::in | ios::binary);
     if (!myfile2)
     {
          myfile2.close();
          cout << "Failed to read file one in swap line 78.\n";
          cin >> pause;
          exit(1);
     }

//    start loop
	 do
	 {
//	     increment count
		  count1++;
		  count2++;
//		       read file1
          myfile1.seekg(count1);
          myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellg();
          byte1 = (int)buffer;

//          cout << " byte1 " << byte1 << "\n";
//          cout << " count1 " << count1 << "\n";
//          cout << " filesize1 " << filesize1 << "\n";
//          cin >> pause;

//			   write file2
          buffer = (unsigned char)byte1;
          myfile2.seekp(count2);
          myfile2.write( reinterpret_cast<char*>( &buffer ),buffersize);
          begin2 = myfile2.tellp();

//	  end loop
	 } while (count2 < (filesize2 - 1));

//	close files
	 myfile1.close();
     myfile2.close();
     myfile1.clear();
     myfile2.clear();
	 myfile1.flush();
	 myfile2.flush();

//	 del tempfile1
	 system("rm tempfile1.bin");

//	del tempfile2
	 // system("del tempfile1.bin");

	 return(0);
}
// ======================================================================================================================
int compare(string file1, string file2, int buffersize, int base, long long s1f1, long long s2f2, long long e1f1, long long e2f2 )
{
// This subroutine will compare two sections of the same or two different files and tell which section is larger in base math
// if compare is 0 file 1 is larger
// if compare is 1 file 2 is larger
// if compare is -1 file 1 and file 2 is the same size
// The sections of two files being compared must be giving the begging and ending file pointers.

 // open file1
     string pause;
     long long begin1;
     long long end1;
     long long filesize1;
     long long begin2;
     long long end2;
     long long filesize2;
     long long sizeofsection1;
     long long sizeofsection2;
     long long fposition1;
     long long fposition2;
     unsigned char buffer;
     int byte1;
     int byte2;
     int compare;

     fstream myfile1(file1.c_str(), ios:: in | ios:: binary);
     if (!myfile1)
     {
          cout << "Error in line 203.\n";
          cin >> pause;
          myfile1.close();
          myfile1.clear();
		  myfile1.flush();
          exit(1); // terminate with error
     }

     // open file2
     fstream myfile2(file2.c_str(), ios::in | ios::binary);
     if (!myfile2)
     {
          cout << "Error in line 203.\n";
          cin >> pause;
          myfile2.close();
          myfile2.clear();
		  myfile2.flush();
          exit(1); // terminate with error
     }


// get filesize1
     begin1 = myfile1.tellg();
     if (!myfile1)
     {
          myfile1.close();
		  myfile1.clear();
		  myfile1.flush();
          cout << "Failed to read file one.\n";
          cin >> pause;
          exit(1);
     }
     myfile1.seekg (0, ios::end);
     end1 = myfile1.tellg();
     filesize1 = (end1-begin1);


//get size file 2
     begin2 = myfile2.tellg();
     if (!myfile2)
     {
          myfile2.close();
		  myfile2.clear();
		  myfile2.flush();
          cout << "Failed to read file one.\n";
          cin >> pause;
          exit(1);
     }
     myfile2.seekg (0, ios::end);
     end2 = myfile2.tellg();
     filesize2 = (end2-begin2);


// byte starting point for file 1
// giving by calling routine

// byte starting point for file 2
// giving by calling routine

// byte ending point for file 1
// giving by calling routine

// byte ending point for file 2
// giving by calling routine

// calulate size of section file 1
sizeofsection1 =  e1f1 - s1f1;

// calulate size of section file 2
sizeofsection2 =  e2f2 - s2f2;

// last largest number file 1 read the file

	  // read file
      myfile1.seekg(e1f1);
      myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
      begin1 = myfile1.tellg();
      byte1 = (int)buffer;

// last largest number file 2 read the file

	  // read file
      myfile2.seekg(e2f2);
      myfile2.read( reinterpret_cast<char*>( &buffer ),buffersize);
      begin2 = myfile2.tellg();
      byte2 = (int)buffer;

// if size of file 1 > file 2 file one larger and return
     if (sizeofsection1 > sizeofsection2)
	 {
	 	compare = 0;
        myfile1.close();
		myfile1.clear();
		myfile1.flush();
        myfile2.close();
	    myfile2.clear();
	    myfile2.flush();
        return(compare);

	 }

// if size of file 2 < file 1 file two larger and return
     if (sizeofsection1 < sizeofsection2)
	 {
	 	compare = 1;
        myfile1.close();
		myfile1.clear();
		myfile1.flush();
        myfile2.close();
	    myfile2.clear();
	    myfile2.flush();
        return(compare);

	 }


// if size of file 1 == file 2 and file 1 number larger file 1 larger and return
     if (sizeofsection1 == sizeofsection2)
	 {
	      if (byte1 > byte2)
		  {
		      compare = 0;
			  myfile1.close();
		      myfile1.clear();
		      myfile1.flush();
              myfile2.close();
	          myfile2.clear();
	          myfile2.flush();
              return(compare);

		  }

	 }


// if size of file 1 == file 2 and file 2 number larger file 2 larger and return

     if (sizeofsection1 == sizeofsection2)
	 {
	      if (byte1 < byte2)
		  {
		      compare = 1;
			  myfile1.close();
		      myfile1.clear();
		      myfile1.flush();
              myfile2.close();
	          myfile2.clear();
	          myfile2.flush();
              return(compare);

		  }

	 }

// if size of file 1 == file 2 and file 1 number == file 2 number then start loop and compare both files
// until find largest number and if they are equal then file 1 and file 2 are equal

     if (sizeofsection1 == sizeofsection2)
	 {
	      if (byte1 ==  byte2)
		  {
		     // set file position to ending number + 1 for file1
			  fposition1 = e1f1 + 1;
			 // set file position to ending number + 1 for file2
			  fposition2 = e2f2 + 1;
			  // start do loop
			  do
			  {
			       fposition1--;
			       fposition2--;


			 // read byte 1
                  myfile1.seekg(fposition1);
                  myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
                  begin1 = myfile1.tellg();
                  byte1 = (int)buffer;

		    // read byte 2
		          myfile2.seekg(fposition2);
                  myfile2.read( reinterpret_cast<char*>( &buffer ),buffersize);
                  begin2 = myfile2.tellg();
                  byte2 = (int)buffer;

		     // if byte 1 larger set compare to 0 close and return
			      if (byte1 > byte2)
				  {
            		   compare = 0;
                       myfile1.close();
		               myfile1.clear();
		               myfile1.flush();
                       myfile2.close();
	                   myfile2.clear();
	                   myfile2.flush();
                       return(compare);
                  }
			 // if byte 2 larger set compare to 1 close and return
			      if (byte1 < byte2)
				  {
            		   compare = 1;
                       myfile1.close();
		               myfile1.clear();
		               myfile1.flush();
                       myfile2.close();
	                   myfile2.clear();
	                   myfile2.flush();
                       return(compare);
                  }


			 // finish loop
			  } while(fposition1 != 0);
			  // set compare to -1 close and return
			           compare = -1;
                       myfile1.close();
		               myfile1.clear();
		               myfile1.flush();
                       myfile2.close();
	                   myfile2.clear();
	                   myfile2.flush();
                       return(compare);

		  }

	 }
}
// ======================================================================================================================
int writesweakchecksumfile(string file1, string file2) // Gets the weak check sum of a file and writes the weak check sum as a file doing the math by 
{ // hand
}
// ======================================================================================================================
int writestrongchecksumfile(string file1, string file2) // Gets the strong check sum of a file and writes the strong check sum as a file doing the math by 
{ // hand
}
// ======================================================================================================================
int multiply1(string file1, string file2, int buffersize, int base, int num)
{
     int byte1;
     string pause;
     long long begin1;
     long long end1;
     long long filesize1;
     int carry;
     long long count;
     unsigned char buffer(buffersize);
     int result;
     long long begin2;

	 // open file1

     fstream myfile1(file1.c_str(), ios:: in | ios:: binary);
     if (!myfile1)
     {
          cout << "Error in line 203.\n";
          cin >> pause;
          myfile1.close();
          myfile1.clear();
		  myfile1.flush();
          exit(1); // terminate with error
      }

      fstream myfile2(file2.c_str(), ios:: out | ios:: binary);
      if (!myfile2)
      {
           cout << "Error in line 46.\n";
           cin >> pause;
           myfile2.close();
           myfile2.clear();
		   myfile2.flush();
           exit(1); // terminate with error
       }


// get filesize1
     begin1 = myfile1.tellg();
     if (!myfile1)
     {
          myfile1.close();
		  myfile1.clear();
		  myfile1.flush();
          cout << "Failed to read file one.\n";
          cin >> pause;
          exit(1);
     }

     myfile1.seekg (0, ios::end);
     end1 = myfile1.tellg();
     filesize1 = (end1-begin1);

//     start loop
     carry = 0;
     count = -1;
     do
     {
           count++;
           // read file
           myfile1.seekg(count);
           myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
           begin1 = myfile1.tellg();
           byte1 = (int)buffer;

     // multiply number
          result = (byte1 * num);

     // add carry from previous result
          result = result + carry;

     // reset carry after using it
          carry = 0;

     if (result > (base - 1))
     {

          // convert base
          carry = int(result/base);
          result = result - (int(result/base) * base);

     }

     //Write file
     buffer = (unsigned char)result;
     myfile2.seekp(count);
     myfile2.write( reinterpret_cast<char*>( &buffer ),buffersize);
     begin2 = myfile2.tellp();
     result = 0;

     } while (count < (filesize1 - 1));

     if (carry > 0)
     {
          count++;
          buffer = (unsigned char)carry;
          myfile2.seekp(count);
          myfile2.write( reinterpret_cast<char*>( &buffer ),buffersize);
          begin2 = myfile2.tellp();
     }
     myfile1.close();
     myfile1.clear();
     myfile1.flush();
     myfile2.close();
     myfile2.clear();
     myfile2.flush();

     return(0);
}
// ======================================================================================================================
int dividefiles(string file1, string file2, string file3) // division of two files in binary
{
}
// ======================================================================================================================
int subtract1(string file1, string file2, string file3, long long filesize1, long long filesize2, int buffersize, int base, long long bpos1, long long bpos2, long long epos1, long long epos2) // I may want to look at rewriting this.
{

     // declare variables
     int carry;
     long long count1 = bpos1;
	 long long count2 = bpos2;
     unsigned char buffer(buffersize);
     long long begin1;
     long long begin2;
     long long begin3;
     int byte1;
     int byte2;
     int byte3;
     string pause;


//     cout << "We are in roll counter forward\n";
//     cin >> pause;

     // open file1

     fstream myfile1(file1.c_str(), ios:: in | ios:: binary);
     if (!myfile1)
     {
          cout << "Error in line 41.\n";
          cin >> pause;
          myfile1.close();
          myfile1.clear();
          exit(1); // terminate with error
      }

     // open file2
     fstream myfile2(file2.c_str(), ios::in | ios::binary);
     if (!myfile2)
     {
          myfile2.close();
          cout << "Failed to read file line 53.\n";
          cin >> pause;
          exit(1);
     }

     //open file3
     fstream myfile3(file3.c_str(), ios::out | ios::binary);
     if (!myfile3)
     {
          myfile3.close();
          cout << "Failed to read file line 64.\n";
          cin >> pause;
          exit(1);
     }




    // set carry to 0
     carry = 0;
     do
     {

// addint file2 to file1

          // read file 1
          myfile1.seekg(count1);
          myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellg();
          byte1 = (int)buffer;
//          cout << byte1 << " byte1\n";


          myfile2.seekg(count2);
          myfile2.read( reinterpret_cast<char*>( &buffer ),buffersize);
          begin2 = myfile2.tellg();
          byte2 = (int)buffer;

//          cout << byte2 << " byte2\n";

          // add file 1 + file 2 + carry
          byte3 = byte1 - byte2 - carry;
//          cout << byte3 << "byte3\n";
//          cout << carry << " carry\n";

//          cin >> pause;

          // if file1 + file2 + carry => base subtract the base and set carry to 1 else carry = 0
          if (byte3  < 0)
          {
               byte3 = byte3 + base;
               carry = 1;
//               cout << "base3 >=base\n";
//               cout << byte3 << carry << " byte3 >= base wiht carry\n ";
//               cin >> pause;
          }
          else
          {
               carry = 0;
          }

          // write remainder to file 1
          if (byte3 > (base - 1))
          {
               cout << "Houston we have a problem\n";
               cout << "Byte3 greater than the base - 1\n";
               cin >> pause;
               exit(0);
          }

          buffer = (unsigned char)byte3;
          myfile3.seekp(count1);
          myfile3.write( reinterpret_cast<char*>( &buffer ),buffersize);
          begin3 = myfile3.tellp();

          count1 = count1 + buffersize;
		  count2 = count2 + buffersize;
//          cout << "Wrote byte3 to file\n";
//          cin >> pause;

     } while (count1 < epos1) ;

     // close files
     myfile1.close();
     myfile2.close();
     myfile1.clear();
     myfile2.clear();
	 myfile1.flush();
	 myfile2.flush();
//     cout << "Leaving roll forward";
//     cin >> pause;
     // exit
     return(0);

}
// ======================================================================================================================
int add1(string file1, string file2, int buffersize)
{

     // declare variables
     int carry;
     long long count1 = -1;
     long long count2 = -1;
     long long count3 = -1;
     unsigned char buffer(buffersize);
     long long begin1 = 0;
     long long begin2 = 0;
     long long begin3 = 0;
     long long end1 = 0;
     long long end2 = 0;
     long long filesize1 = 0;
     long long filesize2 = 0;
     int byte1 = 0;
     int byte2 = 0;
     int byte3 = 0;
     string pause;
     fstream myfile1;
     string file3 = "tempfile3.bin";
     
     // open file1
     myfile1.open(file1.c_str(), ios:: in | ios:: binary);
     if (!myfile1)
     {
          cout << "Error in line 1029.\n";
          cin >> pause;
          myfile1.close();
          myfile1.clear();
          myfile1.flush();
          exit(1); // terminate with error
      }
      // Get filesize 1
     begin1 = myfile1.tellg();
     if (!myfile1)
     {
         myfile1.close();
	 myfile1.clear();
	 myfile1.flush();
         cout << "Failed to read file one.\n";
         cin >> pause;
         exit(1);
     }

     myfile1.seekg (0, ios::end);
     end1 = myfile1.tellg();
     filesize1 = (end1-begin1);

     // open file2
     fstream myfile2(file2.c_str(), ios::in | ios::binary);
     if (!myfile2)
     {
          myfile2.close();
          myfile2.clear();
          myfile2.flush();
          cout << "Failed to read file two in roll counter.\n";
          cin >> pause;
          exit(1);
     }

     // Get filesize 2
     begin2 = myfile2.tellg();
     if (!myfile2)
     {
          myfile2.close();
	  myfile2.clear();
	  myfile2.flush();
          cout << "Failed to read file two.\n";
          cin >> pause;
          exit(1);
     }

     myfile2.seekg (0, ios::end);
     end2 = myfile2.tellg();
     filesize2 = (end2-begin2);

     fstream myfile3(file3.c_str(), ios:: out | ios:: binary);
     if (!myfile3)
     {
          cout << "Error in line 210\n";
          cin >> pause;
          myfile3.close();
          myfile3.clear();
          myfile3.flush();
          exit(1); // terminate with error
     }

    // set carry to 0
     carry = 0;
     do
     {

// addint file2 to file1
         count1++;
	 count2++;

         byte1 = 0;
         byte2 = 0;
         byte3 = 0;
     
          // read file 1
          myfile1.seekg(count1);
          myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellg();
          byte1 = (int)buffer;

          if (count2 < filesize2 - 1)
          {
               myfile2.seekg(count2);
               myfile2.read( reinterpret_cast<char*>( &buffer ),buffersize);
               begin2 = myfile2.tellg();
               byte2 = (int)buffer;
          }
          else
          {
               byte2 = 0;
          }

          // add file 1 + file 2 + carry
          byte3 = byte2 + byte1 + carry;
          carry = 0;

          // if file1 + file2 + carry => base subtract the base and set carry to 1 else carry = 0
          if (byte3  >= 256)
          {
               byte3 = byte3 - 256;
               carry = 1;
          }
          else
          {
               carry = 0;
          }


          // write remainder to file 1
          if (byte3 > (256 - 1))
          {
               cout << "Houston we have a problem\n";
               cout << "Byte3 greater than the base - 1\n";
               cin >> pause;
               exit(0);
          }

          buffer = (unsigned char)byte3;
          myfile3.seekp(count3);
          myfile3.write( reinterpret_cast<char*>( &buffer ),buffersize);
          begin3 = myfile3.tellp();

     } while (count1 < filesize1 - 1);

     if (carry > 0)
     {
          buffer = (unsigned char)carry;
          myfile3.seekp(count3);
          myfile3.write( reinterpret_cast<char*>( &buffer ),buffersize);
          begin3 = myfile3.tellp();
     }

     // close files
     myfile1.close();
     myfile2.close();
     myfile3.close();
     myfile1.clear();
     myfile2.clear();
     myfile3.clear();
     myfile1.flush();
     myfile2.flush();
     myfile3.flush();

     return(0);

}
// ======================================================================================================================
int add2(string file1, string file2, string file3, long long filesize1, long long filesize2, int buffersize, int base, long long bpos1, long long bpos2, long long epos1, long long epos2)
{

     // declare variables
     int carry;
     long long count1 = bpos1;
	 long long count2 = bpos2;
	 long long count3 = bpos1;
     unsigned char buffer(buffersize);
     long long begin1;
     long long begin2;
     long long begin3;
     int byte1;
     int byte2;
     int byte3;
     string pause;
//     fstream myfile1;
//     string file3 = "tempfile3.bin";

//     cout << "We are in roll counter forward\n";
//     cin >> pause;

     // open file1

     fstream myfile1(file1.c_str(), ios:: in | ios:: out | ios:: binary);
     if (!myfile1)
     {
          cout << "Error in line 1216.\n";
          cin >> pause;
          myfile1.close();
          myfile1.clear();
          myfile1.flush();
          exit(1); // terminate with error
      }

     // open file2
     fstream myfile2(file2.c_str(), ios::in | ios::binary);
     if (!myfile2)
     {
          myfile2.close();
          myfile2.clear();
          myfile2.flush();
          cout << "Error in line 1231.\n";
          cin >> pause;
          exit(1);
     }

 //    fstream myfile3(file3.c_str(), ios:: out | ios:: binary); <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Elimate this fix it
 //    if (!myfile3)
 //    {
 //         cout << "Error in line 210\n";
 //         cin >> pause;
 //         myfile3.close();
 //         myfile3.clear();
 //         myfile3.flush();
 //         exit(1); // terminate with error
 //    }


    // set carry to 0
     carry = 0;
     do
     {


          // read file 1
          myfile1.seekg(count1);
          myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellg();
          byte1 = (int)buffer;

// cout << " count2 " << count2 << " " << " epos2 " << epos2 << "\n";
// cout << byte1 << " byte1\n";
// cin >> pause;
// exit(0);

          if (count2 < epos2 + buffersize)
          {
               myfile2.seekg(count2);
               myfile2.read( reinterpret_cast<char*>( &buffer ),buffersize);
               begin2 = myfile2.tellg();
               byte2 = (int)buffer;
          }
          else
          {
               byte2 = 0;
          }
          // add file 1 + file 2 + carry
          byte3 = byte2 + byte1 + carry;

// cout << byte3 << "byte3\n";
// cout << byte2 << "byte2\n";
// cout << byte1 << "byte1\n";
// cout << carry << " carry\n";
// cin >> pause;
// exit(0);
          // if file1 + file2 + carry => base subtract the base and set carry to 1 else carry = 0
          if (byte3  >= base)
          {
               byte3 = byte3 - base;
               carry = 1;
//               cout << "base3 >=base\n";
//               cout << byte3 << carry << " byte3 >= base wiht carry\n ";
//               cin >> pause;
          }
          else
          {
               carry = 0;
          }


          // write remainder to file 1
          if (byte3 > (base - 1))
          {
               cout << "Houston we have a problem\n";
               cout << "Byte3 greater than the base - 1\n";
               cin >> pause;
               exit(0);
          }

          buffer = (unsigned char)byte3;
          myfile1.seekp(count3);
          myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellp();


// addint file2 to file1
          count1 = count1 + buffersize;
		  count2 = count2 + buffersize;
		  count3 = count3 + buffersize;

//          cout << "Wrote byte3 to file\n";
//          cin >> pause;
     } while (count1 < epos1 + buffersize);

     if (carry > 0) // We do a carry test but this may need to be removed. There should be no carry here.
     {
          buffer = (unsigned char)carry;
          myfile1.seekp(count3);
          myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellp();
     }

     // close files
     myfile1.close();
     myfile2.close();
 //    myfile3.close();
     myfile1.clear();
     myfile2.clear();
 //    myfile3.clear();
	 myfile1.flush();
	 myfile2.flush();
 //	 myfile3.flush();

//     cout << "Leaving roll forward";
//     cin >> pause;
     // exit
     return(0);

}
// ======================================================================================================================
int backupcounter() // Edit this as needed
{
    system("rm counterbak.bin"); 
    system("cp counter.bin counterbak.bin");
}
// ======================================================================================================================
int restorecounter(string file1, string file2) // Edit as needed
{
     system("rm counter.bin");
     system("cp counterbak.bin counter.bin");
}
// ======================================================================================================================
int createrandomcounter1(string file1, long long filesize1, int buffersize) // This is done randomly so this can be run in parallel use. Do not use random.bin here. Use computer for numbers. file 1 is the random.bin file. file2 is the speed.bin file
{ // THIS IS NOT FINISHED YET. FINISH IT!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

     string pause;
     long long a = 3;
     long long c = 2361;
     long long m = 999999;
     long long k = 0;
     long long r = 0;
     srand((unsigned int) 5654940);
     time_t seconds;
     long long count1 = -1;
     long long count2 = 0;
     int byte1 = 0;
     unsigned char buffer(buffersize);
     long long begin1;
     

    // open file1
    fstream myfile1(file1.c_str(), ios::out | ios::binary);
    if (!myfile1)
    {
         myfile1.close();
         cout << "Failed to read file one Line 141.\n";
         cin >> pause;
         exit(1);
    }

    do
    {
         // increment count
         count1++;
// generate random bytes
         time(&seconds);
         k = (rand() % 429940833);
         k = k + seconds; 
         byte1 = (a * k + c) % (int)256;     
 
     // Write random file write here
         buffer = (unsigned char)byte1;
         myfile1.seekp(count1);
         myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
         begin1 = myfile1.tellp();


    } while(count1 < filesize1 - 1);

     // close file
     myfile1.close();
     myfile1.clear();
     myfile1.flush();
     return(0);
}
// ======================================================================================================================
long long setspeedrandom1(long long randfileposition, string file3, string file2, int buffersize, long long filesize1) 
{ 
    long long count1 = -1;
    long long count2 = -1;
    int byte1;
    long long begin1 = 0;
    long long begin2 = 0;
    long long end1 = 0;
    unsigned char buffer(buffersize);
    char pause;

    system("rm random.bin");
    system("./generaterandomnumbers 1000"); // this should always be greater then the file size to keep a steady stream of numbers.

    // open random.bin file 1
    // open file1
    fstream myfile1(file3.c_str(), ios::in | ios::binary);
    if (!myfile1)
    {
         myfile1.close();
         cout << "Failed to read file one Line 1423.\n";
         cin >> pause;
         exit(1);
    }

    // open speed.bin
    fstream myfile2(file2.c_str(), ios::out | ios::binary);
    if (!myfile2)
    {
         myfile2.close();
         cout << "Failed to read file one Line 1434.\n";
         cin >> pause;
         exit(1);
    }

    count1 = -1;
    count2 = -1; 
    // start main loop
    do
    {
         count1++;
         count2++;
 
         // read random.bin
         myfile1.seekg(count1);
         myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
         begin1 = myfile1.tellg();
         byte1 = (int)buffer;

         // copy to speed.bin
         buffer = (unsigned char)byte1;
         myfile2.seekp(count2);
         myfile2.write( reinterpret_cast<char*>( &buffer ),buffersize);
         begin2 = myfile2.tellp();
         
    } while(count1 < randfileposition);

    if (randfileposition >= filesize1 - 1)
    {
         randfileposition = -1;
    }

    randfileposition++;

   
    return(randfileposition);
}
// ======================================================================================================================
int viewfile1(string file1, int buffersize, long long filesize1)
{
// declare variables
    int count = -1;
    int byte1 = 0;
    long long begin1 = 0;
    long long end1 = 0;
    unsigned char buffer(buffersize);
    string pause;
    long long filesize3;

// open file 1
     fstream myfile1(file1.c_str(), ios:: in | ios:: binary);
     if (!myfile1)
     {
          cout << "Error in line 1608 view file.\n";
          cin >> pause;
          myfile1.close();
          myfile1.clear();
          myfile1.flush();
	  exit(1); // terminate with error
     }

      // Get filesize 1
     begin1 = myfile1.tellg();
     if (!myfile1)
     {
         myfile1.close();
	 myfile1.clear();
	 myfile1.flush();
         cout << "Failed to read file one.\n";
         cin >> pause;
         exit(1);
     }

     myfile1.seekg (0, ios::end);
     end1 = myfile1.tellg();
     filesize3 = (end1-begin1);

// read file view output  
     count = -1; 
     do
     {
          count++;

         // read file 1
          myfile1.seekg(count);
          myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellg();
          byte1 = (int)buffer;
	  cout << " count " << count << " " << " byte " << byte1 << "\n";

      } while (count < filesize3 - 1);

// close file1
      myfile1.close();
      myfile1.clear();
      myfile1.flush();

      return(0);
}
// ======================================================================================================================
int binaryreadwrite(string whatdo, string file1, long long byteposition, int byte, int buffersize)
{

     unsigned char buffer(buffersize);
     char pause;
     int byte1 = byte;
     long long count1 = byteposition;
     long long begin1;
     
       
     // open file
      fstream myfile1(file1.c_str(), ios::out  | ios::in | ios::binary);
     if (!myfile1)
     {
          myfile1.close();
          cout << "error in line 266" << " " << file1 << "\n";
          cin >> pause;
          exit(1);
     }
     if (whatdo == "read")
     {
// cout << byte1 << " We are reading bytes " << "\n"; // debug code
          myfile1.seekg(count1);
          myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellg();
          byte1 = (int)buffer;
          myfile1.close();
          myfile1.clear();
          myfile1.flush();
          return(byte1);
     }
     if (whatdo == "write")
     {
// cout << byte1 << " We are writing bytes " << "\n"; // debug code
          buffer = (unsigned char)byte1;
          myfile1.seekp(count1);
          myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellp();
          myfile1.close();
          myfile1.clear();
          myfile1.flush();
          return(0);
     } 
     

     cout << "Error in binary read and write" << "\n";
     cin >> pause;
     exit(1);
}
// ======================================================================================================================
long long filesize(string file1)
{
// declare variables
    long long begin1;
    long long end1;
    long long filesize1;
    string pause;  
//    string file1 = globalfile;
      
    // open file1
     fstream myfile1(file1.c_str(), ios::in | ios::binary);
     if (!myfile1)
     {
          myfile1.close();
          cout << "Failed to read file one line 134.\n";
          cin >> pause;
          exit(1);
     }

// get filesize1
     begin1 = myfile1.tellg();
     if (!myfile1)
     {
          myfile1.close();
          cout << "Failed to read file one line 316.\n";
          cin >> pause;
          exit(1);
     }
     myfile1.seekg (0, ios::end);
     end1 = myfile1.tellg();
     filesize1 = (end1-begin1);     

// close file 1
     myfile1.close();
     myfile1.clear();
     myfile1.flush();

// return filesize
     return(filesize1);
// end sub
}
// ======================================================================================================================
// a = y - (b times x) = WRITE EQUATION TO CONFIGURE FILE
//    int writeequationconfigfile(long long y, long double b, long double x)
    int writeequationconfigfile(long double y, long double b, long long x)
    {
         long double a = 0;
         fstream c1myfile2("regressionconfig.txt", ios::out);
         a = y - (b * x);       
         c1myfile2.precision(36);
         c1myfile2 << " y " << " = " << a << " + " <<  b << " times " << x << "\n";
         c1myfile2 << " y = a + bx " << "\n";
         c1myfile2 << a << " = " << y << " - " << " ( " << b << " times " << x << " ) " << "\n";
         c1myfile2 << " a = y - (b times x)" << "\n";  
        // close
         c1myfile2.close();
         c1myfile2.clear();
         c1myfile2.flush();
         return(0);
    }
// ======================================================================================================================
//     (n times (exy))-((ex) times (ey))
// b = --------------------------------     =  CALCULATE B
//      (n times (ex^2)) - ((ex)^2)
//    long double getB(long long samples, long double ex, long long ey, long double exsquared, long long eysquared, long double exy)
    long double getB(long long samples, long long ex, long double ey, long long exsquared, long double eysquared, long double exy)
    {
         long double b = 0;
         b = ((samples * exy) - (ex * ey)) / ((samples * exsquared) - exsquared);
         return(b);  
    }
// ======================================================================================================================
// Get y average of weak check-sums
//    long long getyaverageofy(long long ey, long long samples)
    long double getyaverageofy(long double ey, long long samples)
    {
//         long long count2 = 0;
         long double count2 = 0;
         count2 = ey/samples;
         return(count2);
    }
// ======================================================================================================================
// Get X average
//    long double getxaverageofx(long double ex,long long samples)
    long long getxaverageofx(long long ex,long long samples)
    {
//         long double count2 = 0;
         long long count2 = 0;
         count2 = ex/samples;
         return(count2); 
    }
// ======================================================================================================================
// exy = Sum of X times Y.
//    long double getexysumofxtimesy(long double ex, long long ey)
    long double getexysumofxtimesy(long long ex, long double ey)
    {
         long double count2 = 0;
         count2 = 0;
         count2 = ex * ey;
         return(count2);
    }
// ======================================================================================================================
// ey^2 = Sum of y^2 Get sum of squares.
//    long long geteysquare2sumofsquares()
    long double geteysquare2sumofsquares()
    {
//         long long x2= 0;
//         long long count2 = 0;         
         long double x2= 0;
         long double count2 = 0;         



         // open strong sums list
//         fstream c1myfile2("weaksums.txt", ios::in);
         fstream c1myfile2("strongsums.txt", ios::in);
         count2 = 0;
         // start loop1
         do
         { 
              // read weak sum
              c1myfile2 >> x2;
              x2 = pow(x2, 2);
              count2 = count2 + x2;
              // if end of file break
              if (c1myfile2.eof())
              {
                   break;
              }
              // increment count1
         // end loop 1
         } while(!c1myfile2.eof());
        // close strongsums.txt
         c1myfile2.close();
         c1myfile2.clear();
         c1myfile2.flush();
         return(count2);
    }
// ======================================================================================================================
// ex^2 = Sum of x^2 Get sum of squares.
//    long double getexsquare2sumofsquares()
    long long getexsquare2sumofsquares()
    {
//         long double x2= 0;
//         long double count2 = 0;         
         long long x2= 0;
         long long count2 = 0;         

         // open strong sums list
//         fstream c1myfile2("strongsums.txt", ios::in);
         fstream c1myfile2("weaksums.txt", ios::in);
         count2 = 0;
         // start loop1
         do
         { 
              // read weak sum
              c1myfile2 >> x2;
              x2 = pow(x2, 2);
              count2 = count2 + x2;
              // if end of file break
              if (c1myfile2.eof())
              {
                   break;
              }
              // increment count1
         // end loop 1
         } while(!c1myfile2.eof());
        // close strongsums.txt
         c1myfile2.close();
         c1myfile2.clear();
         c1myfile2.flush();
         return(count2);

    }
// ======================================================================================================================
// ey =  Sum of Y Get sum.
//    long long getey()
    long double getey()
    {
//         long long x2= 0;
//         long long count2 = 0;         
         long double x2= 0;
         long double count2 = 0;         

         // open strong sums list
//         fstream c1myfile2("weaksums.txt", ios::in);
         fstream c1myfile2("strongsums.txt", ios::in);
         count2 = 0;
         // start loop1
         do
         { 
              // read weak sum
              c1myfile2 >> x2;
              count2 = count2 + x2;
              // if end of file break
              if (c1myfile2.eof())
              {
                   break;
              }
              // increment count1
         // end loop 1
         } while(!c1myfile2.eof());
        // close strongsums.txt
         c1myfile2.close();
         c1myfile2.clear();
         c1myfile2.flush();
         return(count2);

    }
// ======================================================================================================================
// ex =  Sum of X Get sum.
//    long double getex()
    long long getex()
    {
//         long double x2= 0;
//         long double count2 = 0;         
         long long x2= 0;
         long long count2 = 0;         

         // open strong sums list
//         fstream c1myfile2("strongsums.txt", ios::in);
           fstream c1myfile2("weaksums.txt", ios::in);
         count2 = 0;
         // start loop1
         do
         { 
              // read weak sum
              c1myfile2 >> x2;
              count2 = count2 + x2;
              // if end of file break
              if (c1myfile2.eof())
              {
                   break;
              }
              // increment count1
         // end loop 1
         } while(!c1myfile2.eof());
        // close strongsums.txt
         c1myfile2.close();
         c1myfile2.clear();
         c1myfile2.flush();
         return(count2);
    }
// ======================================================================================================================
// open list and count how many samples
    long long countsamples()
    {
         // declare variables
         long long count1 = 0;
         long long count2 = 0;  
         long long x1 = 0;
         long double x2= 0;
         string pause;
         // open weak sums list
         fstream c1myfile1("weaksums.txt", ios::in);         
         // open strong sums list
         fstream c1myfile2("strongsums.txt", ios::in);
         // set count1 to 0
         count1 = 0;
         // start loop1
         do
         { 
              // read weak sum
              c1myfile1 >> x1;
              // if end of file break
              if (c1myfile1.eof())
              {
                   break;
              }
              // increment count1
              count1++;
         // end loop 1
         } while(!c1myfile1.eof());
         // set count2 to 0
         count2 = 0;
         // start loop1
         do
         { 
              // read weak sum
              c1myfile2 >> x2;
              // if end of file break
              if (c1myfile2.eof())
              {
                   break;
              }
              // increment count1
              count2++;
         // end loop 1
         } while(!c1myfile2.eof());
        // close list.txt
         c1myfile1.close();
         c1myfile1.clear();
         c1myfile1.flush();
        // close strongsums.txt
         c1myfile2.close();
         c1myfile2.clear();
         c1myfile2.flush();
         if (count1 != count2)
         {
              cout << "count1 " << count1 << " Not equal to " << "count2 " << count2 << "\n";
              cin >> pause;
         }   
         // return(count2);
         return(count2); 
    }
// ======================================================================================================================
// open list of files. Get strong check sum for files and write them to strongchecksum.txt with file names
    int getstrongsumsfilelist(long long howmanyweightedsums, int buffersize)
    {
         // declare variables
         fstream c1myfile1("list.txt", ios::in);
         fstream c1myfile2("strongsums.txt", ios::out);
         // open file2 for weights
         fstream c1myfile3("weights.txt", ios::in);
         string file1; 
         fstream myfile1;
         long double x1;
         string x2;
         int byte1 = 0;
         long double schecksum = 0;
         long long begin1;
         long long count1;
         long long count2;
         unsigned char buffer(buffersize);
         long long size1;
         long long size2;
         long long filesize1;
         long long end1 = 0;
         string pause;
//         stringstream ss;
         
         // open main loop
         do
         {
              // read list
              c1myfile1 >> file1;
              if (c1myfile1.eof())
              {
                   break;
              }   
// get strong check sum

              // open file1 computer file1
              fstream myfile1(file1.c_str(), ios::in | ios::binary);
              if (!myfile1)
              {
                   myfile1.close();
                   cout << "Failed to read file one.\n";
                   cin >> pause;
                   exit(1);
              }

              // get filesize1
              begin1 = myfile1.tellg();
              if (!myfile1)
              {
                   myfile1.close();
                   cout << "Failed to read file one.\n";
                   cin >> pause;
                   exit(1);
              }
              myfile1.seekg (0, ios::end);
              end1 = myfile1.tellg();
              filesize1 = (end1-begin1);

              // Two loops that get the strong check-sum
              count1 = 0;
              schecksum = 0;
              // start loop 1
              do
              {
                   // read file1
                   byte1 = 0;
                   // read file1
                   myfile1.seekg(count1);
                   myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
                   begin1 = myfile1.tellg();
                   // byte1 = read from file 1
                   byte1 = (int)buffer;

                   count2 = 0;
                   // start loop 2
                   do
                   {
                        // count2++;
                        count2++;
                        // read weight file. 
                        c1myfile3.precision(36);
                        c1myfile3 >> x1;
                        // schecksum = schecksum + (byte1 * x1);
                        schecksum = schecksum + (byte1 * x1);
                   // end loop 2 for how many weighted sums
                   } while(count2 < howmanyweightedsums);
                   // count1 = count1 + buffersize;
                   count1 = count1 + buffersize;
              // end loop 1 for count1 < filesize1 - 1
              } while (count1 <  filesize1 - 1);
              // close file1 for program
              myfile1.close();
              myfile1.clear();
              myfile1.flush();     
              // write weak check-sum to file
              c1myfile2.precision(36);
              c1myfile2 << schecksum << "\n";
        // repeat main loop to end of file
         } while(!c1myfile1.eof());
        // close list.txt
         c1myfile1.close();
         c1myfile1.clear();
         c1myfile1.flush();
        // close strongsums.txt
         c1myfile2.close();
         c1myfile2.clear();
         c1myfile2.flush();
        // close file2 for weights
         c1myfile3.close();
         c1myfile3.clear();
         c1myfile3.flush();
    }
// ======================================================================================================================
// open list of file. Get weak check sum for files and write then to weaksum.txt with file names
    int getweaksumsfilelist(int buffersize)
    {
         // declare variables
         fstream c1myfile1("list.txt", ios::in);
         fstream c1myfile2("weaksums.txt", ios::out);
         string file1; 
         fstream myfile1;
         int x;
         long long checksum = 0;
         long long begin1;
         long long count1;
         long long count2;
         unsigned char buffer(buffersize);
         long long size1;
         long long size2;
         long long filesize;
         string pause;
         // open main loop
         do
         {
              // read list
              c1myfile1 >> file1;
//              cout << file1 << "\n";
              if (c1myfile1.eof())
              {
                   break;
              }

              // get weak check-sum of file
// Start getting weak check sum
              // open file1
              myfile1.open(file1.c_str(), ios:: in | ios:: binary);
              if (!myfile1)
              {
                   cout << "122608-12:02 am Unable to open file.\n";
                   cin >> pause;
                   exit(1); // terminate with error
              }
              // get file size
              myfile1.seekg(0, ios::beg);
              size1 = myfile1.tellg();
              myfile1.seekg(0, ios::end);
              size2 = myfile1.tellg();
              filesize = size2 - size1;
              // set checksum to 0
              checksum = 0;
              // set count1 to 0
              count1 = buffersize * -1;
              // start first loop
              do
              {
                   // count1 = count1 + buffersize2
                   count1 = count1 + buffersize;
                   // read byte
                   begin1 = myfile1.tellg();
                   myfile1.seekg(count1);
                   if (!myfile1)
                   {
                        myfile1.close();
                        cout << "error in line 51.\n";
                        cin >> pause;
                        exit(1);
                   }
                   myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
                   x = (int)buffer;
                   // calculate weak check sum
                   checksum = checksum + x;
              // end first loop while (count1 < ((filesize - 1) + buffersize2))
              } while (count1 <  filesize - 1);
              // close files
              myfile1.close();
              myfile1.clear();
              myfile1.flush();
// END GETTING WEAK CHECK STRONG
              if (c1myfile1.eof())
              {
                   break;
              }
              // write weak check-sum to file
              c1myfile2 << checksum << "\n";
        // repeat main loop to end of file
         } while(!c1myfile1.eof());
        // close list.txt
         c1myfile1.close();
         c1myfile1.clear();
         c1myfile1.flush();
        // close weaksums.txt
         c1myfile2.close();
         c1myfile2.clear();
         c1myfile2.flush();
        // return(0);
        return(0);
    } 


// ======================================================================================================================
int makelist1()
{
     char pause;
     system("ls test* > list.txt");
     return(0);
}
// ======================================================================================================================
int generaterandomnumbers(long long filesize1)
{
    // declare variables
//    long long filesize1 = 0; // Note the true filesize of this file has not been determined yet. This is the filesize in theory that we want.
    long long frequency1 = 0; // constant
    long long occurance1 = 0; // constant
    long long frequency2 = 0; // variable
    long long occurance2 = 0; // variable
    long long count1 = 0; // counts up to 255 then we are done. All bytes in file at same frequency and occurance.
    long long count2 = 0; // counting occurance and frequency
    long long count3 = 0; // counting file position
    long long count4 = 0; // unused
    string file1 = "random.bin";
    long long startposition1 = 0; // starting position in the file for each new byte
    long long startposition2 = 0; // starting position in the file for each new byte
    long long begin1;
    long long end1;
    unsigned char buffer;
    int buffersize = 1;
    string pause;
    time_t seconds;
    srand((unsigned int) 5654940); // This seed number can be changed to what ever you want.        
    long long a = 3;
    long long c = 2361;
    long long m = 999999;
    long long k = 0;
    long long r = 0;
    int byte1 = 0;
    int test = 0;
    int dummyfile;

    // Get file size from command line argument.
//    filesize1 = strtoull(argv[1],NULL,10);

    // double donotuse[255];
    double donotuse[255];

    // initialize do not use array with -1
    count1 = 0;
    do
    {
         donotuse[count1] = -1;
         count1++;
    } while(count1 < 256);


    // calculate frequency of use
    frequency1 = round(filesize1 / 255);
    frequency2 = frequency1;

    // calculate how often used
    occurance1 = round(filesize1 / 255);
    occurance2 = occurance1;

    // open binary file random.bin
    fstream myfile1(file1.c_str(), ios::out | ios::binary);
    if (!myfile1)
    {
         myfile1.close();
         cout << "Failed to read file one line 94.\n";
         cin >> pause;
         exit(1);
    }

    // initilize counts
    count1 = 0; // general counting variable
    count2 = 0; // counting occurance and frequency
    count3 = 0; // counting file position
    count4 = 0; // counts up to 255 then we are done. All bytes in file at same frequency and occurance.
    startposition1 = 0; // starting position in the file for each new byte
    do // Start main loop for occurance1
    {

         // jump1
jump1:
         // pick random number
         time(&seconds);
         k = (rand() % 429940833); // We can randomize timer here if we want. Thats up to the user.
         k = k + seconds;
         byte1 = (a * k + c) % 256;
 
         // initilize count1
         count1 = 0;
         // initilize test
         test = 0;
         // start do loop
         do
         {
              // test to see if number in do not use array
              if (donotuse[count1] == byte1)
              {
                   test = 1;
                   break;
              }
              // increment count1
              count1++;
         // end do loop
         } while(count1 < 255);

         // if test == 1 goto jump1
         if (test == 1)
         {
              goto jump1;
         }
         
         // if test == 0 keep going
              // no code needed here we keep going

         // initialize count1
         count1 = 0;

         // start do loop
         do
         {
              // put number in do not use array where there is a -1
              if (donotuse[count1] == -1)
              {
                   donotuse[count1] == byte1;
                   break;
              }
              // increment count1
              count1++;

         // end do loop
         } while(count1 < 255);

         // set occurance1 = occurance2
         occurance2 = occurance1;

         // Put binary number in file at frequency and occurance
         count1 = 0; // counts bytes as they are used. Must be 0 starting out.
         count2 = startposition1; // used for occurance
         count3 = startposition1; // used for file position
         startposition2 = startposition1; // setting variable startposition2
         occurance2 = occurance1; // setting variable occurance2
         do // Start second loop for frequency1
         {
              if (count2 == startposition2)
              {
                   // occurance2--
                   occurance2--;

                   // put number in file at count3;
                   buffer = (unsigned char)byte1;
                   myfile1.seekp(count3);
                   myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
                   begin1 = myfile1.tellp();


                   // startposition2 = -999 // so we do use this again
                   startposition2 = -999;            
              }

              count2++;
              if (count2 >= occurance1)
              {
                   // occurance2--
                   occurance2--;

                   // put number in file at count3
                   buffer = (unsigned char)byte1;
                   myfile1.seekp(count3);
                   myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
                   begin1 = myfile1.tellp();

                   // reset count2
                   count2 = 0; 
              }
 
              count3++; // file position

          } while(occurance2 > 0);

         // reset start position2
         count4++; // counts up to 255 then we are done. All bytes in file at same frequency and occurance.

         // starting position in the file for each new byte 
         startposition1++;          

    } while(count4 < 255); // End main loop for file size

    // close random.bin
    myfile1.close();
    myfile1.clear();
    myfile1.flush();

    
//    dummyfile = viewfile1(file1, filesize1, buffersize);
//    cout << "These were your random numbers" << "\n";

    // exit prograom
    return(0);
}
// ======================================================================================================================
long double getstrongchecksum(string file1, long long howmanyweightedsums, int buffersize)
{
    // declare variables
    // open file2 for weights
    fstream c1myfile3("weights.txt", ios::in);
//    string file1; 
//    fstream myfile1;
    long double x1;
    string x2;
    int byte1 = 0;
    long double schecksum = 0;
    long long begin1;
    long long count1;
    long long count2;
    long long size1;
    long long size2;
    long long filesize1;
    long long end1 = 0;
    string pause;
//    long long howmanyweightedsums;
//    int buffersize;
    unsigned char buffer(buffersize);
    
//    cout << "Please have your weights.txt file ready." << "\n";
//    cout << "Please enter the name of your file." << "\n";
//    cin >> file1;
//    cout << "How many weighted sums do you want?" << "\n";
//    cin >> howmanyweightedsums;
//    cout << "What is your buffer size." << "\n";
//    cin >> buffersize;

    // open file1 computer file1
    fstream myfile1(file1.c_str(), ios::in | ios::binary);
    if (!myfile1)
    {
         myfile1.close();
         cout << "Failed to read file one.\n";
         cin >> pause;
         exit(1);
    }

    // get filesize1
    begin1 = myfile1.tellg();
    if (!myfile1)
    {
         myfile1.close();
         cout << "Failed to read file one.\n";
         cin >> pause;
         exit(1);
    }
    myfile1.seekg (0, ios::end);
    end1 = myfile1.tellg();
    filesize1 = (end1-begin1);

    // Two loops that get the strong check-sum
    count1 = 0;
    schecksum = 0;
    // start loop 1
    do
    {
         // read file1
         byte1 = 0;
         // read file1
         myfile1.seekg(count1);
         myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
         begin1 = myfile1.tellg();
         // byte1 = read from file 1
         byte1 = (int)buffer;
         count2 = buffersize * -1;
         // start loop 2
         do
         {
              // count2++;
              count2 = count2 + buffersize;
              // read weight file. 
              c1myfile3.precision(36);
              c1myfile3 >> x1;
              // schecksum = schecksum + (byte1 * x1);
              schecksum = schecksum + (byte1 * x1);
              // end loop 2 for how many weighted sums
         } while(count2 < howmanyweightedsums);
         // count1 = count1 + buffersize;
         count1 = count1 + buffersize;
         // end loop 1 for count1 < filesize1 - 1
    } while (count1 <  filesize1 - 1);
    // close file1 for program
    myfile1.close();
    myfile1.clear();
    myfile1.flush();     
    // close file2 for weights
    c1myfile3.close();
    c1myfile3.clear();
    c1myfile3.flush();
//    cout.precision(36);
//    cout << schecksum << "\n";
    return(schecksum);
    exit(0);
}
// ======================================================================================================================
int generateweights()
{

//              weight1 = (a * k + c) % (int)999999999;
//              decimal = (a * k + c) % (int)6
//               k = filesize2 = (rand() % 429940833); 

         // declare variables
         long long a = 3;
         long long c = 2361;
         long long m = 999999;
         long long k = 0;
         long long r = 0;
         long long filesize;
         char pause;
         srand((unsigned int) 5654940);
         time_t seconds;
         long long howmanyweights;
         long long count1 = 0;
         long long count2 = 0;
         long double weight2 = 0;
         int decimal = 0;
         int weight1 = 0;
         // Run program
// Ask user how many weights
         cout << "How many weights do we need today" << "\n";
         cin >> howmanyweights; 
// open weight file
         fstream c1myfile2("weights.txt", ios::out);
// start main loop
         do
         { 
              // increment count
              count1++;
// generate random weights
              time(&seconds);
              k = (rand() % 429940833);
              k = k + seconds; 
              weight1 = (a * k + c) % (int)999999999;
              decimal = (a * k + c) % (int)6;
              count2 = -1;
              weight2 = (long double)weight1;
              count2 = 0;
              do
              {
                   count2++;
                   weight2 = weight2/10;
//                   cout.precision(9);
//                   cout << weight2 << "\n";
              } while(count2 < 9);
//              decimal = 5;
//              cout << "---------------" << "\n";
              count2 = 0;
              do
              {
                   count2++;
                   weight2 = weight2/10;
              } while(count2 < decimal); 
//              cout.precision(15);
//              cout << weight2 << "\n";
// write weight to file
              c1myfile2.precision(16);
              c1myfile2 << weight2 << "\n";
// repeat for how many weights
         } while(count1 < howmanyweights);
        // close weaksums.txt
         c1myfile2.close();
         c1myfile2.clear();
         c1myfile2.flush();
// EXIT PROGRAM
         exit(0); 
}
// ======================================================================================================================
long long getweakchecksum(int buffersize, string file1)
{

         fstream myfile1;
         int x;
         long long checksum = 0;
         long long begin1;
         long long count1;
         long long count2;
         unsigned char buffer(buffersize);
         long long size1;
         long long size2;
         long long filesize;
         string pause;
              
              myfile1.open(file1.c_str(), ios:: in | ios:: binary);
              if (!myfile1)
              {
                   cout << "122608-12:02 am Unable to open file.\n";
                   cin >> pause;
                   exit(1); // terminate with error
              }
              // get file size
              myfile1.seekg(0, ios::beg);
              size1 = myfile1.tellg();
              myfile1.seekg(0, ios::end);
              size2 = myfile1.tellg();
              filesize = size2 - size1;
              // set checksum to 0
              checksum = 0;
              // set count1 to 0
              count1 = buffersize * -1;
              // start first loop
              do
              {
                   // count1 = count1 + buffersize2
                   count1 = count1 + buffersize;
                   // read byte
                   begin1 = myfile1.tellg();
                   myfile1.seekg(count1);
                   if (!myfile1)
                   {
                        myfile1.close();
                        cout << "error in line 51.\n";
                        cin >> pause;
                        exit(1);
                   }
                   myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
                   x = (int)buffer;
                   // calculate weak check sum
                   checksum = checksum + x;
              // end first loop while (count1 < ((filesize - 1) + buffersize2))
              } while (count1 <  filesize - 1);
              // close files
              myfile1.close();
              myfile1.clear();
              myfile1.flush();
              return(checksum);

}
// ======================================================================================================================
#endif 
