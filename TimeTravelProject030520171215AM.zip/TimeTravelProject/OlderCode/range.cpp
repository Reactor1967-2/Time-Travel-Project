// Copyright(C) http://time-travel.institute
// This program uses the pbconfigure file to find the highest and lowest base power check-sum range
// ============================================================================================
// declare includes
#include <cstdlib>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <string> 
#include <cmath>
#include <ctime>
#include <cstdio>
#include <iostream>
// ============================================================================================
    // Declare namespace
    using namespace std;
// ============================================================================================     
// declare subs
// ============================================================================================
// declare main
int main (int argc, char *argv[])
{
    // declare variables
    string dummy1;
    string dummy2;
    string dummy3;
    string dummy4;
    string dummy5; 
    string dummy6;
    string dummy7;
    string dummy8;
    string pause;
    fstream c1myfile1;
    long long high;
    long long low;
    long long filenumber1;
    long long filenumber2;
    long long filenumber3;
    long long temp1;

    // open pbconfigure.txt
    c1myfile1.open("pbconfigure.txt", ios::in);
    if (!c1myfile1)
    {
         cout << "There is no configure file." << "\n";
         c1myfile1.close();
         c1myfile1.clear();
         c1myfile1.flush();
         exit(0);           
    }
     // initialize variables
     high = 0;
     low = 99999999999999;
     // read first line of file
     c1myfile1 >> dummy1 >> dummy2 >> dummy3 >> dummy4 >> dummy5 >> dummy6 >> dummy7 >> dummy8;
// cout << dummy1 << " " << dummy2 << " " << dummy3 << " " << dummy4 << " " << dummy5 << " " << dummy6 << " " << dummy7 << " " << dummy8 << "\n";
// cin >> pause;
// exit(0);   
     // start loop
    do
    {   
        // if find a lower variable keep it.
        if (!c1myfile1.eof())
         {
              filenumber1 = 0;
              c1myfile1 >> filenumber1  >> temp1 >> dummy3 >> dummy4;
              if (filenumber1 > 0)
              {
                   if (temp1 < low)
                   {
                        low = temp1;
                        filenumber2 = filenumber1;
                   }
                   
                   if (temp1 > high)
                   {
                        high = temp1;
                        filenumber3 = filenumber1;
                   }
                   cout << filenumber1 << " " << temp1 << " " << dummy3 << " " << dummy4 << " high " << high << " low " << low << "\n";

              }
         }
        // if find a higher variable keep it.
     // repeat loop to eof
    } while(!c1myfile1.eof());
    // close pbconfigure.txt
    c1myfile1.close();
    c1myfile1.clear();
    c1myfile1.flush(); 
    // print output to user
    cout << "High is file = " << filenumber3 << "\n";
    cout << "low is file = " << filenumber2 << "\n";
    // end program
    exit(0);
}
