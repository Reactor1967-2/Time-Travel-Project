#!/bin/bash

g++ timescanner.cpp -o timescanner
g++ timescanner2.cpp -o timescanner2
g++ differencefilescreater.cpp -o differencefilescreater

