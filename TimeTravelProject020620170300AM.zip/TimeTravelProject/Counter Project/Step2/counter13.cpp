// COPYRIGHT(C) 2017 http://time-travel.institute (THIS IS OPEN SOURCE)
// WARNING YOU NEED A random.txt number file  and a weight file to use this program.
// This runs an experimental counter and a control counter to hack a weighted strong check-sum to a computer file.
// Delete the lock.txt file to end the program.
// If your random.txt file is bad this program won't work
// have a weight file or the strong check-sum won't work
 // declare includes
    #include <cstdlib>
    #include <iostream>
    #include <stdlib.h>
    #include <fstream>
    #include <sstream>
    #include <string> 
    #include <cmath>
    #include <ctime>
    #include <cstdio>
    #include <iostream>
    #include "timecheckhacking.h"
// ============================================================================================
    // Declare namespace
    using namespace std;
// ============================================================================================     
// declare globals 
    long double targetstrongchecksum;
    long double destinationstrongchecksum;
    string file3; // destination file
    long long filesize1;
    long long howmanyweightedsums;
    int buffersize;

// ============================================================================================     
// declare subs
// ======================================================================================================================
int binaryreadwrite(string whatdo, string file1, long long byteposition, int byte, int buffersize)
{

    unsigned char buffer(buffersize);
    char pause;
    int byte1 = byte;
    long long count1 = byteposition;
    long long begin1;
//     int buffersize = 1;
       
    // open file
    fstream myfile1(file1.c_str(), ios::out  | ios::in | ios::binary);
    if (!myfile1)
    {
         myfile1.close();
         cout << "error in line 79" << " " << file1 << "\n";
         cin >> pause;
         exit(1);
    }
    if (whatdo == "read")
    {
// cout << byte1 << " We are reading bytes " << "\n"; // debug code
         myfile1.seekg(count1);
         myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
         begin1 = myfile1.tellg();
         byte1 = (int)buffer;
         myfile1.close();
         myfile1.clear();
         myfile1.flush();
         return(byte1);
    }
    if (whatdo == "write")
    {
// cout << byte1 << " We are writing bytes " << "\n"; // debug code
         buffer = (unsigned char)byte1;
         myfile1.seekp(count1);
         myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
         begin1 = myfile1.tellp();
         myfile1.close();
         myfile1.clear();
         myfile1.flush();
         return(0);
    } 
     

    cout << "Error in binary read and write" << "\n";
    cin >> pause;
    exit(1);
}
// =============================================================================================
// loadconfig Note give name of config file
int loadconfig() 
{// Can't put this in a header and use globals
    // Declare these variables as global in your main file
    // declare variables
    string dummy;
    string pause;

// Load configure file
    fstream c1myfile("config.txt", ios::in);
    // read name of file destination file
    c1myfile >>  dummy >> dummy >> dummy >> file3;
    // strong check sum
    c1myfile >>  dummy >> dummy >> dummy >> targetstrongchecksum;
    // read file size
    c1myfile >>  dummy >> dummy >> dummy >> filesize1;
    // read how many weights
    c1myfile >>  dummy >> dummy >> dummy>> dummy >> howmanyweightedsums;
    // read buffersize
    c1myfile >>  dummy >> dummy >> buffersize;

    // close configure file
    c1myfile.close();
    c1myfile.clear();
    c1myfile.flush();

    // Print configure file to confirm loaded correctly
    cout << "File name > " << file3 << "\n";
    cout.precision(36);
    cout << "Strong check-sum > " << targetstrongchecksum << "\n";
    cout.precision(36);
    cout << "File size > " << filesize1 << "\n";
    cout.precision(36);
    cout << "How many weighted check-sums > " << howmanyweightedsums<< "\n";
    cout << "Buffer size " << buffersize << "\n";
    cout << "\n"; 
    cout << "Is the configuration file loaded properly?" << "\n";
    cout << "Hit any key and enter." << "\n";
    cin >> pause;
    return(0);
//       
}
// ============================================================================================
// declare main
int main (int argc, char *argv[])
{
// ============================================================================================
    // declare variables
    int result = -999;
    string pause;
    int byte;
    int byte1;
    int byte2;
    int byte3;
    int carry;
    string whatdo;
    int seed;
    long double diff3 = 999999999;
    long long numberbase;
    string file1;
    string file2;
    long long count2;
    fstream myfile1;
    long long filesize2;
    string seedfile = "random.txt";
    fstream c1myfile1;
    int dummyfile;
    string lockfile = "lock.txt";
    string destinationfile = file3;
    string configfile;

// ============================================================================================
// Test subs and functions here
// ============================================================================================  

    // pass arguments to program. If no arguments run menu. If Arguments run program
    if (argc == 1) 
    {
         cout << "No command line arguments. I can't run. Type nameofprogram help" << "\n";
         cin >> pause;
         exit(1);   
    }

    // passing command line arguments to program
    configfile = argv[1]; // name of config file only // contains lockfile, strong checksum, howmany weighted sums, and file size.

//    destinationfile = argv[2]; // This needs to be the same size as the file it is trying to recreate

    if (configfile == "help")
    {
         cout << "This is help here." << "\n";
         cout << "NAMEOFPROGRAM CONFIGFILE DESTINATIONFILE" << "\n";
         exit(0); 
    }

// ============================================================================================
    // open configure file here and read it.
    dummyfile = loadconfig();
// ============================================================================================
    // create lockfile
    dummyfile = createemptyfile(lockfile);
// ============================================================================================
      // open seed file
    c1myfile1.open(seedfile.c_str(), ios::in);
    if (!c1myfile1)
    {
         cout << "There is no file list." << "\n";
         c1myfile1.close();
         c1myfile1.clear();
         c1myfile1.flush();
         exit(0);           
    }


// ============================================================================================
// start 
Startprogram:
 
// =======================================================================================================================
    // Generate random file
    if (!c1myfile1.eof())
    {
         c1myfile1 >> seed; 
         srand((unsigned int) seed);
    }

    if (c1myfile1.eof())
    {
         c1myfile1.close();
         c1myfile1.clear();
         c1myfile1.flush();
         cout << "Please load another random seed file" << "\n";
         cin >> pause;
         c1myfile1.open(seedfile.c_str(), ios::in);
         if (!c1myfile1)
         {
              cout << "There is no file list." << "\n";
              c1myfile1.close();
              c1myfile1.clear();
              c1myfile1.flush();
              exit(0);           
         }
         c1myfile1 >> seed; 
         srand((unsigned int) seed);
    }
// =======================================================================================================================

         filesize2 = filesize1;        
         file2 = "counter.bin";
         myfile1.open(file2.c_str(), ios::out  | ios::binary);
         if (!myfile1)
         {
              myfile1.close();

              cout << "error in line 38" << " " << file2 << "\n";
              cin >> pause;
              exit(1);
         }
         myfile1.close();
         myfile1.clear();
         myfile1.flush();
         // Get random binary          
         count2 = buffersize * -1;

         // start second loop
         do
         {
              count2 = count2 + buffersize;
              byte = (rand() % (255*buffersize)); // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< ERROR
              whatdo = "write";
              file2 = "counter.bin";
              // write random binary
              dummyfile = binaryreadwrite(whatdo, file2, count2, byte, buffersize);

              // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< NOTE CAN ADD RESEEDED RANDOM NUMBER GENERATOR WHERE WITH SEED FILE
//              c1myfile1 >> seed; 
//              srand((unsigned int) seed);

          // end second loop for random file size
         } while(count2 < filesize2 - 1);
// =========================================================================================================================

    // get destination
    destinationstrongchecksum = getstrongchecksum(file2, howmanyweightedsums, buffersize);

    // break loop if diff3 == 0
    if (abs(targetstrongchecksum - destinationstrongchecksum) == 0)
    {
         if (targetstrongchecksum == destinationstrongchecksum)
         {
              // copy new counter.bin to counterbak.tin
              dummyfile= rename( "counter.bin" , file3.c_str() );
              cout << "File Reconstructed" << "\n";
              cout << "PROGRAM ENDED!!!!!!" << "\n";
              // close seed file
              c1myfile1.close();
              c1myfile1.clear();
              c1myfile1.flush();
              // remove temp.bin
//              system("rm temp.bin"); // if it exist
              // remove counterbak.bin
              system("rm counterbak.bin");
              
              exit(0);
         }
    }

    // Run the pendulum algorithm  
    // if abs(destination - target) < diff3 then backup counter 
    if (abs(targetstrongchecksum - destinationstrongchecksum) < diff3)
    {
         // get new diff3  
         // if abs(destination - target) < diff3 then diff3 = abs(destination - target)
         diff3 = abs(destinationstrongchecksum - targetstrongchecksum);

         if (result == 1)
         {
              system("rm counterbak.bin");
         }
         
           // copy new counter.bin to counterbak.tin
         system("cp counter.bin counterbak.bin");
    
         result = 1;
    }

    // check lock file
    dummyfile = checklockfile(lockfile);

    // display output (for testing only)
    cout << "Diff3 " << diff3 << " Destination sum " << destinationstrongchecksum << " Target sum "<< targetstrongchecksum << "\n";

//  dummyfile = viewfile1(file1, buffersize, filesize1);


    goto Startprogram;         

}
