// COPYRIGHT(C) 2017 http://time-travel.institute
// This program takes two files. A high file and low file.
// Then it reads a file list of files it will subtract from the high or add to the low. 
// The user tells whether or add or subtract.
// Make a file list first like this ls > list.txt
// Then edit the list for any unecessary files.
// Run the program like this // ./ProgramName Buffersize HighFileName LowFileName FileList addsubtract extension
// from the command line.
// It will output target files.
// This works on the principle that if you know any two variables you can calculate the third
// So we we know our high range and our low range and the difference we can calculate your time travel media target file.
// You will have to use a random binary file generator to make the difference files. There is one at http://sourceforge.net/projects/timetravelproject/
// ============================================================================================
// Declare includes
#include <cstdlib>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <string> 
#include <cmath>
#include <ctime>
#include <cstdio>
#include <iostream>
#include "timecheckhacking2.h"
// ============================================================================================
// Declare namespace
using namespace std;
// ============================================================================================     
// declare subs
// ============================================================================================
int add(long long count3, int buffersize, string destinationfile, string differencefile, string extension)
{
         
        long long filesize2;
        long long filesize3;
        long long filesize4;
        long long count2;
        long long carry;
        long long byte;
        long long byte1;
        long long byte2;
        long long byte3;
//        long long numberbase = (256^buffersize) + 1;
        long long numberbase = (pow(256, buffersize));
        string pause;
        string whatdo;
        string file1;
        long long dummyfile;

        // get filesie 2
        filesize2 = filesize(differencefile);


        // get filesize 3
        filesize3 = filesize(destinationfile);

        filesize4 = filesize3;       

        // get file name  from ss
         stringstream ss;
         file1 = "";
         ss << count3;
         ss >> file1;
         file1 = file1 + extension;

         fstream myfile1(file1.c_str(), ios::out  | ios::binary);
         if (!myfile1)
         {
              myfile1.close();
              cout << "error in line 245" << " " << file1 << "\n";
              cin >> pause;
              exit(1);
         }
         myfile1.close();
         myfile1.clear();
         myfile1.flush();

         carry = 0;
         count2 = buffersize * -1;
         // start third loop
         do
         {
              // increment file variable
              count2 = count2 + buffersize;

              // set byte1 to zero
              byte1 = 0;

              // read byte1 if less than filesize
              whatdo = "read";

              if (count2 < filesize3 - 1)
              { 
                   byte1 = binaryreadwrite(whatdo, destinationfile, count2, byte, buffersize);
              }

              // // set byte2 to 0
              byte2 = 0;

              // read byte2 if less than filesize
              if (count2 < filesize2 - 1) 
              {
                   byte2 = binaryreadwrite(whatdo, differencefile, count2, byte, buffersize);
              }
             
              byte3 = 0;
              // byte3 = byte1 - byte2 - carry;
              byte3 = byte1 + byte2 + carry;

              // carry = 0;
              carry = 0;

              // if byte < 0 subtract from the base
              if (byte3  > numberbase - 1)
              {
                   byte3 = byte3 - numberbase;
                   carry = 1;
              }

              // Check for error
              if (byte3 > (numberbase - 1))
              {
                   cout << "Houston we have a problem\n";
                   cout << "byte3 greater than the base - 1\n";
                   cin >> pause;
                   exit(0);
              }

              if (byte3 < 0)
              {
                   cout << "Houston we have a problem\n";
                   cout << "byte3 less than 0\n";
                   cin >> pause;
                   exit(0);
              }



              // write random binary
              whatdo = "write";
              dummyfile = binaryreadwrite(whatdo, file1, count2, byte3, buffersize);


         // end third loop
         } while(count2 < filesize4 - 1); 
         return(0);

}
// ============================================================================================
int subtract(long long count3, int buffersize, string destinationfile, string differencefile, string extension)
{

        long long filesize2;
        long long filesize3;
        long long filesize4;
        long long count2;
        long long carry;
        long long byte;
        long long byte1;
        long long byte2;
        long long byte3;
//        long long numberbase = (256^buffersize) + 1;
        long long numberbase = (pow(256, buffersize));
        string pause;
        string whatdo;
        string file1;
        long long dummyfile;


        // get filesie 2
        filesize2 = filesize(differencefile);


        // get filesize 3
        filesize3 = filesize(destinationfile);

        filesize4 = filesize2; // We take the file size of the difference file to find the target.

         // get file name  from ss
         stringstream ss;
         file1 = "";
         ss << count3;
         ss >> file1;
         file1 = file1 + extension;

         fstream myfile1(file1.c_str(), ios::out  | ios::binary);
         if (!myfile1)
         {
              myfile1.close();
              cout << "error in line 245" << " " << file1 << "\n";
              cin >> pause;
              exit(1);
         }
         myfile1.close();
         myfile1.clear();
         myfile1.flush();

         carry = 0;
         count2 = buffersize * -1;
         // start third loop
         do
         {
              // increment file variable
              count2 = count2 + buffersize;

              // set byte1 to zero
              byte1 = 0;

              // read byte1 if less than filesize
              whatdo = "read";

              if (count2 < filesize3 - 1)
              { 
                   byte1 = binaryreadwrite(whatdo, destinationfile, count2, byte, buffersize);
              }

              // // set byte2 to 0
              byte2 = 0;

              // read byte2 if less than filesize
              if (count2 < filesize2 - 1) 
              {
                   byte2 = binaryreadwrite(whatdo, differencefile, count2, byte, buffersize);
              }
         
              byte3 = 0;
              // byte3 = byte1 - byte2 - carry;
              byte3 = byte1 - byte2 - carry;

              // carry = 0;
              carry = 0;

              // if byte < 0 subtract from the base
              if (byte3  < 0)
              {
                   byte3 = byte3 + numberbase;
                   carry = 1;
              }

              // Check for error
              if (byte3 > (numberbase - 1))
              {
                   cout << "Houston we have a problem\n";
                   cout << "byte3 greater than the base - 1\n";
                   cin >> pause;
                   exit(0);
              }

              // Check for error
              if (byte3 < 0)
              {
                   cout << "Houston we have a problem\n";
                   cout << "byte3 less then 0\n";
                   cin >> pause;
                   exit(0);
              }


              // write random binary
              whatdo = "write";
              dummyfile = binaryreadwrite(whatdo, file1, count2, byte3, buffersize);


         // end third loop
         } while(count2 < filesize4 - 1); 
         return(0);
}
// ============================================================================================
// declare main
int main (int argc, char *argv[])
{
    // Declare variables
    int buffersize;
    string highfile;
    string lowfile;
    string addsubtract;
    string destinationfile;
    string differencefile;
    string filelist;
    string extension;
    long long dummyfile;
    long long count3;
    string pause;

    // Take command line arguments
    // ./ProgramName Buffersize HighFileName LowFileName FileList addsubtract extension
    buffersize = atoi( argv[1]); // How many bytes we are reading at a time.
    highfile = argv[2]; // High file as a number in a numerical base.
    lowfile = argv[3]; // Low file as a number in a numerical base.
    filelist = argv[4]; // filelist containing the names of the difference files.
    addsubtract = argv[5]; // Are we adding the differences or subtracting them.
    extension = argv[6]; // file extension to give to targets.

    // open file list
    fstream c1myfile1(filelist.c_str(), ios::in);
    if (!c1myfile1)
    {
         cout << "There is no file list." << "\n";
         c1myfile1.close();
         c1myfile1.clear();
         c1myfile1.flush();
         exit(0);           
    }

    // if addsubtract == add
    if (addsubtract == "add")
    {
         // destination = Lowfile
         destinationfile = lowfile;
    }

    // if addsubtract = subtract
    if (addsubtract == "subtract")
    {
         // destination file = high file
         destinationfile = highfile;
    }

    // set count3 to 0
    count3 = 0;
    // Start do loop
    do
    {
         // increment count3
         count3++; // This is the file name

         // read file list
         c1myfile1 >> differencefile;


         // if addsubtract = subtract call subtract 
         if (addsubtract == "subtract")
         {
              dummyfile = subtract(count3, buffersize, destinationfile, differencefile, extension);
         }
  
         // if addsubtrct = add call add
         if (addsubtract == "add")
         {

              dummyfile = add(count3, buffersize, destinationfile, differencefile, extension);
         }

    // repeat till end of file list
    } while(!c1myfile1.eof());

    // print to user "ALL TARGETS CONSTRUCTED!!!!!!"
    cout << "ALL TARGETS CONSTRUCTED!!!!!!!!!!!!!!!!" << "\n";

    // Exit program
    exit(0);
}
