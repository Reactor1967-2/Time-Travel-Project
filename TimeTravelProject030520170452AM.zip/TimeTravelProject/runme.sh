#!/bin/bash
cd bin
./timescanner 1 destination.bin  destination.bin  list.txt subtract out.bin
echo Run a robot
cd ..

