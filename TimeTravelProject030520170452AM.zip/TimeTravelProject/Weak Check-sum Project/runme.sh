#!/bin/bash

g++ weakcheck-sumcounter.cpp -o weakcheck-sumcounter
g++ getweaksumslist.cpp -o getweaksumslist
