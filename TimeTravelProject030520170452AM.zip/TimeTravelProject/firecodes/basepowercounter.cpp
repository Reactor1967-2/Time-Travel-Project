// THIS IS THE BEST COUNTER THERE IS AT TIME TRAVEL PROJECT. IT HAS NO FILE COLLISIONS
// USE G++ FILENAME.CPP -O FILENAME TO COMPILE
// WARNING THIS RUNS AT 1 BYTE PER SECOND. IT IS SLOW RIGHT NOW.
// COPYRIGHT(C) 2017 http://time-travel.institute 
// Base Power Counter 
// Load configure file
// Create configure file
// Encodes base power check-sum
// Decodes base power check-sum
// ============================================================================================
 // declare includes
    #include <cstdlib>
    #include <iostream>
    #include <stdlib.h>
    #include <fstream>
    #include <sstream>
    #include <string> 
    #include <cmath>
    #include <ctime>
    #include <cstdio>
    #include <iostream>
    #include "basepower.h"

// ============================================================================================
    // Declare namespace
    using namespace std;
// ============================================================================================     
// declare subs
// ============================================================================================
// declare main
int main (int argc, char *argv[])
{
 
    // declare variables
    string file1;
    string file2;
    long long numberbase = 99999999;
    int dummyfile;
    int buffersize = 1;
    long long filesize1 = 0;
    string pause;
    long long end1;
    long long begin1;
    string choice;


    cout << "Enter 1 for coding a file to a base power check-sum." << "\n";
    cout << "enter 2 for decoding a base power check-sum back to a file." << "\n";
    cin >> choice;


    if (choice == "1")
    {

         cout << "Please enter the name of the file to encode or decode." << "\n";
         cin >> file1;

         // open binary file
         // open file1
         fstream myfile1(file1.c_str(), ios:: in | ios:: binary);
         if (!myfile1)
         {
              cout << "Error in line 1029.\n";
              cin >> pause;
              myfile1.close();
              myfile1.clear();
              myfile1.flush();
              exit(1); // terminate with error
         }

         // get file size of binary file
         begin1 = myfile1.tellg();
         if (!myfile1)
         {
              myfile1.close();
	      myfile1.clear();
	      myfile1.flush();
              cout << "Failed to read file two.\n";
              cin >> pause;
              exit(1);
         }

         myfile1.seekg (0, ios::end);
         end1 = myfile1.tellg();
         filesize1 = (end1-begin1);

         myfile1.close();
         myfile1.clear();
         myfile1.flush();

    }

    if (choice == "2")
    {

         cout << "Please enter the name of the file to encode or decode." << "\n";
         cin >> file1;

         // open binary file
         // open file1
         fstream myfile1(file1.c_str(), ios:: in | ios:: binary);
         if (!myfile1)
         {
              cout << "Error in line 1029.\n";
              cin >> pause;
              myfile1.close();
              myfile1.clear();
              myfile1.flush();
              exit(1); // terminate with error
         }

         // get file size of binary file
         begin1 = myfile1.tellg();
         if (!myfile1)
         {
              myfile1.close();
	      myfile1.clear();
	      myfile1.flush();
              cout << "Failed to read file two.\n";
              cin >> pause;
              exit(1);
         }

         myfile1.seekg (0, ios::end);
         end1 = myfile1.tellg();
         filesize1 = (end1-begin1);

         myfile1.close();
         myfile1.clear();
         myfile1.flush();

    }

    // ============================================================================================
    if (choice == "1")
    {


         cout << "Beginning Encode" << "\n";
         dummyfile = createbpchecksum(file1, numberbase, buffersize);
         cout << "FILE ENCODED TO CHECK-SUM. PLEASE REMOVE THE ORGINAL" << "\n";
         exit(0);
    }

    if (choice == "2")
    {

         cout << "Beginning Decode" << "\n";
         dummyfile = decodepbchecksum(file1, filesize1, numberbase, buffersize);
         cout << "FILE RECONSTRUCTED FROM ITS BASE POWER CHECK-SUM IN BASE 99999999!!!!" << "\n";
         exit(0);
    }         
}
