#!/bin/bash

g++ firecodes.cpp -o firecodes
g++ pbabysumconfig2.cpp -o pbabysumconfig2
g++ prollbabycounters.cpp -o prollbabycounters
g++ basepowercounter.cpp -o basepowercounter

