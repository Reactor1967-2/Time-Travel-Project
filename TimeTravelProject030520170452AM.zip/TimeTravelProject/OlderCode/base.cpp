// BASE.CPP COPYRIGHT(C) http://time-travel.institute
// SAMPLE OF HOW A COMPUTER FILE TRAVEL PROGRAM WOULD WORK.
// So with a text file with a list of numbers in base 1099511627776 read from the text file and converted to binary
// ANY COMPUTER FILE IN SPACE-TIME CAN BE DOWNLOADED TO YOUR COMPUTER AND RECONSTRUCTED!!!!
// this program takes a base 10 number 1099511627775 and writes it as binary in 5 bytes.
// 1099511627775 base10 = FF,FF,FF,FF,FF in base16 = 1111111111111111111111111111111111111111 base2
#include <cstdlib>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <string> 
#include <cmath>
#include <ctime>
#include <cstdio>
#include <iostream>
// ============================================================================================
// Declare namespace
using namespace std;
// ============================================================================================
// ======================================================================================================================
long long binaryreadwrite(string whatdo, string file1, long long byteposition, long long byte, long long buffersize)
{

     long long buffer = 4096;
     char pause;
     long long byte1 = byte;
     long long count1 = byteposition;
     long long begin1;
     
       
     // open file
      fstream myfile1(file1.c_str(), ios::out  | ios::in | ios::binary);
     if (!myfile1)
     {
          myfile1.close();
          cout << "error in line 266" << " " << file1 << "\n";
          cin >> pause;
          exit(1);
     }
     if (whatdo == "read")
     {
// cout << byte1 << " We are reading bytes " << "\n"; // debug code
          myfile1.seekg(count1);
          myfile1.read( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellg();
          byte1 = (int)buffer;
          myfile1.close();
          myfile1.clear();
          myfile1.flush();
          return(byte1);
     }
     if (whatdo == "write")
     {
// cout << byte1 << " We are writing bytes " << "\n"; // debug code
          buffer = (long long )byte1;
          myfile1.seekp(count1);
          myfile1.write( reinterpret_cast<char*>( &buffer ),buffersize);
          begin1 = myfile1.tellp();
          myfile1.close();
          myfile1.clear();
          myfile1.flush();
          return(0);
     } 
     

     cout << "Error in binary read and write" << "\n";
     cin >> pause;
     exit(1);
}
// ============================================================================================   
// declare main
int main (int argc, char *argv[])
{
    // Declare variables
    long long buffersize;
    long long count1;
    long long holdme;
    long long dummyfile;
    long long byte;
    string whatdo;
    string pause;
    string file1;
    cout << "What is your buffer size" << "\n";
    cin >> holdme;
    count1 = -1;
    buffersize = 1;
    file1 = "temp.bin";
    // open file
    fstream myfile1(file1.c_str(), ios::out  | ios::binary);
    if (!myfile1)
    {
         myfile1.close();
         myfile1.clear();
         myfile1.flush();
         cout << "error in line 42" << " " << file1 << "\n";
         cin >> pause;
         exit(1);
    }
    myfile1.close();
    myfile1.clear();
    myfile1.flush();
    count1 = buffersize * -1;
    buffersize = holdme;
    // THIS IS WHERE YOU WOULD READ FROM A TEXT FILE A LIST OF NUMBERS FROM 0 TO 1099511627775 TO CONVERT TO BINARY
    // USE A RANDOM NUMBER GENERATOR OR A REGRESSION LINE WITH A DESTINATION FILE. ADD OR SUBTRACT FROM THE DESTINATION
    // FILE TO BUILD THE TARGET FILES AROUND IT.
    byte = 1099511627775; // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< This is the base - 1 with a buffer of 5 bytes at a time.
    count1 = 0;
    whatdo = "write";
    dummyfile = binaryreadwrite(whatdo, file1, count1, byte, buffersize);
    exit(0);          
    
}
