This folder is here to help the user take a destination file and run it up and down. 
The time scanners take difference files and adds or subtracts them from the
destination files to construct target files. When the user has constructed enough
target files then the user can use the slop difference file to move the destination
file up or down then create more difference files to construct more target files.

To get the slop of a line use slop = y2 - y1 / x2 - x1 = rise / run. But all
the code needs here is to move the destination file up or down then in the
time scanners feed the destination file difference files.

The time scanners them self instead of being used to construct target files
can be used to move to move the destination file up or down by running 
the scanner with the destination file and a difference file. Then the
new target file is made the destination file.
