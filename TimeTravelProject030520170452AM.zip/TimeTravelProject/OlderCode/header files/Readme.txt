THE MOST CURRENT HEADER FILES ARE KEPT IN THIS FOLDER.
BASEPOWER2.H IS A failed UPGRADE TO BASEPOWER.H I will have to rewrite that program to increase the buffer size.
